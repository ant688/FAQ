namespace htWriting.Models;

public sealed class ModelSamplingPipeline
{
    public int TopK { get; set; }

    public double TypicalP { get; set; }

    public double TopP { get; set; }

    public double MinP { get; set; }

    public double Temperature { get; set; }

    public double RepeatPenalty { get; set; }

    public double FrequencyPenalty { get; set; }

    public double PresencePenalty { get; set; }

    public int PenaltyCount { get; set; }
}
