namespace htWriting.Models;

public enum UiLanguage
{
    Vietnamese,
    English
}
