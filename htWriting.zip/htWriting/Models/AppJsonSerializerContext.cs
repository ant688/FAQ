using System.Text.Json.Serialization;

namespace htWriting.Models;

[JsonSourceGenerationOptions(WriteIndented = true, UseStringEnumConverter = true)]
[JsonSerializable(typeof(AppSettings))]
[JsonSerializable(typeof(RewriteModelSettings))]
internal partial class AppJsonSerializerContext : JsonSerializerContext
{
}
