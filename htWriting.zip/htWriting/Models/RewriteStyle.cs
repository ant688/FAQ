namespace htWriting.Models;

public enum RewriteStyle
{
    Friendly,
    Professional,
    ConciseSummary,
    Detailed,
    TranslateOnly,
    Proofread,
    ProofreadImproved,
    ProofreadFormal
}
