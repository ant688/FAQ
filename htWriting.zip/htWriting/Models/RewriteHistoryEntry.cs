namespace htWriting.Models;

public sealed record RewriteHistoryEntry(
    long Id,
    DateTimeOffset CreatedAt,
    string SourceText,
    string ResultText,
    Language SourceLanguage,
    Language TargetLanguage,
    RewriteStyle Style,
    TimeSpan Duration);
