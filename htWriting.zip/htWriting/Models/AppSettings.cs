namespace htWriting.Models;

public sealed record AppSettings
{
    public UiLanguage UiLanguage { get; init; } = UiLanguage.Vietnamese;

    public Language SelectedInputLanguage { get; init; } = Language.None;

    public Language SelectedTranslateTo { get; init; } = Language.None;

    public string? SelectedModel { get; init; }

    public bool EnableThinking { get; init; }

    public bool UseModelConfigs { get; init; }

    public bool UseGpu { get; init; }

    public int GpuLayerCount { get; init; } = 15;

    public int MaxTokens { get; init; } = 512;

    public string Theme { get; init; } = "Default";

    public int TopK { get; init; } = 40;

    public double TypicalP { get; init; } = 1.0;

    public double TopP { get; init; } = 0.9;

    public double MinP { get; init; } = 0.08;

    public double Temperature { get; init; } = 0.7;

    public double RepeatPenalty { get; init; } = 1.0;

    public double FrequencyPenalty { get; init; }

    public double PresencePenalty { get; init; }

    public int PenaltyCount { get; init; } = 64;

    public IReadOnlyList<string> AdditionalGuidelines { get; init; } = [];
}
