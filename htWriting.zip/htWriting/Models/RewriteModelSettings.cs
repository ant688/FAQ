namespace htWriting.Models;

public sealed record RewriteModelSettings
{
    public string ModelName { get; init; } = string.Empty;

    public bool UseGpu { get; init; }

    public int GpuLayerCount { get; init; }

    public int MaxTokens { get; init; }

    public bool EnableThinking { get; init; }

    public bool UseCustomSampling { get; init; }

    public ModelSamplingPipeline Sampling { get; init; } = new();

    public IReadOnlyList<string> AdditionalGuidelines { get; init; } = [];
}
