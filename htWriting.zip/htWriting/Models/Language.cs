namespace htWriting.Models;

public enum Language
{
    None,
    English,
    Japanese,
    Vietnamese,
    ChineseSimplified,
    ChineseTraditional
}
