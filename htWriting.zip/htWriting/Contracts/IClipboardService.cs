namespace htWriting.Contracts;

public interface IClipboardService
{
    Task<string?> GetTextAsync();

    Task SetTextAsync(string text);
}
