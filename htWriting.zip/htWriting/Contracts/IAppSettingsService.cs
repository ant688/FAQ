using htWriting.Models;

namespace htWriting.Contracts;

public interface IAppSettingsService
{
    AppSettings Load();

    void Save(AppSettings settings);
}
