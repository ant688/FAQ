using htWriting.Models;

namespace htWriting.Contracts;

public interface IRewriteHistoryService
{
    Task SaveAsync(RewriteHistoryEntry entry, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<RewriteHistoryEntry>> SearchAsync(
        string query,
        CancellationToken cancellationToken = default);

    Task DeleteAsync(long id, CancellationToken cancellationToken = default);

    Task DeleteAllAsync(CancellationToken cancellationToken = default);
}
