using System.Globalization;
using htWriting.Models;

namespace htWriting.Helpers;

public static class UiText
{
    private static readonly IReadOnlyDictionary<string, (string Vietnamese, string English)> Strings =
        new Dictionary<string, (string Vietnamese, string English)>
        {
            ["app.description"] = ("Công cụ viết lại và dịch văn bản bằng mô hình AI cục bộ", "Local AI-powered writing and translation tool"),
            ["history.open"] = ("Lịch sử", "History"),
            ["history.title"] = ("Lịch sử viết", "Writing history"),
            ["history.search"] = ("Tìm kiếm", "Search"),
            ["history.search_placeholder"] = ("Tìm trong nội dung, ngôn ngữ, loại viết...", "Search text, languages, or writing type..."),
            ["history.delete"] = ("Xóa", "Delete"),
            ["history.delete_all"] = ("Xóa toàn bộ", "Delete all"),
            ["history.confirm_delete_all_title"] = ("Xác nhận xóa lịch sử", "Confirm history deletion"),
            ["history.confirm_delete_all_message"] = ("Bạn có chắc chắn muốn xóa toàn bộ lịch sử viết không? Thao tác này không thể hoàn tác.", "Are you sure you want to delete all writing history? This action cannot be undone."),
            ["history.empty"] = ("Chưa có lịch sử viết.", "No writing history yet."),
            ["history.source"] = ("Nguồn", "Source"),
            ["history.result"] = ("Kết quả", "Result"),
            ["history.reasoning"] = ("Nội dung suy luận", "Reasoning"),
            ["history.model_settings"] = ("Cài đặt mô hình", "Model settings"),
            ["history.model_name"] = ("Mô hình: {0}", "Model: {0}"),
            ["history.gpu"] = ("GPU: {0}, {1} lớp", "GPU: {0}, {1} layers"),
            ["history.max_tokens"] = ("Giới hạn token: {0}", "Max tokens: {0}"),
            ["history.thinking_enabled"] = ("Bật suy luận: {0}", "Reasoning enabled: {0}"),
            ["history.custom_sampling"] = ("Dùng cấu hình lấy mẫu tùy chỉnh: {0}", "Custom sampling: {0}"),
            ["history.settings_unavailable"] = ("Không lưu thông số mô hình (mục lịch sử cũ).", "Model settings were not saved (older history item)."),
            ["history.sampling_values"] = (
                "Top-K: {0}; Typical-P: {1}; Top-P: {2}; Min-P: {3}; Nhiệt độ: {4}; Phạt lặp: {5}; Phạt tần suất: {6}; Phạt hiện diện: {7}; Số token phạt: {8}",
                "Top-K: {0}; Typical-P: {1}; Top-P: {2}; Min-P: {3}; Temperature: {4}; Repeat penalty: {5}; Frequency penalty: {6}; Presence penalty: {7}; Penalty count: {8}"),
            ["history.guidelines"] = ("Hướng dẫn bổ sung: {0}", "Additional guidelines: {0}"),
            ["history.load_error"] = ("Không thể tải lịch sử: {0}", "Could not load history: {0}"),
            ["history.delete_error"] = ("Không thể xóa lịch sử: {0}", "Could not delete history: {0}"),
            ["history.open_error"] = ("Không thể mở cửa sổ lịch sử: {0}", "Could not open the history window: {0}"),
            ["history.save_error"] = ("Đã xử lý xong nhưng không thể lưu lịch sử: {0}", "Processing completed, but history could not be saved: {0}"),
            ["settings.load_error"] = ("Không thể tải cài đặt: {0}", "Could not load settings: {0}"),
            ["settings.save_error"] = ("Không thể lưu cài đặt: {0}", "Could not save settings: {0}"),
            ["language.input"] = ("Ngôn ngữ gốc", "Source language"),
            ["language.translate_to"] = ("Dịch sang", "Translate to"),
            ["language.none"] = ("Không xác định", "Unspecified"),
            ["language.english"] = ("Tiếng Anh", "English"),
            ["language.japanese"] = ("Tiếng Nhật", "Japanese"),
            ["language.vietnamese"] = ("Tiếng Việt", "Vietnamese"),
            ["language.chinese_simplified"] = ("Tiếng Trung giản thể", "Simplified Chinese"),
            ["language.chinese_traditional"] = ("Tiếng Trung phồn thể", "Traditional Chinese"),
            ["action.translate"] = ("Dịch", "Translate"),
            ["action.friendly"] = ("Thân thiện", "Friendly"),
            ["action.professional"] = ("Chuyên nghiệp", "Professional"),
            ["action.summary"] = ("Tóm tắt", "Summarize"),
            ["action.detailed"] = ("Chi tiết", "Detailed"),
            ["action.proofread"] = ("Hiệu đính", "Proofread"),
            ["action.proofread_improved"] = ("Hiệu đính nâng cao", "Enhanced proofreading"),
            ["action.proofread_formal"] = ("Hiệu đính trang trọng", "Formal proofreading"),
            ["action.stop"] = ("Dừng", "Stop"),
            ["thinking.enable"] = ("Bật suy luận", "Enable reasoning"),
            ["guidelines.label"] = ("Hướng dẫn bổ sung", "Additional instructions"),
            ["guidelines.placeholder"] = ("Nhập hướng dẫn rồi nhấn Enter...", "Enter instructions and press Enter..."),
            ["input.title"] = ("Văn bản gốc", "Original text"),
            ["input.copy"] = ("Sao chép văn bản gốc", "Copy original text"),
            ["input.paste"] = ("Dán", "Paste"),
            ["input.clear"] = ("Xóa", "Clear"),
            ["input.placeholder"] = ("Nhập hoặc dán nội dung cần xử lý...", "Enter or paste text to process..."),
            ["result.title"] = ("Kết quả", "Result"),
            ["result.import"] = ("Nhập lại làm đầu vào", "Use result as input"),
            ["result.copy"] = ("Sao chép", "Copy"),
            ["thinking.title"] = ("Nội dung suy luận", "Reasoning"),
            ["common.yes"] = ("Có", "Yes"),
            ["common.no"] = ("Không", "No"),
            ["sampling.title"] = ("Cấu hình lấy mẫu mô hình", "Model sampling configuration"),
            ["model.label"] = ("Mô hình AI", "AI model"),
            ["model.placeholder"] = ("Chọn mô hình (.gguf)", "Select a model (.gguf)"),
            ["gpu.enable"] = ("Sử dụng GPU", "Use GPU"),
            ["gpu.layers"] = ("Số lớp GPU", "GPU layers"),
            ["gpu.hint"] = ("Giảm số lớp nếu thiếu bộ nhớ GPU.", "Reduce layers if GPU memory is insufficient."),
            ["sampling.custom"] = ("Dùng cấu hình tùy chỉnh", "Use custom configuration"),
            ["sampling.max_tokens"] = ("Giới hạn token đầu ra", "Max output tokens"),
            ["sampling.max_tokens_hint"] = ("Mặc định 512; giới hạn này tính cả token suy luận.", "Default 512; this limit includes reasoning tokens."),
            ["sampling.temperature"] = ("Nhiệt độ", "Temperature"),
            ["sampling.repeat_penalty"] = ("Phạt lặp", "Repeat penalty"),
            ["sampling.frequency_penalty"] = ("Phạt tần suất", "Frequency penalty"),
            ["sampling.presence_penalty"] = ("Phạt hiện diện", "Presence penalty"),
            ["sampling.penalty_count"] = ("Số token phạt", "Penalty count"),
            ["status.ready"] = ("Sẵn sàng", "Ready"),
            ["status.models_folder_missing"] = ("Đặt các mô hình .gguf trong thư mục: {0}", "Place .gguf models in: {0}"),
            ["status.models_not_found"] = ("Không tìm thấy mô hình .gguf trong thư mục: {0}", "No .gguf models found in: {0}"),
            ["status.models_read_error"] = ("Không thể đọc thư mục mô hình: {0}", "Could not read the models folder: {0}"),
            ["status.model_loading"] = ("Đang tải mô hình AI ở chế độ nền...", "Loading the AI model in the background..."),
            ["status.model_load_error"] = ("Không thể tải mô hình AI: {0}", "Could not load the AI model: {0}"),
            ["status.copied_original"] = ("Đã sao chép văn bản gốc.", "Original text copied."),
            ["status.copy_original_error"] = ("Không thể sao chép văn bản: {0}", "Could not copy text: {0}"),
            ["status.clipboard_read_error"] = ("Không thể đọc clipboard: {0}", "Could not read the clipboard: {0}"),
            ["status.copied_result"] = ("Đã sao chép kết quả.", "Result copied."),
            ["status.copy_result_error"] = ("Không thể sao chép kết quả: {0}", "Could not copy the result: {0}"),
            ["status.choose_input_language"] = ("Vui lòng chọn ngôn ngữ của văn bản gốc.", "Please select the source language."),
            ["status.choose_model"] = ("Vui lòng đặt file .gguf và chọn mô hình trong thư mục: {0}", "Place a .gguf file in the models folder and select it: {0}"),
            ["status.choose_target_language"] = ("Vui lòng chọn ngôn ngữ cần dịch.", "Please select a target language."),
            ["status.rewrite.friendly"] = ("Đang viết lại theo phong cách thân thiện...", "Rewriting in a friendly style..."),
            ["status.rewrite.professional"] = ("Đang viết lại theo phong cách chuyên nghiệp...", "Rewriting in a professional style..."),
            ["status.rewrite.summary"] = ("Đang tóm tắt...", "Summarizing..."),
            ["status.rewrite.detailed"] = ("Đang viết lại chi tiết...", "Rewriting in detail..."),
            ["status.rewrite.proofread"] = ("Đang kiểm tra và hiệu đính...", "Checking and proofreading..."),
            ["status.rewrite.proofread_improved"] = ("Đang hiệu đính nâng cao...", "Enhancing the proofreading..."),
            ["status.rewrite.proofread_formal"] = ("Đang hiệu đính theo văn phong trang trọng...", "Proofreading in a formal style..."),
            ["status.rewrite.translate"] = ("Đang dịch...", "Translating..."),
            ["status.completed"] = ("Hoàn tất", "Completed"),
            ["status.cancelled"] = ("Đã hủy thao tác.", "Operation cancelled."),
            ["status.rewrite_error"] = ("Không thể xử lý văn bản: {0}", "Could not process the text: {0}"),
            ["error.gpu_unavailable"] = ("Không tìm thấy backend GPU tương thích. Hãy tắt tùy chọn GPU hoặc cài driver phù hợp.", "No compatible GPU backend was found. Turn off GPU use or install a compatible driver."),
            ["error.model_missing"] = ("Không tìm thấy mô hình AI tại '{0}'. Hãy đặt file .gguf trong thư mục Models cạnh ứng dụng.", "AI model not found at '{0}'. Place a .gguf file in the Models folder next to the app."),
            ["error.backend_init"] = ("Không thể khởi tạo backend mô hình AI.", "Could not initialize the AI model backend.")
        };

    public static string Get(UiLanguage language, string key, params object?[] arguments)
    {
        if (!Strings.TryGetValue(key, out var translations))
        {
            throw new KeyNotFoundException($"Unknown localization key '{key}'.");
        }

        var format = language switch
        {
            UiLanguage.Vietnamese => translations.Vietnamese,
            UiLanguage.English => translations.English,
            _ => throw new ArgumentOutOfRangeException(nameof(language), language, null)
        };

        return arguments.Length == 0
            ? format
            : string.Format(CultureInfo.InvariantCulture, format, arguments);
    }

    public static string GetLanguageName(UiLanguage uiLanguage, Language language) =>
        Get(uiLanguage, language switch
        {
            Language.None => "language.none",
            Language.English => "language.english",
            Language.Japanese => "language.japanese",
            Language.Vietnamese => "language.vietnamese",
            Language.ChineseSimplified => "language.chinese_simplified",
            Language.ChineseTraditional => "language.chinese_traditional",
            _ => throw new ArgumentOutOfRangeException(nameof(language), language, null)
        });

    public static string GetRewriteStyleName(UiLanguage uiLanguage, RewriteStyle style) =>
        Get(uiLanguage, style switch
        {
            RewriteStyle.Friendly => "action.friendly",
            RewriteStyle.Professional => "action.professional",
            RewriteStyle.ConciseSummary => "action.summary",
            RewriteStyle.Detailed => "action.detailed",
            RewriteStyle.TranslateOnly => "action.translate",
            RewriteStyle.Proofread => "action.proofread",
            RewriteStyle.ProofreadImproved => "action.proofread_improved",
            RewriteStyle.ProofreadFormal => "action.proofread_formal",
            _ => throw new ArgumentOutOfRangeException(nameof(style), style, null)
        });
}
