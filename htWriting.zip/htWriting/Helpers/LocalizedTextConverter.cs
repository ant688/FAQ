using System.Globalization;
using Avalonia.Data.Converters;
using htWriting.Models;

namespace htWriting.Helpers;

public sealed class LocalizedTextConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is not UiLanguage language)
        {
            throw new ArgumentException("The converter value must be a UI language.", nameof(value));
        }

        if (parameter is not string key)
        {
            throw new ArgumentException("The converter parameter must be a localization key.", nameof(parameter));
        }

        return UiText.Get(language, key);
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
