namespace htWriting.Helpers;

public static class AppDataPaths
{
    public static string DirectoryPath { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "HTWriting");
}
