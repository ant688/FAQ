using Avalonia.Controls;
using Avalonia.Input.Platform;
using htWriting.Contracts;

namespace htWriting.Services;

public sealed class ClipboardService(Func<Window?> getMainWindow) : IClipboardService
{
    public Task<string?> GetTextAsync()
    {
        var clipboard = getMainWindow()?.Clipboard
            ?? throw new InvalidOperationException("The application clipboard is unavailable.");

        return clipboard.TryGetTextAsync();
    }

    public Task SetTextAsync(string text)
    {
        var clipboard = getMainWindow()?.Clipboard
            ?? throw new InvalidOperationException("The application clipboard is unavailable.");

        return clipboard.SetTextAsync(text);
    }
}
