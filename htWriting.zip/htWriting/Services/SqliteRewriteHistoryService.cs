using System.Globalization;
using htWriting.Contracts;
using htWriting.Models;
using Microsoft.Data.Sqlite;

namespace htWriting.Services;

public sealed class SqliteRewriteHistoryService : IRewriteHistoryService
{
    private readonly string _connectionString;
    private readonly string _databaseDirectory;
    private readonly SemaphoreSlim _initializationLock = new(1, 1);
    private bool _initialized;

    public SqliteRewriteHistoryService()
    {
        SQLitePCL.raw.SetProvider(OperatingSystem.IsWindows()
            ? new SQLitePCL.SQLite3Provider_winsqlite3()
            : new SQLitePCL.SQLite3Provider_sqlite3());
        _databaseDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "HTWritingTool");
        _connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = Path.Combine(_databaseDirectory, "rewrite-history.sqlite")
        }.ToString();
    }

    public async Task SaveAsync(RewriteHistoryEntry entry, CancellationToken cancellationToken = default)
    {
        await EnsureInitializedAsync(cancellationToken);

        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO rewrite_history (
                created_at, source_text, result_text, source_language,
                target_language, rewrite_style, duration_ticks)
            VALUES (
                $created_at, $source_text, $result_text, $source_language,
                $target_language, $rewrite_style, $duration_ticks);
            """;
        command.Parameters.AddWithValue("$created_at", entry.CreatedAt.ToString("O", CultureInfo.InvariantCulture));
        command.Parameters.AddWithValue("$source_text", entry.SourceText);
        command.Parameters.AddWithValue("$result_text", entry.ResultText);
        command.Parameters.AddWithValue("$source_language", entry.SourceLanguage.ToString());
        command.Parameters.AddWithValue("$target_language", entry.TargetLanguage.ToString());
        command.Parameters.AddWithValue("$rewrite_style", entry.Style.ToString());
        command.Parameters.AddWithValue("$duration_ticks", entry.Duration.Ticks);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<RewriteHistoryEntry>> SearchAsync(
        string query,
        CancellationToken cancellationToken = default)
    {
        await EnsureInitializedAsync(cancellationToken);

        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT id, created_at, source_text, result_text, source_language,
                   target_language, rewrite_style, duration_ticks
            FROM rewrite_history
            WHERE $query = ''
               OR created_at LIKE $pattern ESCAPE '\'
               OR source_text LIKE $pattern ESCAPE '\'
               OR result_text LIKE $pattern ESCAPE '\'
               OR source_language LIKE $pattern ESCAPE '\'
               OR target_language LIKE $pattern ESCAPE '\'
               OR rewrite_style LIKE $pattern ESCAPE '\'
            ORDER BY created_at DESC, id DESC;
            """;
        command.Parameters.AddWithValue("$query", query);
        command.Parameters.AddWithValue("$pattern", $"%{EscapeLikePattern(query)}%");

        var entries = new List<RewriteHistoryEntry>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            entries.Add(new RewriteHistoryEntry(
                reader.GetInt64(0),
                DateTimeOffset.Parse(reader.GetString(1), CultureInfo.InvariantCulture, DateTimeStyles.None),
                reader.GetString(2),
                reader.GetString(3),
                Enum.Parse<Language>(reader.GetString(4)),
                Enum.Parse<Language>(reader.GetString(5)),
                Enum.Parse<RewriteStyle>(reader.GetString(6)),
                TimeSpan.FromTicks(reader.GetInt64(7))));
        }

        return entries;
    }

    public async Task DeleteAsync(long id, CancellationToken cancellationToken = default)
    {
        await EnsureInitializedAsync(cancellationToken);

        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM rewrite_history WHERE id = $id;";
        command.Parameters.AddWithValue("$id", id);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task DeleteAllAsync(CancellationToken cancellationToken = default)
    {
        await EnsureInitializedAsync(cancellationToken);

        await using var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = "DELETE FROM rewrite_history;";
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private async Task EnsureInitializedAsync(CancellationToken cancellationToken)
    {
        if (_initialized)
        {
            return;
        }

        await _initializationLock.WaitAsync(cancellationToken);
        try
        {
            if (_initialized)
            {
                return;
            }

            Directory.CreateDirectory(_databaseDirectory);
            await using var connection = new SqliteConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);
            await using var command = connection.CreateCommand();
            command.CommandText = """
                CREATE TABLE IF NOT EXISTS rewrite_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    source_text TEXT NOT NULL,
                    result_text TEXT NOT NULL,
                    source_language TEXT NOT NULL,
                    target_language TEXT NOT NULL,
                    rewrite_style TEXT NOT NULL,
                    duration_ticks INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS ix_rewrite_history_created_at
                    ON rewrite_history (created_at DESC, id DESC);
                """;
            await command.ExecuteNonQueryAsync(cancellationToken);
            _initialized = true;
        }
        finally
        {
            _initializationLock.Release();
        }
    }

    private static string EscapeLikePattern(string value) =>
        value.Replace("\\", "\\\\", StringComparison.Ordinal)
            .Replace("%", "\\%", StringComparison.Ordinal)
            .Replace("_", "\\_", StringComparison.Ordinal);
}
