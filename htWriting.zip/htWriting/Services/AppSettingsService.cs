using System.Text.Json;
using htWriting.Contracts;
using htWriting.Helpers;
using htWriting.Models;

namespace htWriting.Services;

public sealed class AppSettingsService : IAppSettingsService
{
    private readonly string _settingsPath = Path.Combine(AppDataPaths.DirectoryPath, "appsettings.json");

    public AppSettings Load()
    {
        string settingsJson;
        try
        {
            settingsJson = File.ReadAllText(_settingsPath);
        }
        catch (FileNotFoundException)
        {
            return new AppSettings();
        }
        catch (DirectoryNotFoundException)
        {
            return new AppSettings();
        }

        return JsonSerializer.Deserialize(
                   settingsJson,
                   AppJsonSerializerContext.Default.AppSettings)
               ?? throw new JsonException("The saved application settings are invalid.");
    }

    public void Save(AppSettings settings)
    {
        Directory.CreateDirectory(AppDataPaths.DirectoryPath);
        File.WriteAllText(
            _settingsPath,
            JsonSerializer.Serialize(settings, AppJsonSerializerContext.Default.AppSettings));
    }
}
