# htWriting

htWriting is a desktop application for rewriting, proofreading, summarizing, and translating text with a locally running language model. It uses Avalonia for its UI and LLamaSharp for inference with GGUF models. Text is processed on the user's machine by the selected model; the app does not send content to an online AI service.

## Features

- Rewrite text in friendly, professional, or detailed styles.
- Summarize and proofread text with standard, enhanced, or formal proofreading.
- Translate between English, Japanese, Vietnamese, Simplified Chinese, and Traditional Chinese.
- Select the source language, add custom instructions, enable reasoning, and configure sampling parameters.
- Copy, paste, and clear text; use a result as new input; cancel an ongoing operation.
- Search, view, and delete history. History records source text, results, languages, operation style, duration, reasoning text, and model settings.
- Vietnamese and English UI, with light, dark, or system theme options.

## How it works

1. When the main window opens, the app looks for `.gguf` files in the `Models` directory next to the application, selects a model, and preloads it in the background.
2. The user enters text, selects its source language, and chooses an operation. Translation also requires a target language.
3. `MainViewModel` validates the input, snapshots the current settings, and forwards the request through `IRewriteService`.
4. `LlamaRewriteService` builds the model instructions, loads or reuses the LLamaSharp model, and generates output token by token.
5. The UI displays output as it is generated. On completion, the result and its settings are saved to SQLite.
6. Application settings are stored as JSON; the history window queries a separate SQLite database.

The app follows MVVM. `App.axaml.cs` registers services, view models, and windows with dependency injection. Interfaces in `Contracts/` decouple the UI from storage, clipboard, and inference implementations.

## Getting started

### Requirements

- .NET 10 SDK.
- A GGUF model compatible with LLamaSharp. A model is not included.
- Enough RAM/VRAM for the selected model. GPU support is not required for CPU inference.

### Run from source

Place a model file in the `Models/` directory at the project root, then run:

```bash
dotnet restore
dotnet run
```

In the app, select a model if one was not selected automatically, choose the source language, enter text, and choose an operation. If GPU use is enabled, adjust the number of GPU layers as needed. If no compatible backend is available, turn off GPU use.

### Build and publish

```bash
dotnet build -c Release
dotnet publish -c Release -r <RID>
```

Replace `<RID>` with the Runtime Identifier for the target operating system and architecture. The project enables Native AOT (`PublishAot`); publishing may require the corresponding native toolchain on the build machine. Models in `Models/*.gguf` are configured to be copied to build and publish output.

## Settings and data

- Models: `Models/*.gguf` next to the application.
- Settings: the user's local application data directory, in the `HTWriting` subdirectory; file `appsettings.json`.
- History: the same data directory; file `rewrite-history.sqlite`.

Settings include UI and processing languages, model selection, GPU and GPU layer count, token limit, reasoning mode, theme, additional instructions, and sampling parameters. History can be searched by text, language, operation style, and saved model settings; each query returns up to the 200 most recent matches.

### Model configuration settings

Expand **Model sampling configuration** at the bottom of the main window to see these options. The defaults below apply when the app has no previously saved settings.

| Setting | What it does and how to use it | Default |
|---|---|---:|
| **AI model** | Select a `.gguf` file from the `Models` directory. Processing speed and resource use depend on the model and hardware. | First model found |
| **Use GPU** | Enable to offload some computation to a GPU. A compatible backend and driver are required. If model loading reports a GPU error, turn this off to use the CPU. | Off |
| **GPU layers** | Number of model layers placed on the GPU. Increasing this can reduce CPU work or improve speed, but requires more VRAM; lower it if GPU memory is insufficient. Only applies when GPU use is enabled. | 15 (UI range: 1–128) |
| **Max output tokens** | Maximum number of tokens the model may generate for one operation. This includes reasoning tokens. A higher limit allows longer output but may require more time and memory. | 512 (1–4096) |
| **Enable reasoning** | Allows the model's reasoning mode. Use with a model that supports this mode. Reasoning tokens count toward the output limit and may be shown separately when the model emits the expected reasoning boundary. | Off |
| **Use custom configuration** | Enable to apply the sampling parameters below. When disabled, the app uses a style-dependent default temperature (for example: friendly 0.5, professional 0.3, summary 0.2, translation 0.1); the custom values are not applied. | Off |
| **Top-K** | Limits each generation step to at most the K highest-probability tokens. A smaller K generally narrows the choices. | 40 (0–64) |
| **Typical-P** | Filters tokens according to how well they fit the model's typical probability distribution. Lower values generally filter more aggressively. | 1.00 (0–1) |
| **Top-P** | Selects from the smallest group of tokens whose cumulative probability reaches P. Lower values generally constrain the choices more. | 0.90 (0–1) |
| **Min-P** | Filters out tokens below a threshold relative to the highest-probability token. Raising the threshold generally focuses generation on more likely choices. | 0.08 (0–1) |
| **Temperature** | Controls randomness: lower values are generally more predictable, while higher values are more varied but may be less consistent. | 0.70 (0–2) |
| **Repeat penalty** | Reduces the tendency to repeat tokens that have already appeared. 1.0 is neutral; high values can make wording less natural. | 1.00 (0–2) |
| **Frequency penalty** | Adjusts token probability based on how often it has appeared. Positive values discourage frequent repetition; negative values may encourage it. | 0 (-2–2) |
| **Presence penalty** | Adjusts token probability if it has appeared at least once, regardless of repetition count. Positive values encourage introducing new tokens/topics; negative values may encourage reuse. | 0 (-2–2) |
| **Penalty count** | Number of recent tokens considered when applying repetition penalties. Increase it to consider a longer context window. | 64 (0–128) |

Sampling filters can interact. If output is too random, repetitive, or constrained, change one parameter at a time and try again. **Additional instructions** above the text area accepts custom requests as tags; keep them concise and specific (for example, preserve technical terms or limit the length).

## Optimizations

- **Background loading and model reuse:** model discovery and preloading do not block the UI. A loaded model is retained and reloaded only when the model path or GPU layer count changes.
- **Streaming inference:** output arrives token by token through `IAsyncEnumerable`, rather than waiting for the entire response. Inference can be cancelled with a `CancellationToken`.
- **Fewer UI updates:** streamed text is accumulated with `StringBuilder` and synchronized with the UI at most about 10 times per second, instead of updating for every token.
- **Hardware acceleration:** GPU layer count is configurable. LLamaSharp backends include CUDA and Vulkan, and Metal is detected on macOS ARM64. For CPU inference, the thread count is based on the available processor count, with a minimum of one thread. The default context size is 4096 tokens.
- **Batched settings writes:** setting changes are debounced by 300 ms to avoid repeated disk writes while adjusting options. A lock and version check coordinate writes, and pending settings are flushed when the window closes.
- **SQLite history storage:** connection pooling, shared cache, WAL, `synchronous=NORMAL`, in-memory temporary storage, and a timestamp index support history reads, writes, and sorting.
- **Native AOT support:** JSON serialization uses `System.Text.Json` source generation for known data types, reducing reliance on reflection during AOT publishing.
- **Bounded history queries:** searches return at most the 200 most recent matches, limiting the amount of data loaded into the UI.

## Main technologies

- C# / .NET 10, Avalonia 12, CommunityToolkit.Mvvm.
- LLamaSharp with CPU, CUDA 12, and Vulkan backends.
- SQLite (`Microsoft.Data.Sqlite`).
