using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using htWriting.Contracts;
using htWriting.Services;
using htWriting.ViewModels;
using htWriting.Views;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace htWriting;

public partial class App : Application
{
    private IHost? _host;

    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var host = Host.CreateDefaultBuilder()
                .ConfigureServices(services =>
                {
                    services.AddSingleton<IRewriteService, LlamaRewriteService>();
                    services.AddSingleton<IRewriteHistoryService, SqliteRewriteHistoryService>();
                    services.AddSingleton<IClipboardService>(
                        _ => new ClipboardService(() => desktop.MainWindow));
                    services.AddTransient<MainViewModel>();
                    services.AddTransient<HistoryViewModel>();
                    services.AddTransient<MainWindow>();
                    services.AddTransient<HistoryWindow>();
                })
                .Build();
            _host = host;

            desktop.MainWindow = host.Services.GetRequiredService<MainWindow>();
            desktop.Exit += (_, _) => host.Dispose();
        }

        base.OnFrameworkInitializationCompleted();
    }
}