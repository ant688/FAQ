# htWriting

htWriting là ứng dụng desktop viết lại, hiệu đính, tóm tắt và dịch văn bản bằng mô hình ngôn ngữ chạy cục bộ. Ứng dụng dùng Avalonia cho giao diện và LLamaSharp để suy luận trên các mô hình GGUF. Văn bản được xử lý trên máy bằng mô hình đã chọn; ứng dụng không gửi nội dung tới dịch vụ AI trực tuyến.

## Chức năng

- Viết lại theo phong cách thân thiện, chuyên nghiệp hoặc chi tiết.
- Tóm tắt; hiệu đính cơ bản, nâng cao hoặc theo văn phong trang trọng.
- Dịch giữa tiếng Anh, tiếng Nhật, tiếng Việt, tiếng Trung giản thể và phồn thể.
- Chọn ngôn ngữ đầu vào, thêm hướng dẫn riêng, bật chế độ suy luận và điều chỉnh thông số lấy mẫu.
- Sao chép, dán, xóa văn bản, dùng kết quả làm đầu vào mới và hủy tác vụ đang chạy.
- Tìm kiếm, xem và xóa lịch sử. Lịch sử lưu văn bản gốc, kết quả, ngôn ngữ, kiểu xử lý, thời lượng, nội dung suy luận và thông số mô hình.
- Giao diện tiếng Việt hoặc tiếng Anh, hỗ trợ giao diện sáng, tối hoặc theo hệ thống.

## Cách ứng dụng hoạt động

1. Khi cửa sổ chính mở, ứng dụng tìm các tệp `.gguf` trong thư mục `Models` cạnh ứng dụng, chọn mô hình và tải mô hình ở chế độ nền.
2. Người dùng nhập văn bản, chọn ngôn ngữ gốc và một thao tác. Với dịch thuật, cần chọn thêm ngôn ngữ đích.
3. `MainViewModel` kiểm tra đầu vào, chụp lại cấu hình hiện thời và chuyển yêu cầu qua `IRewriteService`.
4. `LlamaRewriteService` tạo chỉ dẫn cho mô hình, tải hoặc tái sử dụng mô hình LLamaSharp, rồi phát sinh kết quả theo từng token.
5. Giao diện hiển thị kết quả trong lúc sinh. Khi xử lý thành công, kết quả cùng thông tin cấu hình được lưu vào SQLite.
6. Cài đặt được lưu dưới dạng JSON; cửa sổ lịch sử truy vấn cơ sở dữ liệu SQLite riêng.

Ứng dụng áp dụng MVVM. `App.axaml.cs` đăng ký dịch vụ, ViewModel và cửa sổ với dependency injection; các interface trong `Contracts/` tách giao diện khỏi phần cài đặt lưu trữ, clipboard và suy luận.

## Bắt đầu

### Yêu cầu

- .NET 10 SDK.
- Một mô hình GGUF tương thích với LLamaSharp. Mô hình không được đóng gói sẵn.
- Đủ RAM/VRAM cho mô hình đã chọn. Chạy CPU không cần GPU tương thích.

### Chạy từ mã nguồn

Đặt tệp mô hình vào `Models/` ở thư mục gốc dự án, sau đó chạy:

```bash
dotnet restore
dotnet run
```

Trong ứng dụng, chọn mô hình nếu chưa được chọn tự động, chọn ngôn ngữ gốc, nhập văn bản rồi chọn thao tác. Khi bật GPU, có thể điều chỉnh số lớp chạy trên GPU; nếu máy không có backend tương thích, hãy tắt tùy chọn GPU.

### Build và publish

```bash
dotnet build -c Release
dotnet publish -c Release -r <RID>
```

Thay `<RID>` bằng Runtime Identifier phù hợp với hệ điều hành và kiến trúc đích. Dự án bật Native AOT (`PublishAot`); publish có thể cần toolchain native tương ứng trên máy build. Các mô hình trong `Models/*.gguf` được cấu hình để sao chép vào đầu ra build và publish.

## Cấu hình và dữ liệu

- Mô hình: `Models/*.gguf` cạnh ứng dụng.
- Cài đặt: thư mục dữ liệu ứng dụng cục bộ của người dùng, trong thư mục con `HTWriting`; tệp `appsettings.json`.
- Lịch sử: cùng thư mục dữ liệu, tệp `rewrite-history.sqlite`.

Cài đặt gồm ngôn ngữ giao diện và xử lý, mô hình, GPU/số lớp GPU, giới hạn token, chế độ suy luận, chủ đề, hướng dẫn bổ sung và các thông số lấy mẫu. Lịch sử có thể tìm kiếm theo nội dung, ngôn ngữ, kiểu xử lý và thông số đã lưu; truy vấn hiển thị tối đa 200 mục mới nhất.

### Giải thích thiết lập cho mô hình

Mở mục **Cấu hình lấy mẫu mô hình** ở cuối cửa sổ chính để xem các tùy chọn. Các giá trị mặc định dưới đây là giá trị mới khi ứng dụng chưa có cấu hình đã lưu.

| Thiết lập | Ý nghĩa và cách dùng | Mặc định |
|---|---|---:|
| **Mô hình AI** | Chọn tệp `.gguf` trong thư mục `Models`. Kích thước và tốc độ xử lý phụ thuộc vào mô hình và phần cứng. | Chọn mô hình đầu tiên tìm thấy |
| **Sử dụng GPU** | Bật để chuyển một phần phép tính sang GPU. Cần backend/driver tương thích; nếu tải mô hình báo lỗi GPU, hãy tắt tùy chọn này để chạy CPU. | Tắt |
| **Số lớp GPU** | Số lớp mô hình được đưa lên GPU. Tăng có thể giảm tải CPU hoặc tăng tốc, nhưng cần thêm VRAM; giảm số lớp nếu thiếu bộ nhớ GPU. Chỉ có tác dụng khi bật GPU. | 15 (giới hạn giao diện: 1–128) |
| **Giới hạn token đầu ra** | Số token tối đa mô hình được sinh cho một lần xử lý. Giới hạn này tính cả token suy luận; tăng giới hạn có thể cho phép kết quả dài hơn nhưng tốn thêm thời gian/bộ nhớ. | 512 (1–4096) |
| **Bật suy luận** | Cho phép dùng chế độ suy luận của mô hình. Nên dùng với mô hình hỗ trợ chế độ này; token suy luận vẫn tính vào giới hạn token và có thể được hiển thị riêng khi mô hình trả về ranh giới suy luận phù hợp. | Tắt |
| **Dùng cấu hình tùy chỉnh** | Bật để áp dụng các tham số lấy mẫu bên dưới. Khi tắt, ứng dụng dùng nhiệt độ mặc định theo thao tác (ví dụ: thân thiện 0,5; chuyên nghiệp 0,3; tóm tắt 0,2; dịch 0,1); các giá trị tùy chỉnh không được áp dụng. | Tắt |
| **Top-K** | Giới hạn lựa chọn vào tối đa K token có xác suất cao nhất ở mỗi bước. K nhỏ thường làm lựa chọn hẹp hơn. | 40 (0–64) |
| **Typical-P** | Lọc token theo mức độ phù hợp với phân phối xác suất điển hình của mô hình. Giá trị thấp hơn thường lọc mạnh hơn. | 1,00 (0–1) |
| **Top-P** | Lấy nhóm token có tổng xác suất tích lũy đạt ngưỡng P rồi chọn trong nhóm đó. Giá trị thấp hơn thường giới hạn lựa chọn chặt hơn. | 0,90 (0–1) |
| **Min-P** | Loại các token có xác suất thấp hơn ngưỡng tương đối so với token có xác suất cao nhất. Tăng ngưỡng thường làm lựa chọn tập trung hơn. | 0,08 (0–1) |
| **Nhiệt độ (Temperature)** | Điều chỉnh độ ngẫu nhiên: thấp thường ổn định/dễ đoán hơn, cao thường đa dạng hơn nhưng có thể kém nhất quán. | 0,70 (0–2) |
| **Phạt lặp (Repeat penalty)** | Giảm xu hướng lặp lại token đã xuất hiện. Giá trị 1,0 là mức trung tính; tăng cao có thể khiến câu chữ thiếu tự nhiên. | 1,00 (0–2) |
| **Phạt tần suất (Frequency penalty)** | Điều chỉnh xác suất token dựa trên số lần token đó đã xuất hiện: giá trị dương hạn chế lặp nhiều, giá trị âm có thể khuyến khích lặp. | 0 (-2–2) |
| **Phạt hiện diện (Presence penalty)** | Điều chỉnh xác suất token đã xuất hiện ít nhất một lần, không phụ thuộc số lần lặp. Giá trị dương khuyến khích đưa thêm token/chủ đề mới; giá trị âm có thể khuyến khích dùng lại. | 0 (-2–2) |
| **Số token áp dụng phạt (Penalty count)** | Phạm vi token gần nhất được xét khi áp dụng các hình phạt lặp. Tăng phạm vi để xét đoạn dài hơn. | 64 (0–128) |

Các bộ lọc lấy mẫu có thể tương tác với nhau. Nếu kết quả quá ngẫu nhiên, lặp nhiều hoặc bị giới hạn quá mức, hãy thay đổi từng tham số một và thử lại. Mục **Hướng dẫn bổ sung** phía trên vùng văn bản nhận các yêu cầu riêng dạng thẻ; hãy viết ngắn gọn, cụ thể (chẳng hạn yêu cầu giữ nguyên thuật ngữ hoặc giới hạn độ dài).

## Tối ưu hóa được sử dụng

- **Tải nền và tái sử dụng mô hình:** dò tệp mô hình và preload không chặn giao diện. Mô hình đã nạp được giữ lại; chỉ nạp lại khi đường dẫn mô hình hoặc số lớp GPU thay đổi.
- **Suy luận streaming:** kết quả được nhận theo từng token qua `IAsyncEnumerable`, không phải đợi mô hình tạo xong toàn bộ văn bản. Có thể hủy tác vụ bằng `CancellationToken`.
- **Giảm cập nhật giao diện:** nội dung streaming được gom bằng `StringBuilder` và chỉ đồng bộ lên UI tối đa khoảng 10 lần/giây, tránh cập nhật giao diện cho từng token.
- **Tận dụng phần cứng:** cấu hình số lớp GPU; backend LLamaSharp hỗ trợ CUDA và Vulkan, đồng thời nhận diện Metal trên macOS ARM64. Khi chạy CPU, số luồng được đặt theo số lõi khả dụng (tối thiểu một luồng). Context mặc định là 4096 token.
- **Ghi cài đặt theo lô:** thay đổi cấu hình được debounce 300 ms, tránh ghi tệp liên tục khi người dùng điều chỉnh nhiều giá trị; có khóa và phiên bản để phối hợp việc lưu, đồng thời flush khi đóng cửa sổ.
- **SQLite cho lịch sử:** dùng connection pooling, shared cache, WAL, `synchronous=NORMAL`, temporary store trong bộ nhớ và chỉ mục theo thời gian để hỗ trợ đọc/ghi và sắp xếp lịch sử.
- **Hỗ trợ Native AOT:** JSON dùng `System.Text.Json` source generation cho các kiểu dữ liệu đã biết, giảm phụ thuộc vào phân tích kiểu bằng reflection khi publish AOT.
- **Giới hạn dữ liệu truy vấn:** tìm kiếm lịch sử chỉ trả về tối đa 200 kết quả mới nhất, hạn chế tải quá nhiều dữ liệu cùng lúc lên giao diện.

## Công nghệ chính

- C# / .NET 10, Avalonia 12, CommunityToolkit.Mvvm.
- LLamaSharp với backend CPU, CUDA 12 và Vulkan.
- SQLite (`Microsoft.Data.Sqlite`).
