using System.Globalization;
using htWriting.Helpers;
using htWriting.Models;

namespace htWriting.ViewModels;

public sealed class HistoryItemViewModel
{
    public long Id { get; }
    public string Summary { get; }
    public string DeleteLabel { get; }
    public string SourceLabel { get; }
    public string ResultLabel { get; }
    public string SourceText { get; }
    public string ResultText { get; }

    public HistoryItemViewModel(RewriteHistoryEntry entry, UiLanguage language)
    {
        Id = entry.Id;
        var createdAt = entry.CreatedAt.ToLocalTime().ToString("g", CultureInfo.CurrentCulture);
        var style = UiText.GetRewriteStyleName(language, entry.Style);
        var languages = $"{UiText.GetLanguageName(language, entry.SourceLanguage)} → " +
                        $"{UiText.GetLanguageName(language, entry.TargetLanguage)}";
        var duration = entry.Duration.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture);
        Summary = $"{createdAt} · {style} · {languages} · {duration}";
        DeleteLabel = UiText.Get(language, "history.delete");
        SourceLabel = UiText.Get(language, "history.source");
        ResultLabel = UiText.Get(language, "history.result");
        SourceText = entry.SourceText;
        ResultText = entry.ResultText;
    }
}
