using System.Globalization;
using htWriting.Helpers;
using htWriting.Models;

namespace htWriting.ViewModels;

public sealed class HistoryItemViewModel
{
    public long Id { get; }
    public string Summary { get; }
    public string DeleteLabel { get; }
    public string SourceLabel { get; }
    public string ResultLabel { get; }
    public string ReasoningLabel { get; }
    public string ModelSettingsLabel { get; }
    public string SourceText { get; }
    public string ResultText { get; }
    public string ReasoningText { get; }
    public string ModelSettingsText { get; }
    public bool HasReasoning => !string.IsNullOrWhiteSpace(ReasoningText);

    public HistoryItemViewModel(RewriteHistoryEntry entry, UiLanguage language)
    {
        Id = entry.Id;
        var createdAt = entry.CreatedAt.ToLocalTime().ToString("g", CultureInfo.CurrentCulture);
        var style = UiText.GetRewriteStyleName(language, entry.Style);
        var languages = $"{UiText.GetLanguageName(language, entry.SourceLanguage)} → " +
                        $"{UiText.GetLanguageName(language, entry.TargetLanguage)}";
        var duration = entry.Duration.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture);
        Summary = $"{createdAt} · {style} · {languages} · {duration}";
        DeleteLabel = UiText.Get(language, "history.delete");
        SourceLabel = UiText.Get(language, "history.source");
        ResultLabel = UiText.Get(language, "history.result");
        ReasoningLabel = UiText.Get(language, "history.reasoning");
        ModelSettingsLabel = UiText.Get(language, "history.model_settings");
        SourceText = entry.SourceText;
        ResultText = entry.ResultText;
        ReasoningText = entry.ReasoningText;
        if (entry.ModelSettings is not { } settings)
        {
            ModelSettingsText = UiText.Get(language, "history.settings_unavailable");
            return;
        }

        var yes = UiText.Get(language, "common.yes");
        var no = UiText.Get(language, "common.no");
        var sampling = settings.Sampling;
        var settingsLines = new List<string>
        {
            UiText.Get(language, "history.model_name", settings.ModelName),
            UiText.Get(language, "history.gpu", settings.UseGpu ? yes : no, settings.GpuLayerCount),
            UiText.Get(language, "history.max_tokens", settings.MaxTokens),
            UiText.Get(language, "history.thinking_enabled", settings.EnableThinking ? yes : no),
            UiText.Get(language, "history.custom_sampling", settings.UseCustomSampling ? yes : no),
            UiText.Get(
                language,
                "history.sampling_values",
                sampling.TopK,
                sampling.TypicalP.ToString("0.##", CultureInfo.CurrentCulture),
                sampling.TopP.ToString("0.##", CultureInfo.CurrentCulture),
                sampling.MinP.ToString("0.##", CultureInfo.CurrentCulture),
                sampling.Temperature.ToString("0.##", CultureInfo.CurrentCulture),
                sampling.RepeatPenalty.ToString("0.##", CultureInfo.CurrentCulture),
                sampling.FrequencyPenalty.ToString("0.##", CultureInfo.CurrentCulture),
                sampling.PresencePenalty.ToString("0.##", CultureInfo.CurrentCulture),
                sampling.PenaltyCount)
        };
        if (settings.AdditionalGuidelines.Count > 0)
        {
            settingsLines.Add(UiText.Get(
                language,
                "history.guidelines",
                string.Join("; ", settings.AdditionalGuidelines)));
        }

        ModelSettingsText = string.Join(Environment.NewLine, settingsLines);
    }
}
