using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Avalonia;
using Avalonia.Styling;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using htWriting.Contracts;
using htWriting.Helpers;
using htWriting.Models;

namespace htWriting.ViewModels;

public partial class MainViewModel : ViewModelBase
{
    private const string ThinkingBoundary = "<channel|>";
    private readonly IRewriteService _rewriteService;
    private readonly IClipboardService _clipboardService;
    private readonly IRewriteHistoryService _historyService;
    private readonly IAppSettingsService _settingsService;
    private readonly SemaphoreSlim _settingsSaveLock = new(1, 1);
    private readonly DispatcherTimer _settingsSaveTimer = new()
    {
        Interval = TimeSpan.FromMilliseconds(300)
    };
    private CancellationTokenSource? _rewriteCancellation;
    private AppSettings? _pendingSettings;
    private int _settingsVersion;
    private int _pendingSettingsVersion;
    private string _statusKey = "status.ready";
    private object?[] _statusArguments = [];

    [ObservableProperty]
    public partial UiLanguage UiLanguage { get; set; } = UiLanguage.Vietnamese;

    public bool IsVietnameseSelected
    {
        get => UiLanguage == UiLanguage.Vietnamese;
        set
        {
            if (value)
            {
                UiLanguage = UiLanguage.Vietnamese;
            }
        }
    }

    public bool IsEnglishSelected
    {
        get => UiLanguage == UiLanguage.English;
        set
        {
            if (value)
            {
                UiLanguage = UiLanguage.English;
            }
        }
    }

    public string StatusMessage => UiText.Get(UiLanguage, _statusKey, _statusArguments);

    partial void OnUiLanguageChanged(UiLanguage value)
    {
        OnPropertyChanged(nameof(IsVietnameseSelected));
        OnPropertyChanged(nameof(IsEnglishSelected));
        OnPropertyChanged(nameof(StatusMessage));
        OnPropertyChanged(nameof(ResultStyleLabel));
    }

    private void SetStatus(string key, params object?[] arguments)
    {
        _statusKey = key;
        _statusArguments = arguments;
        OnPropertyChanged(nameof(StatusMessage));
    }

    public void ReportHistoryOpenError(Exception exception) =>
        SetStatus("history.open_error", exception.Message);

    [ObservableProperty]
    public partial string? SelectedModel { get; set; }

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(FriendlyRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProfessionalRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(SummaryCommand))]
    [NotifyCanExecuteChangedFor(nameof(DetailedRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadImprovedCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadFormalCommand))]
    [NotifyCanExecuteChangedFor(nameof(TranslateCommand))]
    [NotifyCanExecuteChangedFor(nameof(ClearInputCommand))]
    [NotifyCanExecuteChangedFor(nameof(CopyInputCommand))]
    public partial string OriginalText { get; set; } = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(CopyResultCommand))]
    [NotifyCanExecuteChangedFor(nameof(ImportResultCommand))]
    [NotifyPropertyChangedFor(nameof(HasResultStyle))]
    public partial string RewrittenText { get; set; } = string.Empty;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(ResultStyleLabel))]
    [NotifyPropertyChangedFor(nameof(HasResultStyle))]
    public partial RewriteStyle? ResultStyle { get; set; }

    public string ResultStyleLabel => ResultStyle is { } style
        ? UiText.GetRewriteStyleName(UiLanguage, style)
        : string.Empty;

    public bool HasResultStyle => ResultStyle is not null && !string.IsNullOrEmpty(RewrittenText);

    [ObservableProperty]
    public partial string ThinkingText { get; set; } = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(FriendlyRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProfessionalRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(SummaryCommand))]
    [NotifyCanExecuteChangedFor(nameof(DetailedRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadImprovedCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadFormalCommand))]
    [NotifyCanExecuteChangedFor(nameof(TranslateCommand))]
    [NotifyCanExecuteChangedFor(nameof(ClearInputCommand))]
    [NotifyCanExecuteChangedFor(nameof(CopyInputCommand))]
    public partial bool IsBusy { get; set; }

    [ObservableProperty]
    public partial bool IsThinking { get; set; }

    [ObservableProperty]
    public partial bool EnableThinking { get; set; }

    [ObservableProperty]
    public partial bool UseModelConfigs { get; set; }

    [ObservableProperty]
    public partial bool UseGpu { get; set; }

    [ObservableProperty]
    public partial int GpuLayerCount { get; set; } = 15;

    [ObservableProperty]
    public partial int MaxTokens { get; set; } = 512;

    [ObservableProperty]
    public partial ThemeVariant CurrentTheme { get; set; } = ThemeVariant.Default;

    partial void OnCurrentThemeChanged(ThemeVariant value)
    {
        if (Application.Current is { } application)
        {
            application.RequestedThemeVariant = value;
        }
    }

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(TranslateCommand))]
    public partial Language SelectedTranslateTo { get; set; } = Language.None;

    [ObservableProperty]
    public partial Language SelectedInputLanguage { get; set; } = Language.None;

    [ObservableProperty]
    public partial int TopK { get; set; } = 40;

    [ObservableProperty]
    public partial double TypicalP { get; set; } = 1.0;

    [ObservableProperty]
    public partial double TopP { get; set; } = 0.9;

    [ObservableProperty]
    public partial double MinP { get; set; } = 0.08;

    [ObservableProperty]
    public partial double Temperature { get; set; } = 0.7;

    [ObservableProperty]
    public partial double RepeatPenalty { get; set; } = 1.0;

    [ObservableProperty]
    public partial double FrequencyPenalty { get; set; }

    [ObservableProperty]
    public partial double PresencePenalty { get; set; }

    [ObservableProperty]
    public partial int PenaltyCount { get; set; } = 64;

    public Array Languages { get; } = Enum.GetValues<Language>();

    public ObservableCollection<string> AvailableModels { get; } = [];

    public string ModelsDirectory { get; } = Path.Combine(AppContext.BaseDirectory, "Models");

    public ObservableCollection<string> SelectedGuidelines { get; } = [];

    public MainViewModel(
        IRewriteService rewriteService,
        IClipboardService clipboardService,
        IRewriteHistoryService historyService,
        IAppSettingsService settingsService)
    {
        _rewriteService = rewriteService;
        _clipboardService = clipboardService;
        _historyService = historyService;
        _settingsService = settingsService;
        Exception? settingsLoadError = null;
        try
        {
            ApplySettings(_settingsService.Load());
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or JsonException)
        {
            settingsLoadError = exception;
        }

        PropertyChanged += OnPropertyChanged;
        SelectedGuidelines.CollectionChanged += OnGuidelinesChanged;
        _settingsSaveTimer.Tick += OnSettingsSaveTimerTick;
        if (settingsLoadError is not null)
        {
            SetStatus("settings.load_error", settingsLoadError.Message);
        }
    }

    public async Task InitializeAfterShownAsync()
    {
        try
        {
            var availableModels = await Task.Run(() =>
            {
                if (!Directory.Exists(ModelsDirectory))
                {
                    return null;
                }

                return Directory.EnumerateFiles(ModelsDirectory)
                    .Where(path => string.Equals(
                        Path.GetExtension(path),
                        ".gguf",
                        StringComparison.OrdinalIgnoreCase))
                    .OrderBy(Path.GetFileName, StringComparer.OrdinalIgnoreCase)
                    .Select(Path.GetFileName)
                    .ToArray();
            });

            if (availableModels is null)
            {
                SetStatus("status.models_folder_missing", ModelsDirectory);
                return;
            }

            foreach (var model in availableModels)
            {
                if (model is not null)
                {
                    AvailableModels.Add(model);
                }
            }

            if (SelectedModel is null || !AvailableModels.Contains(SelectedModel))
            {
                SelectedModel = AvailableModels.FirstOrDefault();
            }

            if (SelectedModel is null)
            {
                SetStatus("status.models_not_found", ModelsDirectory);
                return;
            }

            await PreloadSelectedModelAsync();
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
        {
            SetStatus("status.models_read_error", exception.Message);
        }
    }

    public async Task PreloadSelectedModelAsync()
    {
        if (SelectedModel is null)
        {
            return;
        }

        var modelPath = Path.Combine(ModelsDirectory, SelectedModel);
        var gpuLayerCount = UseGpu ? GpuLayerCount : 0;
        SetStatus("status.model_loading");
        try
        {
            await _rewriteService.PreloadAsync(modelPath, gpuLayerCount);
            if (_statusKey == "status.model_loading")
            {
                SetStatus("status.ready");
            }
        }
        catch (Exception exception)
        {
            var detail = exception switch
            {
                PlatformNotSupportedException => UiText.Get(UiLanguage, "error.gpu_unavailable"),
                FileNotFoundException => UiText.Get(UiLanguage, "error.model_missing", modelPath),
                InvalidOperationException => UiText.Get(UiLanguage, "error.backend_init"),
                _ => exception.Message
            };
            SetStatus("status.model_load_error", detail);
        }
    }

    private void ApplySettings(AppSettings settings)
    {
        UiLanguage = Enum.IsDefined(settings.UiLanguage) ? settings.UiLanguage : UiLanguage.Vietnamese;
        SelectedInputLanguage = Enum.IsDefined(settings.SelectedInputLanguage)
            ? settings.SelectedInputLanguage
            : Language.None;
        SelectedTranslateTo = Enum.IsDefined(settings.SelectedTranslateTo)
            ? settings.SelectedTranslateTo
            : Language.None;
        SelectedModel = settings.SelectedModel;
        EnableThinking = settings.EnableThinking;
        UseModelConfigs = settings.UseModelConfigs;
        UseGpu = settings.UseGpu;
        GpuLayerCount = settings.GpuLayerCount;
        MaxTokens = settings.MaxTokens;
        CurrentTheme = settings.Theme switch
        {
            "Light" => ThemeVariant.Light,
            "Dark" => ThemeVariant.Dark,
            _ => ThemeVariant.Default
        };
        TopK = settings.TopK;
        TypicalP = settings.TypicalP;
        TopP = settings.TopP;
        MinP = settings.MinP;
        Temperature = settings.Temperature;
        RepeatPenalty = settings.RepeatPenalty;
        FrequencyPenalty = settings.FrequencyPenalty;
        PresencePenalty = settings.PresencePenalty;
        PenaltyCount = settings.PenaltyCount;
        SelectedGuidelines.Clear();
        foreach (var guideline in settings.AdditionalGuidelines ?? [])
        {
            if (!string.IsNullOrWhiteSpace(guideline))
            {
                SelectedGuidelines.Add(guideline);
            }
        }
    }

    private void OnPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(UiLanguage)
            or nameof(SelectedModel)
            or nameof(SelectedTranslateTo)
            or nameof(SelectedInputLanguage)
            or nameof(EnableThinking)
            or nameof(UseModelConfigs)
            or nameof(UseGpu)
            or nameof(GpuLayerCount)
            or nameof(MaxTokens)
            or nameof(CurrentTheme)
            or nameof(TopK)
            or nameof(TypicalP)
            or nameof(TopP)
            or nameof(MinP)
            or nameof(Temperature)
            or nameof(RepeatPenalty)
            or nameof(FrequencyPenalty)
            or nameof(PresencePenalty)
            or nameof(PenaltyCount))
        {
            SaveSettings();
        }
    }

    private void OnGuidelinesChanged(object? sender, NotifyCollectionChangedEventArgs e) => SaveSettings();

    private void SaveSettings()
    {
        _pendingSettings = CreateSettingsSnapshot();
        _pendingSettingsVersion = ++_settingsVersion;
        _settingsSaveTimer.Stop();
        _settingsSaveTimer.Start();
    }

    private AppSettings CreateSettingsSnapshot() => new()
    {
        UiLanguage = UiLanguage,
        SelectedInputLanguage = SelectedInputLanguage,
        SelectedTranslateTo = SelectedTranslateTo,
        SelectedModel = SelectedModel,
        EnableThinking = EnableThinking,
        UseModelConfigs = UseModelConfigs,
        UseGpu = UseGpu,
        GpuLayerCount = GpuLayerCount,
        MaxTokens = MaxTokens,
        Theme = CurrentTheme == ThemeVariant.Light
            ? "Light"
            : CurrentTheme == ThemeVariant.Dark ? "Dark" : "Default",
        TopK = TopK,
        TypicalP = TypicalP,
        TopP = TopP,
        MinP = MinP,
        Temperature = Temperature,
        RepeatPenalty = RepeatPenalty,
        FrequencyPenalty = FrequencyPenalty,
        PresencePenalty = PresencePenalty,
        PenaltyCount = PenaltyCount,
        AdditionalGuidelines = SelectedGuidelines.ToArray()
    };

    private async void OnSettingsSaveTimerTick(object? sender, EventArgs e)
    {
        _settingsSaveTimer.Stop();
        var settings = _pendingSettings;
        var version = _pendingSettingsVersion;
        _pendingSettings = null;
        if (settings is null)
        {
            return;
        }

        try
        {
            await _settingsSaveLock.WaitAsync();
            try
            {
                if (version == Volatile.Read(ref _settingsVersion))
                {
                    await Task.Run(() => _settingsService.Save(settings));
                }
            }
            finally
            {
                _settingsSaveLock.Release();
            }
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or JsonException)
        {
            SetStatus("settings.save_error", exception.Message);
        }
    }

    public void FlushPendingSettings()
    {
        _settingsSaveTimer.Stop();
        if (_pendingSettings is null && _settingsSaveLock.CurrentCount > 0)
        {
            return;
        }

        var settings = CreateSettingsSnapshot();
        var version = _settingsVersion;
        _pendingSettings = null;

        _settingsSaveLock.Wait();
        try
        {
            if (version == Volatile.Read(ref _settingsVersion))
            {
                _settingsService.Save(settings);
            }
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or JsonException)
        {
            SetStatus("settings.save_error", exception.Message);
        }
        finally
        {
            _settingsSaveLock.Release();
        }
    }

    private bool CanRewrite() => !IsBusy && !string.IsNullOrWhiteSpace(OriginalText);

    private bool CanTranslate() => CanRewrite() && SelectedTranslateTo != Language.None;

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task FriendlyRewriteAsync() => RewriteAsync(RewriteStyle.Friendly, "status.rewrite.friendly");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task ProfessionalRewriteAsync() => RewriteAsync(RewriteStyle.Professional, "status.rewrite.professional");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task SummaryAsync() => RewriteAsync(RewriteStyle.ConciseSummary, "status.rewrite.summary");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task DetailedRewriteAsync() => RewriteAsync(RewriteStyle.Detailed, "status.rewrite.detailed");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task ProofreadAsync() => RewriteAsync(RewriteStyle.Proofread, "status.rewrite.proofread");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task ProofreadImprovedAsync() => RewriteAsync(RewriteStyle.ProofreadImproved, "status.rewrite.proofread_improved");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task ProofreadFormalAsync() => RewriteAsync(RewriteStyle.ProofreadFormal, "status.rewrite.proofread_formal");

    [RelayCommand(CanExecute = nameof(CanTranslate))]
    private Task TranslateAsync() => RewriteAsync(RewriteStyle.TranslateOnly, "status.rewrite.translate");

    [RelayCommand]
    private void CancelRewrite() => _rewriteCancellation?.Cancel();

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private void ClearInput() => OriginalText = string.Empty;

    private static int FindThinkingBoundary(StringBuilder text)
    {
        var lastStart = text.Length - ThinkingBoundary.Length;
        if (lastStart < 0)
        {
            return -1;
        }

        for (var start = 0; start <= lastStart; start++)
        {
            var matches = true;
            for (var offset = 0; offset < ThinkingBoundary.Length; offset++)
            {
                if (text[start + offset] != ThinkingBoundary[offset])
                {
                    matches = false;
                    break;
                }
            }

            if (matches)
            {
                return start;
            }
        }

        return -1;
    }

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private async Task CopyInputAsync()
    {
        try
        {
            await _clipboardService.SetTextAsync(OriginalText);
            SetStatus("status.copied_original");
        }
        catch (Exception exception)
        {
            SetStatus("status.copy_original_error", exception.Message);
        }
    }

    [RelayCommand]
    private async Task PasteInputAsync()
    {
        try
        {
            var text = await _clipboardService.GetTextAsync();
            if (text is not null)
            {
                OriginalText = text;
            }
        }
        catch (Exception exception)
        {
            SetStatus("status.clipboard_read_error", exception.Message);
        }
    }

    [RelayCommand(CanExecute = nameof(CanCopyResult))]
    private async Task CopyResultAsync()
    {
        try
        {
            await _clipboardService.SetTextAsync(RewrittenText);
            SetStatus("status.copied_result");
        }
        catch (Exception exception)
        {
            SetStatus("status.copy_result_error", exception.Message);
        }
    }

    private bool CanCopyResult() => !string.IsNullOrEmpty(RewrittenText);

    [RelayCommand(CanExecute = nameof(CanCopyResult))]
    private void ImportResult()
    {
        OriginalText = RewrittenText;
        RewrittenText = string.Empty;
        ResultStyle = null;
    }

    private async Task RewriteAsync(RewriteStyle style, string statusKey)
    {
        if (IsBusy || string.IsNullOrWhiteSpace(OriginalText))
        {
            return;
        }

        if (SelectedInputLanguage == Language.None)
        {
            SetStatus("status.choose_input_language");
            return;
        }

        if (SelectedModel is null)
        {
            SetStatus("status.choose_model", ModelsDirectory);
            return;
        }

        if (style == RewriteStyle.TranslateOnly && SelectedTranslateTo == Language.None)
        {
            SetStatus("status.choose_target_language");
            return;
        }

        _rewriteCancellation?.Dispose();
        _rewriteCancellation = new CancellationTokenSource();
        var cancellationToken = _rewriteCancellation.Token;
        var inputText = OriginalText;
        var modelPath = Path.Combine(ModelsDirectory, SelectedModel);
        var useGpu = UseGpu;
        var configuredGpuLayerCount = GpuLayerCount;
        var gpuLayerCount = useGpu ? configuredGpuLayerCount : 0;
        var maxTokens = MaxTokens;
        var inputLanguage = SelectedInputLanguage;
        var translateTo = SelectedTranslateTo;
        var enableThinking = EnableThinking;
        var useModelConfigs = UseModelConfigs;
        var guidelines = SelectedGuidelines.ToArray();

        IsBusy = true;
        var startedAt = Stopwatch.GetTimestamp();
        IsThinking = enableThinking;
        ThinkingText = string.Empty;
        RewrittenText = string.Empty;
        ResultStyle = style;
        SetStatus(statusKey);
        var thinkingBuffer = new StringBuilder();
        var resultBuffer = new StringBuilder();
        var pendingBuffer = new StringBuilder();
        var finalThinking = string.Empty;

        try
        {
            var sampling = new ModelSamplingPipeline
            {
                TopK = TopK,
                TypicalP = TypicalP,
                TopP = TopP,
                MinP = MinP,
                Temperature = Temperature,
                RepeatPenalty = RepeatPenalty,
                FrequencyPenalty = FrequencyPenalty,
                PresencePenalty = PresencePenalty,
                PenaltyCount = PenaltyCount
            };
            var modelSettings = new RewriteModelSettings
            {
                ModelName = SelectedModel,
                UseGpu = useGpu,
                GpuLayerCount = configuredGpuLayerCount,
                MaxTokens = maxTokens,
                EnableThinking = enableThinking,
                UseCustomSampling = useModelConfigs,
                Sampling = sampling,
                AdditionalGuidelines = guidelines
            };

            await Task.Run(async () =>
            {
                var isThinking = enableThinking;
                var thinkingBoundaryFound = false;
                var lastUiUpdate = Stopwatch.GetTimestamp();
                await foreach (var token in _rewriteService.RewriteTextAsync(
                    inputText,
                    modelPath,
                    gpuLayerCount,
                    maxTokens,
                    style,
                    inputLanguage,
                    translateTo,
                    useModelConfigs,
                    sampling,
                    enableThinking,
                    guidelines,
                    cancellationToken))
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (isThinking)
                    {
                        pendingBuffer.Append(token);
                        var boundaryIndex = FindThinkingBoundary(pendingBuffer);
                        if (boundaryIndex >= 0)
                        {
                            thinkingBuffer.Append(pendingBuffer, 0, boundaryIndex);
                            resultBuffer.Append(pendingBuffer, boundaryIndex + ThinkingBoundary.Length,
                                pendingBuffer.Length - boundaryIndex - ThinkingBoundary.Length);
                            pendingBuffer.Clear();
                            isThinking = false;
                            thinkingBoundaryFound = true;
                        }
                        else
                        {
                            var safeLength = Math.Max(0, pendingBuffer.Length - ThinkingBoundary.Length + 1);
                            if (safeLength > 0)
                            {
                                thinkingBuffer.Append(pendingBuffer, 0, safeLength);
                                pendingBuffer.Remove(0, safeLength);
                            }
                        }
                    }
                    else
                    {
                        resultBuffer.Append(token);
                    }

                    if (Stopwatch.GetElapsedTime(lastUiUpdate) >= TimeSpan.FromMilliseconds(100))
                    {
                        var thinking = thinkingBuffer.ToString();
                        var result = resultBuffer.ToString();
                        await Dispatcher.UIThread.InvokeAsync(() =>
                        {
                            IsThinking = isThinking;
                            ThinkingText = thinking;
                            RewrittenText = result;
                        });
                        lastUiUpdate = Stopwatch.GetTimestamp();
                    }
                }

                if (isThinking && pendingBuffer.Length > 0)
                {
                    thinkingBuffer.Append(pendingBuffer);
                }

                if (isThinking)
                {
                    resultBuffer.Append(thinkingBuffer);
                    isThinking = false;
                }

                finalThinking = thinkingBoundaryFound ? thinkingBuffer.ToString() : string.Empty;
                var finalResult = resultBuffer.ToString();
                await Dispatcher.UIThread.InvokeAsync(() =>
                {
                    IsThinking = isThinking;
                    ThinkingText = finalThinking;
                    RewrittenText = finalResult;
                });
            }, cancellationToken);

            SetStatus("status.completed");
            if (!string.IsNullOrWhiteSpace(RewrittenText))
            {
                try
                {
                    await _historyService.SaveAsync(new RewriteHistoryEntry(
                        0,
                        DateTimeOffset.UtcNow,
                        inputText,
                        RewrittenText,
                        inputLanguage,
                        style == RewriteStyle.TranslateOnly ? translateTo : inputLanguage,
                        style,
                        Stopwatch.GetElapsedTime(startedAt),
                        finalThinking,
                        modelSettings));
                }
                catch (Exception exception)
                {
                    SetStatus("history.save_error", exception.Message);
                }
            }
        }
        catch (OperationCanceledException)
        {
            SetStatus("status.cancelled");
        }
        catch (Exception exception)
        {
            var detail = exception switch
            {
                PlatformNotSupportedException => UiText.Get(UiLanguage, "error.gpu_unavailable"),
                FileNotFoundException => UiText.Get(UiLanguage, "error.model_missing", modelPath),
                InvalidOperationException => UiText.Get(UiLanguage, "error.backend_init"),
                _ => exception.Message
            };
            SetStatus("status.rewrite_error", detail);
        }
        finally
        {
            IsBusy = false;
            IsThinking = false;
            _rewriteCancellation?.Dispose();
            _rewriteCancellation = null;
        }
    }
}
