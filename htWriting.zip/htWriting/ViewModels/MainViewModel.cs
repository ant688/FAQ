using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
using Avalonia;
using Avalonia.Styling;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using htWriting.Contracts;
using htWriting.Helpers;
using htWriting.Models;

namespace htWriting.ViewModels;

public partial class MainViewModel : ViewModelBase
{
    private const string ThinkingBoundary = "<channel|>";
    private readonly IRewriteService _rewriteService;
    private readonly IClipboardService _clipboardService;
    private readonly IRewriteHistoryService _historyService;
    private CancellationTokenSource? _rewriteCancellation;
    private string _statusKey = "status.ready";
    private object?[] _statusArguments = [];

    [ObservableProperty]
    public partial UiLanguage UiLanguage { get; set; } = UiLanguage.Vietnamese;

    public bool IsVietnameseSelected
    {
        get => UiLanguage == UiLanguage.Vietnamese;
        set
        {
            if (value)
            {
                UiLanguage = UiLanguage.Vietnamese;
            }
        }
    }

    public bool IsEnglishSelected
    {
        get => UiLanguage == UiLanguage.English;
        set
        {
            if (value)
            {
                UiLanguage = UiLanguage.English;
            }
        }
    }

    public string StatusMessage => UiText.Get(UiLanguage, _statusKey, _statusArguments);

    partial void OnUiLanguageChanged(UiLanguage value)
    {
        OnPropertyChanged(nameof(IsVietnameseSelected));
        OnPropertyChanged(nameof(IsEnglishSelected));
        OnPropertyChanged(nameof(StatusMessage));
        OnPropertyChanged(nameof(ResultStyleLabel));
    }

    private void SetStatus(string key, params object?[] arguments)
    {
        _statusKey = key;
        _statusArguments = arguments;
        OnPropertyChanged(nameof(StatusMessage));
    }

    public void ReportHistoryOpenError(Exception exception) =>
        SetStatus("history.open_error", exception.Message);

    [ObservableProperty]
    public partial string? SelectedModel { get; set; }

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(FriendlyRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProfessionalRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(SummaryCommand))]
    [NotifyCanExecuteChangedFor(nameof(DetailedRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadImprovedCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadFormalCommand))]
    [NotifyCanExecuteChangedFor(nameof(TranslateCommand))]
    [NotifyCanExecuteChangedFor(nameof(ClearInputCommand))]
    [NotifyCanExecuteChangedFor(nameof(CopyInputCommand))]
    public partial string OriginalText { get; set; } = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(CopyResultCommand))]
    [NotifyCanExecuteChangedFor(nameof(ImportResultCommand))]
    [NotifyPropertyChangedFor(nameof(HasResultStyle))]
    public partial string RewrittenText { get; set; } = string.Empty;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(ResultStyleLabel))]
    [NotifyPropertyChangedFor(nameof(HasResultStyle))]
    public partial RewriteStyle? ResultStyle { get; set; }

    public string ResultStyleLabel => ResultStyle is { } style
        ? UiText.GetRewriteStyleName(UiLanguage, style)
        : string.Empty;

    public bool HasResultStyle => ResultStyle is not null && !string.IsNullOrEmpty(RewrittenText);

    [ObservableProperty]
    public partial string ThinkingText { get; set; } = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(FriendlyRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProfessionalRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(SummaryCommand))]
    [NotifyCanExecuteChangedFor(nameof(DetailedRewriteCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadImprovedCommand))]
    [NotifyCanExecuteChangedFor(nameof(ProofreadFormalCommand))]
    [NotifyCanExecuteChangedFor(nameof(TranslateCommand))]
    [NotifyCanExecuteChangedFor(nameof(ClearInputCommand))]
    [NotifyCanExecuteChangedFor(nameof(CopyInputCommand))]
    public partial bool IsBusy { get; set; }

    [ObservableProperty]
    public partial bool IsThinking { get; set; }

    [ObservableProperty]
    public partial bool EnableThinking { get; set; }

    [ObservableProperty]
    public partial bool UseModelConfigs { get; set; }

    [ObservableProperty]
    public partial bool UseGpu { get; set; }

    [ObservableProperty]
    public partial int GpuLayerCount { get; set; } = 15;

    [ObservableProperty]
    public partial int MaxTokens { get; set; } = 512;

    [ObservableProperty]
    public partial ThemeVariant CurrentTheme { get; set; } = ThemeVariant.Default;

    partial void OnCurrentThemeChanged(ThemeVariant value)
    {
        if (Application.Current is { } application)
        {
            application.RequestedThemeVariant = value;
        }
    }

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(TranslateCommand))]
    public partial Language SelectedTranslateTo { get; set; } = Language.None;

    [ObservableProperty]
    public partial Language SelectedInputLanguage { get; set; } = Language.None;

    [ObservableProperty]
    public partial int TopK { get; set; } = 40;

    [ObservableProperty]
    public partial double TypicalP { get; set; } = 1.0;

    [ObservableProperty]
    public partial double TopP { get; set; } = 0.9;

    [ObservableProperty]
    public partial double MinP { get; set; } = 0.08;

    [ObservableProperty]
    public partial double Temperature { get; set; } = 0.7;

    [ObservableProperty]
    public partial double RepeatPenalty { get; set; } = 1.0;

    [ObservableProperty]
    public partial double FrequencyPenalty { get; set; }

    [ObservableProperty]
    public partial double PresencePenalty { get; set; }

    [ObservableProperty]
    public partial int PenaltyCount { get; set; } = 64;

    public Array Languages { get; } = Enum.GetValues<Language>();

    public ObservableCollection<string> AvailableModels { get; } = [];

    public string ModelsDirectory { get; } = Path.Combine(AppContext.BaseDirectory, "Models");

    public ObservableCollection<string> SelectedGuidelines { get; } = [];

    public MainViewModel(
        IRewriteService rewriteService,
        IClipboardService clipboardService,
        IRewriteHistoryService historyService)
    {
        _rewriteService = rewriteService;
        _clipboardService = clipboardService;
        _historyService = historyService;
        LoadAvailableModels();
    }

    private void LoadAvailableModels()
    {
        if (!Directory.Exists(ModelsDirectory))
        {
            SetStatus("status.models_folder_missing", ModelsDirectory);
            return;
        }

        try
        {
            foreach (var modelPath in Directory.EnumerateFiles(ModelsDirectory)
                         .Where(path => string.Equals(Path.GetExtension(path), ".gguf", StringComparison.OrdinalIgnoreCase))
                         .OrderBy(Path.GetFileName, StringComparer.OrdinalIgnoreCase))
            {
                AvailableModels.Add(Path.GetFileName(modelPath));
            }

            SelectedModel = AvailableModels.FirstOrDefault();
            if (SelectedModel is null)
            {
                SetStatus("status.models_not_found", ModelsDirectory);
            }
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
        {
            SetStatus("status.models_read_error", exception.Message);
        }
    }

    private bool CanRewrite() => !IsBusy && !string.IsNullOrWhiteSpace(OriginalText);

    private bool CanTranslate() => CanRewrite() && SelectedTranslateTo != Language.None;

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task FriendlyRewriteAsync() => RewriteAsync(RewriteStyle.Friendly, "status.rewrite.friendly");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task ProfessionalRewriteAsync() => RewriteAsync(RewriteStyle.Professional, "status.rewrite.professional");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task SummaryAsync() => RewriteAsync(RewriteStyle.ConciseSummary, "status.rewrite.summary");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task DetailedRewriteAsync() => RewriteAsync(RewriteStyle.Detailed, "status.rewrite.detailed");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task ProofreadAsync() => RewriteAsync(RewriteStyle.Proofread, "status.rewrite.proofread");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task ProofreadImprovedAsync() => RewriteAsync(RewriteStyle.ProofreadImproved, "status.rewrite.proofread_improved");

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private Task ProofreadFormalAsync() => RewriteAsync(RewriteStyle.ProofreadFormal, "status.rewrite.proofread_formal");

    [RelayCommand(CanExecute = nameof(CanTranslate))]
    private Task TranslateAsync() => RewriteAsync(RewriteStyle.TranslateOnly, "status.rewrite.translate");

    [RelayCommand]
    private void CancelRewrite() => _rewriteCancellation?.Cancel();

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private void ClearInput() => OriginalText = string.Empty;

    [RelayCommand(CanExecute = nameof(CanRewrite))]
    private async Task CopyInputAsync()
    {
        try
        {
            await _clipboardService.SetTextAsync(OriginalText);
            SetStatus("status.copied_original");
        }
        catch (Exception exception)
        {
            SetStatus("status.copy_original_error", exception.Message);
        }
    }

    [RelayCommand]
    private async Task PasteInputAsync()
    {
        try
        {
            var text = await _clipboardService.GetTextAsync();
            if (text is not null)
            {
                OriginalText = text;
            }
        }
        catch (Exception exception)
        {
            SetStatus("status.clipboard_read_error", exception.Message);
        }
    }

    [RelayCommand(CanExecute = nameof(CanCopyResult))]
    private async Task CopyResultAsync()
    {
        try
        {
            await _clipboardService.SetTextAsync(RewrittenText);
            SetStatus("status.copied_result");
        }
        catch (Exception exception)
        {
            SetStatus("status.copy_result_error", exception.Message);
        }
    }

    private bool CanCopyResult() => !string.IsNullOrEmpty(RewrittenText);

    [RelayCommand(CanExecute = nameof(CanCopyResult))]
    private void ImportResult()
    {
        OriginalText = RewrittenText;
        RewrittenText = string.Empty;
        ResultStyle = null;
    }

    private async Task RewriteAsync(RewriteStyle style, string statusKey)
    {
        if (IsBusy || string.IsNullOrWhiteSpace(OriginalText))
        {
            return;
        }

        if (SelectedInputLanguage == Language.None)
        {
            SetStatus("status.choose_input_language");
            return;
        }

        if (SelectedModel is null)
        {
            SetStatus("status.choose_model", ModelsDirectory);
            return;
        }

        if (style == RewriteStyle.TranslateOnly && SelectedTranslateTo == Language.None)
        {
            SetStatus("status.choose_target_language");
            return;
        }

        _rewriteCancellation?.Dispose();
        _rewriteCancellation = new CancellationTokenSource();
        var cancellationToken = _rewriteCancellation.Token;
        var inputText = OriginalText;
        var modelPath = Path.Combine(ModelsDirectory, SelectedModel);
        var gpuLayerCount = UseGpu ? GpuLayerCount : 0;
        var maxTokens = MaxTokens;
        var inputLanguage = SelectedInputLanguage;
        var translateTo = SelectedTranslateTo;
        var enableThinking = EnableThinking;
        var useModelConfigs = UseModelConfigs;
        var guidelines = SelectedGuidelines.ToArray();

        IsBusy = true;
        var startedAt = Stopwatch.GetTimestamp();
        IsThinking = enableThinking;
        ThinkingText = string.Empty;
        RewrittenText = string.Empty;
        ResultStyle = style;
        SetStatus(statusKey);
        var thinkingBuffer = new StringBuilder();
        var resultBuffer = new StringBuilder();
        var pendingText = string.Empty;

        try
        {
            var sampling = new ModelSamplingPipeline
            {
                TopK = TopK,
                TypicalP = TypicalP,
                TopP = TopP,
                MinP = MinP,
                Temperature = Temperature,
                RepeatPenalty = RepeatPenalty,
                FrequencyPenalty = FrequencyPenalty,
                PresencePenalty = PresencePenalty,
                PenaltyCount = PenaltyCount
            };

            await Task.Run(async () =>
            {
                var isThinking = enableThinking;
                var thinkingBoundaryFound = false;
                var lastUiUpdate = Stopwatch.GetTimestamp();
                await foreach (var token in _rewriteService.RewriteTextAsync(
                    inputText,
                    modelPath,
                    gpuLayerCount,
                    maxTokens,
                    style,
                    inputLanguage,
                    translateTo,
                    useModelConfigs,
                    sampling,
                    enableThinking,
                    guidelines,
                    cancellationToken))
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (isThinking)
                    {
                        pendingText += token;
                        var boundaryIndex = pendingText.IndexOf(ThinkingBoundary, StringComparison.Ordinal);
                        if (boundaryIndex >= 0)
                        {
                            thinkingBuffer.Append(pendingText.AsSpan(0, boundaryIndex));
                            resultBuffer.Append(pendingText.AsSpan(boundaryIndex + ThinkingBoundary.Length));
                            pendingText = string.Empty;
                            isThinking = false;
                            thinkingBoundaryFound = true;
                        }
                        else
                        {
                            var safeLength = Math.Max(0, pendingText.Length - ThinkingBoundary.Length + 1);
                            if (safeLength > 0)
                            {
                                thinkingBuffer.Append(pendingText.AsSpan(0, safeLength));
                                pendingText = pendingText[safeLength..];
                            }
                        }
                    }
                    else
                    {
                        resultBuffer.Append(token);
                    }

                    if (Stopwatch.GetElapsedTime(lastUiUpdate) >= TimeSpan.FromMilliseconds(100))
                    {
                        var thinking = thinkingBuffer.ToString();
                        var result = resultBuffer.ToString();
                        await Dispatcher.UIThread.InvokeAsync(() =>
                        {
                            IsThinking = isThinking;
                            ThinkingText = thinking;
                            RewrittenText = result;
                        });
                        lastUiUpdate = Stopwatch.GetTimestamp();
                    }
                }

                if (isThinking && pendingText.Length > 0)
                {
                    thinkingBuffer.Append(pendingText);
                }

                if (isThinking)
                {
                    resultBuffer.Append(thinkingBuffer);
                    isThinking = false;
                }

                var finalThinking = thinkingBoundaryFound ? thinkingBuffer.ToString() : string.Empty;
                var finalResult = resultBuffer.ToString();
                await Dispatcher.UIThread.InvokeAsync(() =>
                {
                    IsThinking = isThinking;
                    ThinkingText = finalThinking;
                    RewrittenText = finalResult;
                });
            }, cancellationToken);

            SetStatus("status.completed");
            if (!string.IsNullOrWhiteSpace(RewrittenText))
            {
                try
                {
                    await _historyService.SaveAsync(new RewriteHistoryEntry(
                        0,
                        DateTimeOffset.UtcNow,
                        inputText,
                        RewrittenText,
                        inputLanguage,
                        style == RewriteStyle.TranslateOnly ? translateTo : inputLanguage,
                        style,
                        Stopwatch.GetElapsedTime(startedAt)));
                }
                catch (Exception exception)
                {
                    SetStatus("history.save_error", exception.Message);
                }
            }
        }
        catch (OperationCanceledException)
        {
            SetStatus("status.cancelled");
        }
        catch (Exception exception)
        {
            var detail = exception switch
            {
                PlatformNotSupportedException => UiText.Get(UiLanguage, "error.gpu_unavailable"),
                FileNotFoundException => UiText.Get(UiLanguage, "error.model_missing", modelPath),
                InvalidOperationException => UiText.Get(UiLanguage, "error.backend_init"),
                _ => exception.Message
            };
            SetStatus("status.rewrite_error", detail);
        }
        finally
        {
            IsBusy = false;
            IsThinking = false;
            _rewriteCancellation?.Dispose();
            _rewriteCancellation = null;
        }
    }
}
