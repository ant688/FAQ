﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace htWriting.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
