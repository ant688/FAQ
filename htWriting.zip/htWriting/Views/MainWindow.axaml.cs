using Avalonia.Controls;
using Avalonia.Interactivity;
using htWriting.ViewModels;
using Microsoft.Extensions.DependencyInjection;

namespace htWriting.Views;

public partial class MainWindow : Window
{
    private IServiceProvider? _services;

    public MainWindow()
    {
        InitializeComponent();
        Opened += OnOpened;
        Closing += OnClosing;
    }

    public MainWindow(MainViewModel viewModel, IServiceProvider services)
        : this()
    {
        DataContext = viewModel;
        _services = services;
    }

    private async void OnOpened(object? sender, EventArgs e)
    {
        if (DataContext is MainViewModel viewModel)
        {
            await viewModel.InitializeAfterShownAsync();
        }
    }

    private void OnClosing(object? sender, EventArgs e)
    {
        if (DataContext is MainViewModel viewModel)
        {
            viewModel.FlushPendingSettings();
        }
    }

    private void OpenHistoryClick(object? sender, RoutedEventArgs e)
    {
        if (DataContext is not MainViewModel mainViewModel)
        {
            return;
        }

        try
        {
            if (_services is null)
            {
                throw new InvalidOperationException("The application services are unavailable.");
            }

            var historyWindow = _services.GetRequiredService<HistoryWindow>();
            if (historyWindow.DataContext is not HistoryViewModel historyViewModel)
            {
                throw new InvalidOperationException("The history view model was not initialized.");
            }

            historyViewModel.UiLanguage = mainViewModel.UiLanguage;
            historyWindow.Show(this);
        }
        catch (Exception exception)
        {
            mainViewModel.ReportHistoryOpenError(exception);
        }
    }
}