using OrtSummarizerConsole.Services;

if (args.Length == 0 || args.Contains("--help") || args.Contains("-h"))
{
    PrintHelp();
    return;
}

var options = Options.Parse(args);
if (string.IsNullOrWhiteSpace(options.InputPath) || string.IsNullOrWhiteSpace(options.ModelDir))
{
    Console.Error.WriteLine("❌ Missing --input or --model-dir. Run with --help for usage.");
    return;
}
if (!File.Exists(options.InputPath))
{
    Console.Error.WriteLine($"❌ Input file not found: {options.InputPath}");
    return;
}
if (!Directory.Exists(options.ModelDir))
{
    Console.Error.WriteLine($"❌ Model directory not found: {options.ModelDir}");
    return;
}

// 1) Load text (.txt or .pdf)
Console.WriteLine("📥 Reading input...");
var extractor = new TextExtractor();
var text = await extractor.ReadAsTextAsync(options.InputPath);

if (string.IsNullOrWhiteSpace(text))
{
    Console.Error.WriteLine("❌ No text extracted from input.");
    return;
}

// 2) Chunking
Console.WriteLine("✂️ Chunking...");
var chunker = new Chunker(tokenBudgetPerChunk: options.TokensPerChunk);
var chunks = chunker.Split(text);

Console.WriteLine($"📦 {chunks.Count} chunks (~{options.TokensPerChunk} tokens each target).");

// 3) Map-Reduce with ORT-GenAI
Console.WriteLine("🧠 Initializing ORT-GenAI...");
using var summarizer = new OrtGenAiSummarizer(options.ModelDir, options);

Console.WriteLine("🗺️ Map phase (summarizing chunks)...");
var mapSummaries = new List<string>();
int idx = 0;
foreach (var c in chunks)
{
    idx++;
    Console.WriteLine($"   • Chunk {idx}/{chunks.Count}...");
    var sum = await summarizer.SummarizeChunkAsync(c);
    mapSummaries.Add(sum.Trim());
}

// 4) Reduce
Console.WriteLine("🧩 Reduce phase (merging summaries)...");
var finalSummary = await summarizer.ReduceAsync(mapSummaries);

// 5) Output
var outPath = options.OutputPath;
if (string.IsNullOrWhiteSpace(outPath))
{
    var ext = Path.GetExtension(options.InputPath).ToLowerInvariant() == ".md" ? ".txt" : ".md";
    outPath = Path.ChangeExtension(options.InputPath, ext);
}
await File.WriteAllTextAsync(outPath, finalSummary);
Console.WriteLine($"✅ Done. Wrote: {outPath}");


static void PrintHelp()
{
    Console.WriteLine(@"
ORT Summarizer (Console, .NET 8)
Usage:
  dotnet run -- --input <path.pdf|path.txt> --model-dir <ort_genai_model_dir> [--out <out.md|out.txt>]
              [--tokens-per-chunk 800] [--max-new-tokens 256] [--temperature 0.2] [--top-p 0.9]

Examples:
  dotnet run -- --input sample.pdf --model-dir C:\models\phi3-mini\directml-int4 --out summary.md
  dotnet run -- --input note.txt  --model-dir ./models/cpu-int4 --tokens-per-chunk 900

Notes:
- Install ONE of: Microsoft.ML.OnnxRuntimeGenAI (CPU), .DirectML (Windows GPU), or .Cuda (NVIDIA).
- The model directory should be an ORT-GenAI compatible folder (contains onnx, tokenizer.json, etc.).
");
}

public record Options
{
    public string InputPath { get; init; } = "";
    public string ModelDir { get; init; } = "";
    public string? OutputPath { get; init; }
    public int TokensPerChunk { get; init; } = 900;
    public int MaxNewTokens { get; init; } = 256;
    public double Temperature { get; init; } = 0.2;
    public double TopP { get; init; } = 0.9;

    public static Options Parse(string[] args)
    {
        string? input = null, modelDir = null, output = null;
        int tokensPerChunk = 900, maxNew = 256;
        double temp = 0.2, topP = 0.9;

        for (int i = 0; i < args.Length; i++)
        {
            string a = args[i];
            string? Next() => (i + 1) < args.Length ? args[++i] : null;

            switch (a)
            {
                case "--input": input = Next(); break;
                case "--model-dir": modelDir = Next(); break;
                case "--out": output = Next(); break;
                case "--tokens-per-chunk": tokensPerChunk = int.Parse(Next() ?? "900"); break;
                case "--max-new-tokens": maxNew = int.Parse(Next() ?? "256"); break;
                case "--temperature": temp = double.Parse(Next() ?? "0.2"); break;
                case "--top-p": topP = double.Parse(Next() ?? "0.9"); break;
            }
        }

        return new Options
        {
            InputPath = input ?? "",
            ModelDir = modelDir ?? "",
            OutputPath = output,
            TokensPerChunk = tokensPerChunk,
            MaxNewTokens = maxNew,
            Temperature = temp,
            TopP = topP
        };
    }
}
