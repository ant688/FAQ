using System.Text;

namespace OrtSummarizerConsole.Services;

public class Chunker
{
    private readonly int _tokenBudgetPerChunk;

    public Chunker(int tokenBudgetPerChunk = 900)
    {
        _tokenBudgetPerChunk = Math.Max(200, tokenBudgetPerChunk);
    }

    public List<string> Split(string text)
    {
        // Use paragraph-based splitting; approximate tokens by chars/4
        var paras = text.Replace("\r\n", "\n").Split(new[] { "\n\n" }, StringSplitOptions.RemoveEmptyEntries);

        var chunks = new List<string>();
        var buf = new StringBuilder();
        int budget = 0;
        foreach (var p in paras)
        {
            var ptoks = EstimateTokens(p);
            if (budget + ptoks > _tokenBudgetPerChunk && buf.Length > 0)
            {
                chunks.Add(buf.ToString().Trim());
                buf.Clear();
                budget = 0;
            }
            buf.AppendLine(p.Trim());
            buf.AppendLine();
            budget += ptoks;
        }
        if (buf.Length > 0) chunks.Add(buf.ToString().Trim());

        // For very long single paragraphs, hard split by sentences
        var refined = new List<string>();
        foreach (var c in chunks)
        {
            if (EstimateTokens(c) <= _tokenBudgetPerChunk) { refined.Add(c); continue; }
            // naive sentence split
            var sentences = c.Split(new[] { ". ", "? ", "! " }, StringSplitOptions.RemoveEmptyEntries);
            var b = new StringBuilder();
            int bTok = 0;
            foreach (var s in sentences)
            {
                var sTok = EstimateTokens(s);
                if (bTok + sTok > _tokenBudgetPerChunk && b.Length > 0)
                {
                    refined.Add(b.ToString().Trim());
                    b.Clear();
                    bTok = 0;
                }
                b.Append(s.Trim());
                b.Append(". ");
                bTok += sTok;
            }
            if (b.Length > 0) refined.Add(b.ToString().Trim());
        }
        return refined;
    }

    private static int EstimateTokens(string s)
    {
        // quick heuristic: ~4 chars/token (works reasonably for Latin/VNese)
        var len = s?.Length ?? 0;
        return Math.Max(1, len / 4);
    }
}
