using UglyToad.PdfPig;
using UglyToad.PdfPig.DocumentLayoutAnalysis.TextExtractor;
using System.Text;

namespace OrtSummarizerConsole.Services;

public class TextExtractor
{
    public async Task<string> ReadAsTextAsync(string path)
    {
        var ext = Path.GetExtension(path).ToLowerInvariant();
        if (ext == ".pdf")
        {
            return await Task.Run(() => ExtractPdf(path));
        }
        else
        {
            return await File.ReadAllTextAsync(path);
        }
    }

    private string ExtractPdf(string path)
    {
        var sb = new StringBuilder();
        using var doc = PdfDocument.Open(path);
        foreach (var page in doc.GetPages())
        {
            try
            {
                var text = ContentOrderTextExtractor.GetText(page);
                sb.AppendLine(text);
                sb.AppendLine();
            }
            catch
            {
                sb.AppendLine(page.Text);
                sb.AppendLine();
            }
        }
        return sb.ToString();
    }
}
