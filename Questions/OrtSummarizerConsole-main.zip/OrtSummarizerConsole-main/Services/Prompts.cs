namespace OrtSummarizerConsole.Services;

public static class Prompts
{
    public static string System =
        "Bạn là trợ lý tóm tắt tiếng Việt, súc tích và chính xác. " +
        "Giữ nguyên số liệu, tên riêng, trích dẫn; không bịa đặt. " +
        "Nếu thông tin thiếu, hãy ghi [chưa đủ dữ liệu].";

    public static string MapTemplate =
        "NHIỆM VỤ: Tóm tắt phần văn bản sau bằng tiếng Việt.\n" +
        "- Đầu ra 8–12 gạch đầu dòng, rõ ý, không trùng lặp.\n" +
        "- Giữ nguyên số liệu và mốc thời gian.\n" +
        "- Nêu 3 ý chính cuối cùng (CHÍNH).\n\n" +
        "[VĂN BẢN]:\n{chunk}\n";

    public static string ReduceTemplate =
        "NHIỆM VỤ: Hợp nhất các bản tóm tắt con dưới đây thành một bản tóm tắt cuối cùng.\n" +
        "- Đầu ra 12–15 gạch đầu dòng không trùng ý.\n" +
        "- Giữ số liệu/mốc thời gian nếu có, tránh suy đoán.\n" +
        "- Cuối cùng liệt kê 3 KẾT LUẬN then chốt.\n\n" +
        "[TÓM TẮT CON]:\n{maps}\n";
}
