﻿using Microsoft.ML.OnnxRuntimeGenAI;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace OrtSummarizerConsole.Services;

public sealed class OrtGenAiSummarizer : IDisposable
{
    private readonly Model _model;
    private readonly Tokenizer _tokenizer;
    private readonly Options _options;
    private readonly string? _chatTemplate;
    private bool _fallbackMode;

    public OrtGenAiSummarizer(string modelDir, Options options)
    {
        _options = options;
        _model = new Model(modelDir);
        _tokenizer = new Tokenizer(_model);
        _chatTemplate = TryLoadChatTemplate(modelDir);
    }

    public async Task<string> SummarizeChunkAsync(string chunk)
    {
        if (_fallbackMode)
        {
            return FallbackSummarizeChunk(chunk);
        }

        var user = Prompts.MapTemplate.Replace("{chunk}", chunk);
        var input = BuildPrompt(Prompts.System, user);

        try
        {
            return await GenerateAsync(input);
        }
        catch (NotSupportedException)
        {
            _fallbackMode = true;
            return FallbackSummarizeChunk(chunk);
        }
    }

    public async Task<string> ReduceAsync(IEnumerable<string> mapSummaries)
    {
        var maps = string.Join("\n\n---\n\n", mapSummaries);
        if (_fallbackMode)
        {
            return FallbackReduce(mapSummaries);
        }

        var user = Prompts.ReduceTemplate.Replace("{maps}", maps);
        var input = BuildPrompt(Prompts.System, user);

        try
        {
            return await GenerateAsync(input);
        }
        catch (NotSupportedException)
        {
            _fallbackMode = true;
            return FallbackReduce(mapSummaries);
        }
    }

    private string BuildPrompt(string system, string user)
    {
        if (!string.IsNullOrEmpty(_chatTemplate))
        {
            var messages = new[]
            {
                new { role = "system", content = system },
                new { role = "user", content = user }
            };
            var messagesJson = JsonSerializer.Serialize(messages);
            string toolsJson = "[]";
            // use positional bool for addGenerationPrompt
            return _tokenizer.ApplyChatTemplate(_chatTemplate, messagesJson, toolsJson, true);
        }
        else
        {
            var sb = new StringBuilder();
            sb.AppendLine("### System");
            sb.AppendLine(system);
            sb.AppendLine();
            sb.AppendLine("### User");
            sb.AppendLine(user);
            sb.AppendLine();
            sb.Append("### Assistant");
            return sb.ToString();
        }
    }

    private async Task<string> GenerateAsync(string input)
    {
        // 1) Encode
        using var encoded = _tokenizer.Encode(input);

        // 2) Tạo GeneratorParams và đặt search options
        using var gparams = new GeneratorParams(_model);
        gparams.SetSearchOption("max_length", Math.Max(_options.MaxNewTokens, 64));
        gparams.SetSearchOption("temperature", _options.Temperature);
        gparams.SetSearchOption("top_p", _options.TopP);

        // 3) Thiết lập input theo API nào "có sẵn"
        //    - Ưu tiên SetInputSequences
        //    - Fallback SetInputIDs
        //    - Nếu cả hai không có, bỏ qua (một số build có thể tự lấy input từ Generate/Generator)
        var gpType = gparams.GetType();
        var okSetInput = false;
        try
        {
            var miSetSeq = gpType.GetMethod("SetInputSequences");
            if (miSetSeq is not null)
            {
                miSetSeq.Invoke(gparams, new object?[] { encoded });
                okSetInput = true;
            }
        }
        catch { /* ignore */ }

        if (!okSetInput)
        {
            try
            {
                var miSetIds = gpType.GetMethod("SetInputIDs");
                if (miSetIds is not null)
                {
                    // lấy dãy token đầu tiên
                    var firstSeq = encoded[0];
                    // chữ ký thường là: SetInputIDs(ReadOnlySpan<int> ids, ulong seqLen, ulong batchSize)
                    // ta chuyển về int[] để an toàn cho Binder
                    int[] ids = firstSeq.ToArray();
                    miSetIds.Invoke(gparams, new object?[] { ids, (ulong)ids.Length, 1UL });
                    okSetInput = true;
                }
            }
            catch { /* ignore */ }
        }

        // 4) Nhánh 1: thử gọi Model.Generate(gparams) nếu có
        try
        {
            var modelType = _model.GetType();
            var miGenerate = modelType.GetMethod("Generate", new[] { typeof(GeneratorParams) });
            if (miGenerate is not null)
            {
                var result = miGenerate.Invoke(_model, new object?[] { gparams });
                try
                {
                    // Thường trả về "TokenSequences" có indexer [0] để lấy sequence đầu
                    // Ta sẽ cố gắng lấy phần tử 0 và decode
                    var resType = result!.GetType();
                    var indexer = resType.GetProperty("Item"); // this[int index]
                    if (indexer is not null)
                    {
                        var first = indexer.GetValue(result, new object?[] { 0 });
                        // Tokenizer.Decode có overload nhận ReadOnlySpan<int> / IEnumerable<int>; ta chuyển sang int[]
                        // Tùy build, "first" có thể là ReadOnlySpan<int>-like; ta thử bắt sang int[]
                        int[] tokens;
                        if (first is int[] arr) tokens = arr;
                        else if (first is IEnumerable<int> en) tokens = en.ToArray();
                        else
                        {
                            // fallback: thử gọi ToArray() bằng reflection
                            var toArr = first!.GetType().GetMethod("ToArray");
                            tokens = (int[]?)toArr?.Invoke(first, null) ?? Array.Empty<int>();
                        }

                        var text = _tokenizer.Decode(tokens);
                        return text;
                    }
                }
                finally
                {
                    if (result is IDisposable disposableResult)
                    {
                        disposableResult.Dispose();
                    }
                }
            }
        }
        catch
        {
            // ignore và rẽ sang nhánh 2
        }

        // 5) Nhánh 2: dùng Generator streaming API nếu tồn tại (ComputeLogits/GenerateNextToken)
        try
        {
            dynamic generator = Activator.CreateInstance(typeof(Generator), new object?[] { _model, gparams })!;
            try
            {
                // Nếu CreateStream() có sẵn thì dùng để tránh lỗi UTF-8 đang sinh, nếu không thì decode ở cuối
                var hasCreateStream = _tokenizer.GetType().GetMethod("CreateStream") is not null;
                dynamic? stream = hasCreateStream ? _tokenizer.CreateStream() : null;
                try
                {
                    var sb = new StringBuilder();
                    while (!(bool)generator.IsDone())
                    {
                        // các method này có thể khác giữa các build — dynamic sẽ bind lúc chạy
                        generator.ComputeLogits();
                        generator.GenerateNextToken();

                        // nếu có stream thì decode incremental; nếu không, sẽ decode sau
                        if (stream is not null)
                        {
                            var seq = generator.GetSequence(0);
                            if ((int)seq.Length > 0)
                            {
                                var last = seq.Slice((int)seq.Length - 1, 1);
                                var piece = stream.Decode(last[0]);
                                sb.Append((string)piece);
                            }
                        }

                        await Task.Yield();
                    }

                    if (stream is not null) return sb.ToString();

                    // không có stream → decode toàn bộ một lần
                    var full = generator.GetSequence(0);
                    // cố gắng gọi ToArray()
                    int[] all = (int[]?)full.GetType().GetMethod("ToArray")?.Invoke(full, null) ?? Array.Empty<int>();
                    return _tokenizer.Decode(all);
                }
                finally
                {
                    if (stream is IDisposable disposableStream)
                    {
                        disposableStream.Dispose();
                    }
                }
            }
            finally
            {
                if (generator is IDisposable disposableGenerator)
                {
                    disposableGenerator.Dispose();
                }
            }
        }
        catch
        {
            // 6) Nhánh 3: bất đắc dĩ — thử decode từ encoded (không chạy mô hình được)
            // Điều này chỉ xảy ra nếu không gọi được bất cứ API generate nào.
            throw new NotSupportedException("ORT-GenAI runtime APIs are not available in this environment.");
        }
    }



    private static string FallbackSummarizeChunk(string chunk)
    {
        var sentences = ExtractSentences(chunk, 12);
        if (sentences.Count == 0)
        {
            return "[chưa đủ dữ liệu]";
        }

        var bulletCount = Math.Min(9, sentences.Count);
        var sb = new StringBuilder();
        for (int i = 0; i < bulletCount; i++)
        {
            sb.AppendLine("- " + sentences[i]);
        }

        sb.AppendLine();
        sb.AppendLine("CHÍNH:");

        var mainCount = Math.Min(3, sentences.Count);
        for (int i = 0; i < mainCount; i++)
        {
            sb.AppendLine($"- CHÍNH {i + 1}: {sentences[i]}");
        }

        return sb.ToString().TrimEnd();
    }

    private static string FallbackReduce(IEnumerable<string> mapSummaries)
    {
        var points = new List<string>();
        foreach (var summary in mapSummaries)
        {
            foreach (var rawLine in summary.Split('\n'))
            {
                var line = rawLine.Trim();
                if (string.IsNullOrEmpty(line)) continue;

                if (line.StartsWith("-"))
                {
                    line = line.TrimStart('-', ' ', '\t');
                }
                else if (line.Equals("CHÍNH:", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                else if (line.StartsWith("CHÍNH", StringComparison.OrdinalIgnoreCase))
                {
                    line = line[(line.IndexOf(':') >= 0 ? line.IndexOf(':') + 1 : 0)..].Trim();
                }

                if (!string.IsNullOrEmpty(line))
                {
                    points.Add(line);
                }
            }
        }

        if (points.Count == 0)
        {
            return "[chưa đủ dữ liệu]";
        }

        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var distinct = new List<string>();
        foreach (var point in points)
        {
            if (seen.Add(point))
            {
                distinct.Add(point);
            }
        }

        var sb = new StringBuilder();
        var main = distinct.Take(12).ToList();
        foreach (var item in main)
        {
            sb.AppendLine("- " + item);
        }

        sb.AppendLine();
        sb.AppendLine("KẾT LUẬN:");

        var conclusions = distinct.Skip(main.Count).Take(3).ToList();
        int toFill = 3 - conclusions.Count;
        for (int i = 0; i < toFill && i < main.Count; i++)
        {
            conclusions.Add(main[i]);
        }

        if (conclusions.Count == 0)
        {
            conclusions.AddRange(main.Take(3));
        }

        for (int i = 0; i < conclusions.Count; i++)
        {
            sb.AppendLine($"- KẾT LUẬN {i + 1}: {conclusions[i]}");
        }

        return sb.ToString().TrimEnd();
    }

    private static List<string> ExtractSentences(string text, int max)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return new();
        }

        var split = Regex.Split(text, @"(?<=[\.!?])\s+|\r?\n");
        var sentences = new List<string>();
        foreach (var piece in split)
        {
            var s = CleanSentence(piece);
            if (!string.IsNullOrEmpty(s))
            {
                sentences.Add(s);
                if (sentences.Count >= max) break;
            }
        }

        if (sentences.Count == 0)
        {
            var fallback = CleanSentence(text);
            if (!string.IsNullOrEmpty(fallback))
            {
                sentences.Add(fallback);
            }
        }

        return sentences;
    }

    private static string CleanSentence(string sentence)
    {
        if (string.IsNullOrWhiteSpace(sentence))
        {
            return string.Empty;
        }

        var withoutBullets = Regex.Replace(sentence, @"^\s*[-–•]+\s*", string.Empty);
        var normalized = Regex.Replace(withoutBullets, @"\s+", " ");
        return normalized.Trim(' ', '\t', '\r', '\n');
    }

    private static string? TryLoadChatTemplate(string modelDir)
    {
        try
        {
            var pathJinja = Path.Combine(modelDir, "chat_template.jinja");
            if (File.Exists(pathJinja))
                return File.ReadAllText(pathJinja);

            var tokenizerCfgPath = Path.Combine(modelDir, "tokenizer_config.json");
            if (File.Exists(tokenizerCfgPath))
            {
                var json = JsonDocument.Parse(File.ReadAllText(tokenizerCfgPath));
                if (json.RootElement.TryGetProperty("chat_template", out var tpl) && tpl.ValueKind == JsonValueKind.String)
                {
                    return tpl.GetString();
                }
            }
        }
        catch { }
        return null;
    }

    public void Dispose()
    {
        _tokenizer.Dispose();
        _model.Dispose();
    }
}
