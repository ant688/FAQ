# ORT Summarizer Console (.NET 8, ORT-GenAI)

A minimal console app to **summarize / synthesize** `.txt` and `.pdf` documents locally using **ONNX Runtime GenAI (ORT-GenAI)**.  
Implements a simple **chunk → map → reduce** pipeline and outputs a `.md` or `.txt` summary.

## Features
- Local inference via **Microsoft.ML.OnnxRuntimeGenAI** (CPU by default).
- **PDF** text extraction via **PdfPig** (free, Apache 2.0).
- Token-budget chunking (char→token heuristic).
- Map/Reduce prompts tuned for **Vietnamese** concise summaries.
- Optional **chat template** support (reads `chat_template.jinja` or `tokenizer_config.json` if present).

## Install
> ⚠️ Choose **ONE** ORT-GenAI NuGet variant:
- CPU: `Microsoft.ML.OnnxRuntimeGenAI`
- Windows GPU (DirectML): `Microsoft.ML.OnnxRuntimeGenAI.DirectML`
- NVIDIA CUDA: `Microsoft.ML.OnnxRuntimeGenAI.Cuda`

Edit the `.csproj` accordingly (only keep one). See ORT-GenAI install notes.  

## Usage
```bash
dotnet run -- --input sample.pdf --model-dir C:\models\phi3-mini\directml-int4 --out summary.md
dotnet run -- --input note.txt  --model-dir ./models/cpu-int4 --tokens-per-chunk 900 --max-new-tokens 256
```

**Arguments**
- `--input` (required): path to `.pdf` or `.txt`
- `--model-dir` (required): path to the **ORT-GenAI** model folder
- `--out`: output `.md` or `.txt` (default: based on input name)
- `--tokens-per-chunk` (default: 900)
- `--max-new-tokens` (default: 256)
- `--temperature` (default: 0.2)
- `--top-p` (default: 0.9)

## Model Notes
- Works with ORT-GenAI compatible models (e.g., Phi-3, Gemma, Llama in ONNX format).
- If your model folder contains a `chat_template.jinja` or `tokenizer_config.json` with `chat_template`, the app will apply it; otherwise it uses a neutral **Instruction/User/Assistant** fallback that is generally fine for *Instruct* models.

## How it works
1. **Extract** text (PdfPig or read `.txt`)
2. **Chunk** into ~N tokens
3. **Map**: summarize each chunk
4. **Reduce**: merge all chunk summaries into final summary
5. **Write** `.md`/`.txt`

## Tips
- For large/complex docs, increase `--tokens-per-chunk` and `--max-new-tokens` if your model and hardware allow.
- Quantized models (int4) in ORT format run well on CPU; DirectML provides a nice speedup on Windows GPUs.
