﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDFWand.Services;

public interface ILogInputService
{
    Task Log(string content);
}

