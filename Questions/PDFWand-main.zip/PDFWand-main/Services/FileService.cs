﻿using System.IO;
using System.Text;
using System.Text.Json;

namespace PDFWand.Services;

public class FileService : IFileService
{
    private readonly JsonSerializerOptions _options = new()
    {
        WriteIndented = true,
    };

    /// <summary>
    /// Asynchronously reads and deserializes the file content from the specified path.
    /// </summary>
    /// <typeparam name="T">The type into which the JSON will be deserialized.</typeparam>
    /// <param name="folderPath">The folder path where the file resides.</param>
    /// <param name="fileName">The name of the file.</param>
    /// <returns>The deserialized object if successful; otherwise, default(T).</returns>
    public async Task<T> ReadAsync<T>(string folderPath, string fileName)
    {
        if (string.IsNullOrWhiteSpace(folderPath))
            throw new ArgumentException("Folder path cannot be null or empty.", nameof(folderPath));

        if (string.IsNullOrWhiteSpace(fileName))
            throw new ArgumentException("File name cannot be null or empty.", nameof(fileName));

        var fullPath = Path.Combine(folderPath, fileName);

        if (!File.Exists(fullPath))
            return default;

        // Asynchronously read file content using UTF8 encoding.
        var json = await File.ReadAllTextAsync(fullPath, Encoding.UTF8).ConfigureAwait(false);

        // Optionally, wrap the deserialization in a try/catch to handle malformed JSON.
        return JsonSerializer.Deserialize<T>(json, _options);
    }

    /// <summary>
    /// Asynchronously serializes the provided content and writes it to the specified file.
    /// </summary>
    /// <typeparam name="T">The type of the content.</typeparam>
    /// <param name="folderPath">The folder path where the file will be saved.</param>
    /// <param name="fileName">The name of the file.</param>
    /// <param name="content">The content to be serialized and saved.</param>
    public async Task SaveAsync<T>(string folderPath, string fileName, T content)
    {
        if (string.IsNullOrWhiteSpace(folderPath))
            throw new ArgumentException("Folder path cannot be null or empty.", nameof(folderPath));

        if (string.IsNullOrWhiteSpace(fileName))
            throw new ArgumentException("File name cannot be null or empty.", nameof(fileName));

        // Ensure the directory exists; create it if not.
        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }

        var fullPath = Path.Combine(folderPath, fileName);
        var fileContent = JsonSerializer.Serialize(content, _options);

        // Write the content asynchronously.
        await File.WriteAllTextAsync(fullPath, fileContent, Encoding.UTF8).ConfigureAwait(false);
    }

    /// <summary>
    /// Synchronously deletes the specified file if it exists.
    /// </summary>
    /// <param name="folderPath">The folder path where the file is located.</param>
    /// <param name="fileName">The name of the file to delete.</param>
    public void Delete(string folderPath, string fileName)
    {
        if (string.IsNullOrWhiteSpace(folderPath))
            throw new ArgumentException("Folder path cannot be null or empty.", nameof(folderPath));

        if (string.IsNullOrWhiteSpace(fileName))
            throw new ArgumentException("File name cannot be null or empty.", nameof(fileName));

        var fullPath = Path.Combine(folderPath, fileName);
        if (File.Exists(fullPath))
        {
            File.Delete(fullPath);
        }
    }

    /// <summary>
    /// Asynchronously appends content to the specified file.
    /// </summary>
    /// <param name="folderPath">The folder path where the file is located.</param>
    /// <param name="fileName">The name of the file to append content to.</param>
    /// <param name="content">The content to be appended.</param>
    public async Task AppendAsync<T>(string folderPath, string fileName, T content)
    {
        if (string.IsNullOrWhiteSpace(folderPath))
            throw new ArgumentException("Folder path cannot be null or empty.", nameof(folderPath));

        if (string.IsNullOrWhiteSpace(fileName))
            throw new ArgumentException("File name cannot be null or empty.", nameof(fileName));

        // Ensure the directory exists; create it if not.
        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }

        var fullPath = Path.Combine(folderPath, fileName);
        //var fileContent = JsonSerializer.Serialize(content, _options);

        // Append the content asynchronously.
        await File.AppendAllTextAsync(fullPath, content + Environment.NewLine, Encoding.UTF8).ConfigureAwait(false);
    }
}

