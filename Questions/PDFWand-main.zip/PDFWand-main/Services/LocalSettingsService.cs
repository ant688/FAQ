﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.Tasks;
using PDFWand.Models;


namespace PDFWand.Services;

public class LocalSettingsService : ILocalSettingsService
{
    // Default values used if configuration is not provided.
    private const string DefaultLocalSettingsFile = "LocalSettings.json";
    private readonly string DefaultApplicationDataFolder =
        $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}/ApplicationData";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    //private readonly IFileService _fileService;
    private readonly AppConfig _appConfig;

    private readonly string _localApplicationData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
    private readonly string _applicationDataFolder;
    private readonly string _localSettingsFile;

    private IDictionary<string, object> _settings;
    private bool _isInitialized;

    public LocalSettingsService(IFileService fileService, IOptions<AppConfig> config)
    {
        //_fileService = fileService;
        _appConfig = config.Value;

        // Use the application config if provided, otherwise fallback to defaults.
        _applicationDataFolder = Path.Combine(
            _localApplicationData,
            _appConfig.ApplicationDataFolder ?? DefaultApplicationDataFolder);
        _localSettingsFile = _appConfig.LocalSettingsFile ?? DefaultLocalSettingsFile;

        _settings = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
    }

    private async Task InitializeAsync()
    {
        if (_isInitialized) return;

        if (!Directory.Exists(_applicationDataFolder))
        {
            Directory.CreateDirectory(_applicationDataFolder);
        }

        string settingsFilePath = Path.Combine(_applicationDataFolder, _localSettingsFile);

        if (!File.Exists(settingsFilePath))
        {
            using var fs = File.Create(settingsFilePath);
            using var writer = new StreamWriter(fs, Encoding.UTF8);
            await writer.WriteAsync("{}");
        }

        // NOTE: when deserializing to object, System.Text.Json will use JsonElement for values.
        _settings = JsonSerializer.Deserialize<IDictionary<string, object>>(
                       await File.ReadAllTextAsync(settingsFilePath, Encoding.UTF8),
                       JsonOptions)
                   ?? new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);


        _isInitialized = true;
    }

    public async Task<T?> ReadSettingAsync<T>(string key)
    {
        await InitializeAsync();

        if (_settings != null && _settings.TryGetValue(key, out var obj))
        {
            // If the saved value is a JsonElement (most common when reading from file)
            if (obj is JsonElement element)
            {
                // If caller expects string, return the plain string if it is one
                if (typeof(T) == typeof(string))
                {
                    if (element.ValueKind == JsonValueKind.String)
                    {
                        var s = element.GetString();

                        // Handle legacy “double-encoded” values like "\"System\"" gracefully
                        try
                        {
                            // If s is a JSON string literal, this will unescape it to plain text
                            var unwrapped = JsonSerializer.Deserialize<string>(s!);
                            if (unwrapped is not null)
                                return (T)(object)unwrapped;
                        }
                        catch
                        {
                            // fall back to raw string
                        }

                        return (T)(object)(s ?? string.Empty);
                    }

                    // For non-string kinds, deserialize to string (e.g., numbers/bools → string)
                    return (T)(object)element.GetRawText();
                }

                // For non-string T, deserialize directly from the element
                return element.Deserialize<T>(JsonOptions);
            }

            // If we somehow already have the runtime type
            if (obj is T t)
                return t;

            // Handle legacy case where value was stored as a JSON string (double-encoded)
            if (obj is string s2)
            {
                try
                {
                    // Try deserializing the JSON string into T
                    var v = JsonSerializer.Deserialize<T>(s2, JsonOptions);
                    if (v is not null) return v;
                }
                catch
                {
                    if (typeof(T) == typeof(string))
                        return (T)(object)s2;
                    throw;
                }
            }
        }

        return default;
    }

    public async Task SaveSettingAsync<T>(string key, T value)
    {
        await InitializeAsync();

        // ✅ Do NOT pre-serialize; store the raw value and let the final save serialize once.
        _settings[key] = value!;

        // Persist to disk. Ensure your IFileService uses the provided JsonOptions (or equivalent).
        //await _fileService.SaveAsync(_applicationDataFolder, _localSettingsFile, _settings, JsonOptions);

        var path = Path.Combine(_applicationDataFolder, _localSettingsFile);
        var json = JsonSerializer.Serialize(_settings, JsonOptions);
        await File.WriteAllTextAsync(path, json, Encoding.UTF8);

    }

    public async Task<bool> RemoveSettingAsync(string key)
    {
        await InitializeAsync();

        if (_settings.ContainsKey(key))
        {
            _settings.Remove(key);

            // Save the updated settings back to the file
            var path = Path.Combine(_applicationDataFolder, _localSettingsFile);
            var json = JsonSerializer.Serialize(_settings, JsonOptions);
            await File.WriteAllTextAsync(path, json, Encoding.UTF8);

            return true; // Key was removed
        }

        return false; // Key not found
    }

}
