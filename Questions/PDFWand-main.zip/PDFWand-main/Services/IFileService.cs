﻿using System.Threading.Tasks;

namespace PDFWand.Services;

/// <summary>
/// Represents a service that performs file operations such as reading, writing, and deleting files.
/// </summary>
public interface IFileService
{

    Task<T> ReadAsync<T>(string folderPath, string fileName);

    Task SaveAsync<T>(string folderPath, string fileName, T content);

    void Delete(string folderPath, string fileName);

    Task AppendAsync<T>(string folderPath, string fileName, T content);
}
