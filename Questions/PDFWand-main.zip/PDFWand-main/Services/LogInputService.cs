﻿using PDFWand.Models;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;

namespace PDFWand.Services;

public class LogInputService : ILogInputService
{
    // Default values used if configuration is not provided.
    private const string DefaultLogFile = "Input.txt";
    private readonly string DefaultApplicationDataFolder =
        $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}/ApplicationData/Log";

    private readonly IFileService _fileService;
    private readonly AppConfig _appConfig;

    private readonly string _localApplicationData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
    private readonly string _applicationDataFolder;
    private readonly string _localLogFile;

    public LogInputService(IFileService fileService, IOptions<AppConfig> config)
    {
        _fileService = fileService;
        _appConfig = config.Value;

        // Use the application config if provided, otherwise fallback to defaults.
        _applicationDataFolder = Path.Combine(
            _localApplicationData,
            _appConfig.ApplicationDataFolder ?? DefaultApplicationDataFolder);
        _localLogFile = _appConfig.LogFile ?? DefaultLogFile;

    }



    public async Task Log(string content)
    {
       await _fileService.AppendAsync<string>(_applicationDataFolder, _localLogFile, content);
    }
}

