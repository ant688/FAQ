﻿using CommunityToolkit.Mvvm.Messaging;
using PDFWand.Messenger;
using PDFWand.Services;
using PDFWand.ViewModels.Windows;
using System.Diagnostics;
using System.Threading.Tasks;
using Wpf.Ui;
using Wpf.Ui.Abstractions;
using Wpf.Ui.Appearance;
using Wpf.Ui.Controls;

namespace PDFWand.Views.Windows
{
    public partial class MainWindow : INavigationWindow
    {
        public MainWindowViewModel ViewModel { get; }
        private readonly ILocalSettingsService _localSettingsService;
        private readonly IMessenger _messenger;


        public MainWindow(
            MainWindowViewModel viewModel,
            INavigationViewPageProvider navigationViewPageProvider,
            INavigationService navigationService,
            ISnackbarService snackbarService,
            IContentDialogService contentDialogService,
            ILocalSettingsService localSettingsService,
            IMessenger messenger
        )
        {
            ViewModel = viewModel;
            DataContext = this;

            _messenger = messenger;
            _messenger.Register<ThemeChangeMessage>(this, (recipient, message) =>
            {
                Debug.Print("Mainwindow: Messeage received !");
                if (message.Theme.Code == "Unknown")
                {
                    ApplicationThemeManager.ApplySystemTheme();
                    SystemThemeWatcher.Watch(this);
                }
                else
                {
                    SystemThemeWatcher.UnWatch(this);
                }
            });

            InitializeComponent();
            SetPageService(navigationViewPageProvider);
            _localSettingsService = localSettingsService;
            navigationService.SetNavigationControl(RootNavigation);
            contentDialogService.SetDialogHost(RootContentDialog);
            snackbarService.SetSnackbarPresenter(SnackbarPresenter);
            InitTheme();
        }

        #region INavigationWindow methods

        public INavigationView GetNavigation() => RootNavigation;

        public bool Navigate(Type pageType) => RootNavigation.Navigate(pageType);

        public void SetPageService(INavigationViewPageProvider navigationViewPageProvider) => RootNavigation.SetPageProviderService(navigationViewPageProvider);

        public void ShowWindow() => Show();

        public void CloseWindow() => Close();

        #endregion INavigationWindow methods

        /// <summary>
        /// Raises the closed event.
        /// </summary>
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            // Make sure that closing this window will begin the process of closing the application.
           System.Windows.Application.Current.Shutdown();
        }

        INavigationView INavigationWindow.GetNavigation()
        {
            throw new NotImplementedException();
        }

        public void SetServiceProvider(IServiceProvider serviceProvider)
        {
            throw new NotImplementedException();
        }


        private async void InitTheme()
        {
            var theme = await _localSettingsService.ReadSettingAsync<string>("Theme");

            if (string.IsNullOrWhiteSpace(theme))
            {
                SystemThemeWatcher.Watch(this);
            }
            else
            {
                switch (theme)
                {
                    case "Light":
                        ApplicationThemeManager.Apply(ApplicationTheme.Light);
                        break;
                    case "Dark":
                        ApplicationThemeManager.Apply(ApplicationTheme.Dark);
                        break;
                    case "HighContrast":
                        ApplicationThemeManager.Apply(ApplicationTheme.HighContrast);
                        break;
                    case "Unknown":
                        SystemThemeWatcher.Watch(this);
                        break;
                    default:
                        SystemThemeWatcher.Watch(this);
                        break;
                }
            }
        }

        private async void RootNavigation_PaneOpened(NavigationView sender, RoutedEventArgs args)
        {
            if (_localSettingsService is not null)
            {
                await _localSettingsService.SaveSettingAsync("IsPaneOpen", true);
            }
        }

        private async void RootNavigation_PaneClosed(NavigationView sender, RoutedEventArgs args)
        {
            if (_localSettingsService is not null)
            {
                await _localSettingsService.SaveSettingAsync("IsPaneOpen", false);
            }

        }

    }
}
