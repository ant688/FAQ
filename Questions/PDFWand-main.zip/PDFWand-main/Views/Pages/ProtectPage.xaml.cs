﻿using PDFWand.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PDFWand.Views.Pages;

/// <summary>
/// Interaction logic for ProtectPage.xaml
/// </summary>
public partial class ProtectPage : Page
{
    public ProtectViewModel ViewModel { get; }

    public ProtectPage(ProtectViewModel viewModel) 
    {
        InitializeComponent();
        ViewModel = viewModel;
        DataContext = this;
    }
}
