using System.Windows;
using System.Windows.Controls;
using PDFWand.ViewModels.Pages;

namespace PDFWand.Views.Pages;

public partial class WatermarkPage : Page
{
    public WatermarkViewModel ViewModel { get; }

    public WatermarkPage(WatermarkViewModel viewModel)
    {
        InitializeComponent();
        ViewModel = viewModel;
        DataContext = this;
    }

    private void PreviewCardContent_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (e.NewSize.Width <= 0 || e.NewSize.Height <= 0)
        {
            return;
        }

        ViewModel.UpdatePreviewViewportSize(e.NewSize.Width, e.NewSize.Height);
    }
}
