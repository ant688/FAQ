﻿using PDFWand.ViewModels.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Wpf.Ui.Abstractions.Controls;

namespace PDFWand.Views.Pages;

/// <summary>
/// Interaction logic for ExtractionPage.xaml
/// </summary>
public partial class ExtractionPage : INavigableView<ExtractionViewModel>
{
    public ExtractionViewModel ViewModel { get; }

    public ExtractionPage(ExtractionViewModel vm)
    {
        ViewModel = vm;
        DataContext = this;
        InitializeComponent();
    }
}
