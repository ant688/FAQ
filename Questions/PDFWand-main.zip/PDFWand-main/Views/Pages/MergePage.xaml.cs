﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PDFWand.ViewModels;

namespace PDFWand.Views.Pages;

/// <summary>
/// Interaction logic for MergePage.xaml
/// </summary>
public partial class MergePage : Page
{
    public MergeViewModel ViewModel { get; }

    public MergePage(MergeViewModel vm)
    {
        ViewModel = vm;
        DataContext = this;
        InitializeComponent();
    }
}
