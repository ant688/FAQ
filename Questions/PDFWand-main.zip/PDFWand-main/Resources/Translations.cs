namespace PDFWand.Resources
{
    public partial class Translations
    {
    }
}
