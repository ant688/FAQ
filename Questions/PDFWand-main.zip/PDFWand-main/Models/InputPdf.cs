﻿
namespace PDFWand.Model;

public class InputPdf : ObservableObject
{
    private int _no;
    private string? _fileName;
    private string? _fullPath;
    private long _size;
    private int _pageCount;
    private string? _openPassword;
    private DateTime _modifiedDate;

    public int No { get => _no; set => SetProperty(ref _no, value); }
    public string? FileName { get => _fileName; set => SetProperty(ref _fileName, value); }
    public string? FullPath { get => _fullPath; set => SetProperty(ref _fullPath, value); }
    public long Size { get => _size; set => SetProperty(ref _size, value); }
    public int PageCount { get => _pageCount; set => SetProperty(ref _pageCount, value); }
    public string? OpenPassword { get => _openPassword; set => SetProperty(ref _openPassword, value); }
    public DateTime ModifiedDate { get => _modifiedDate; set => SetProperty(ref _modifiedDate, value); }
}
