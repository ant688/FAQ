﻿using System.Windows.Media;
using CommunityToolkit.Mvvm.ComponentModel;

namespace PDFWand.Models
{
    public class PdfPreviewPage : ObservableObject
    {
        public int PageNo { get; set; }

        public int TotalPage { get; set; }

        private ImageSource? _viewPage;

        public ImageSource? ViewPage
        {
            get => _viewPage;
            set => SetProperty(ref _viewPage, value);
        }

        private int _rotationAngle;

        public int RotationAngle
        {
            get => _rotationAngle;
            set => SetProperty(ref _rotationAngle, value);
        }
    }
}
