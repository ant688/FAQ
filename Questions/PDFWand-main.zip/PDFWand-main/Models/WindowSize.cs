﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDFWand.Models;

public class WindowSize
{
    public double Width { get; set; }
    public double Height { get; set; }
}
