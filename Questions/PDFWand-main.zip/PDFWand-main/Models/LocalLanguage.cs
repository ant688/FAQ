﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDFWand.Models;

public class LocalLanguage: ObservableObject
{
    public string? DisplayName { get; set; }
    public string? Code { get; set; }
}
