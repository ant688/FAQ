﻿namespace PDFWand.Models;

public class AppConfig
{
    public string? ConfigurationsFolder { get; set; }

    public string? AppPropertiesFileName { get; set; }

    public string? ApplicationDataFolder { get; set; }

    public string? LocalSettingsFile { get; set; }

    public string? LogFile { get; set; }
}
