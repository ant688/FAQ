using CommunityToolkit.Mvvm.Messaging;
using iText.IO.Image;
using iText.Kernel.Colors;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Extgstate;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using Lepo.i18n;
using Microsoft.Win32;
using PDFWand.CoreHelper;
using PDFWand.Helpers;
using PDFWand.Messenger;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Threading;
using System.Threading.Tasks;
using Wpf.Ui.Controls;
using Wpf.Ui;
using MediaColor = System.Windows.Media.Color;
using DrawingColor = System.Drawing.Color;
using FormsColorDialog = System.Windows.Forms.ColorDialog;
using FormsDialogResult = System.Windows.Forms.DialogResult;
using WindowsSize = System.Windows.Size;
namespace PDFWand.ViewModels.Pages;

public partial class WatermarkViewModel : ObservableObject
{
    private readonly IContentDialogService _contentDialogService;
    private readonly ILocalizationProvider _localizationProvider;
    private readonly IMessenger _messenger;
    private LocalizationSet? _localizationSet;
    private string? _currentPreviewFilePath;
    private int _currentPreviewPageIndex;
    private double _previewAvailableWidth;
    private double _previewAvailableHeight;
    private bool _isManualZoom;

    private const double MinZoom = 0.05;
    private const double MaxZoom = 4.0;
    private const double ZoomStep = 0.1;

    public WatermarkViewModel(IContentDialogService contentDialogService,
        ILocalizationProvider localizationProvider,
        IMessenger messenger)
    {
        _contentDialogService = contentDialogService;
        _localizationProvider = localizationProvider;
        _messenger = messenger;

        _localizationSet = _localizationProvider.GetLocalizationSet(_localizationProvider.GetCulture().Name);

        _messenger.Register<LanguageChangedMessage>(this, (_, message) =>
        {
            _localizationSet = _localizationProvider.GetLocalizationSet(message.Culture.Name);
            UpdateOutputPreview();
        });

        WatermarkText = "CONFIDENTIAL";
        WatermarkFontSize = 48;
        WatermarkOpacity = 0.3;
        WatermarkRotation = 45;
        HorizontalPosition = 50;
        VerticalPosition = 50;
        WatermarkScale = 0.5;
        WatermarkModeIndex = 0;
        PreviewZoom = 1;
        UpdateOutputPreview();
    }

    #region Fields

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ApplyWatermarkCommand))]
    private string _selectedPath = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ApplyWatermarkCommand))]
    private string _outputPath = string.Empty;

    [ObservableProperty]
    private bool _isFolder;

    [ObservableProperty]
    private Visibility _openedFilePathVisibility = Visibility.Collapsed;

    [ObservableProperty]
    private Visibility _outputPathVisibility = Visibility.Collapsed;

    [ObservableProperty]
    private string _pickedFileOrFolder = string.Empty;

    [ObservableProperty]
    private ControlAppearance _openFileButtonApperance = ControlAppearance.Transparent;

    [ObservableProperty]
    private ControlAppearance _openFolderButtonApperance = ControlAppearance.Transparent;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ApplyWatermarkCommand))]
    private bool _renameOutputFile;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ApplyWatermarkCommand))]
    private string _prefixFileName = string.Empty;

    [ObservableProperty]
    private bool _useTextWatermark = true;

    [ObservableProperty]
    private int _watermarkModeIndex;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ApplyWatermarkCommand))]
    private string _watermarkText = string.Empty;

    public string WatermarkDisplayText => string.IsNullOrWhiteSpace(WatermarkText) ? "CONFIDENTIAL" : WatermarkText;

    [ObservableProperty]
    private double _watermarkFontSize;

    [ObservableProperty]
    private double _watermarkOpacity;

    [ObservableProperty]
    private double _watermarkRotation;

    [ObservableProperty]
    private MediaColor _watermarkTextColor = Colors.Gray;

    [ObservableProperty]
    private SolidColorBrush _watermarkTextBrush = CreateFrozenBrush(Colors.Gray);

    [ObservableProperty]
    private double _horizontalPosition;

    [ObservableProperty]
    private double _verticalPosition;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ApplyWatermarkCommand))]
    private string _watermarkImagePath = string.Empty;

    [ObservableProperty]
    private ImageSource? _watermarkImagePreview;

    [ObservableProperty]
    private string _watermarkImageFileName = string.Empty;

    [ObservableProperty]
    private double _watermarkScale;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ZoomInCommand))]
    [NotifyCanExecuteChangedFor(nameof(ZoomOutCommand))]
    [NotifyCanExecuteChangedFor(nameof(ResetZoomCommand))]
    private BitmapSource? _previewImage;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ZoomInCommand))]
    [NotifyCanExecuteChangedFor(nameof(ZoomOutCommand))]
    [NotifyCanExecuteChangedFor(nameof(ResetZoomCommand))]
    private double _previewWidth;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ZoomInCommand))]
    [NotifyCanExecuteChangedFor(nameof(ZoomOutCommand))]
    [NotifyCanExecuteChangedFor(nameof(ResetZoomCommand))]
    private double _previewHeight;

    [ObservableProperty]
    private double _watermarkPreviewWidth = 160;

    [ObservableProperty]
    private double _watermarkPreviewHeight = 60;

    [ObservableProperty]
    private double _watermarkPreviewBoundingWidth = 160;

    [ObservableProperty]
    private double _watermarkPreviewBoundingHeight = 60;

    [ObservableProperty]
    private Thickness _watermarkPreviewMargin = new(0);

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ApplyWatermarkCommand))]
    private bool _isProcessing;

    [ObservableProperty]
    private bool _setPassword;

    [ObservableProperty]
    private bool _allowPrint = true;

    [ObservableProperty]
    private bool _allowCopy = true;

    [ObservableProperty]
    private bool _allowFillIn = true;

    [ObservableProperty]
    private bool _allowModifyAnnotations = true;

    [ObservableProperty]
    private bool _allowModifyContents = true;

    [ObservableProperty]
    private bool _allowScreenReaders = true;

    [ObservableProperty]
    private bool _allowAssembly = true;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(GoToPreviousPageCommand))]
    [NotifyCanExecuteChangedFor(nameof(GoToNextPageCommand))]
    private int _currentPreviewPage;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(GoToPreviousPageCommand))]
    [NotifyCanExecuteChangedFor(nameof(GoToNextPageCommand))]
    private int _previewPageCount;

    [ObservableProperty]
    private double _previewZoom;

    [ObservableProperty]
    private string _previewPageDisplay = "0 / 0";

    [ObservableProperty]
    private string _outputFilePreview = string.Empty;

    #endregion

    #region Commands

    [RelayCommand]
    private async Task OpenFileAsync()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "PDF|*.pdf",
            Title = _localizationSet?["OpenFile"] ?? "Open file"
        };

        if (dialog.ShowDialog() == true)
        {
            IsFolder = false;
            SelectedPath = dialog.FileName;
            PickedFileOrFolder = _localizationSet?["SelectedFileLabel"] ?? "Selected file:";
            OpenedFilePathVisibility = Visibility.Visible;
            OpenFileButtonApperance = ControlAppearance.Info;
            OpenFolderButtonApperance = ControlAppearance.Transparent;
            await LoadPreviewForFileAsync(dialog.FileName);
            AutoToggleRename();
            UpdateOutputPreview();
        }
    }

    [RelayCommand]
    private async Task OpenFolderAsync()
    {
        var dialog = new OpenFolderDialog
        {
            Title = _localizationSet?["SelectPdfFolderTitle"] ?? "Select folder",
            Multiselect = false
        };

        if (dialog.ShowDialog() == true)
        {
            IsFolder = true;
            RenameOutputFile = false;
            PrefixFileName = string.Empty;
            SelectedPath = dialog.FolderName;
            PickedFileOrFolder = _localizationSet?["SelectedFolderLabel"] ?? "Selected folder:";
            OpenedFilePathVisibility = Visibility.Visible;
            OpenFileButtonApperance = ControlAppearance.Transparent;
            OpenFolderButtonApperance = ControlAppearance.Info;

            var firstPdf = Directory.GetFiles(dialog.FolderName, "*.pdf").FirstOrDefault();
            if (!string.IsNullOrEmpty(firstPdf))
            {
                await LoadPreviewForFileAsync(firstPdf);
            }
            else
            {
                ResetPreviewState();
            }
            AutoToggleRename();
            UpdateOutputPreview();
        }
    }

    [RelayCommand]
    private void OpenOutputFolder()
    {
        var dialog = new OpenFolderDialog
        {
            Title = _localizationSet?["SelectOutputFolderTitle"] ?? "Select output",
            Multiselect = false
        };

        if (dialog.ShowDialog() == true)
        {
            OutputPath = dialog.FolderName;
            OutputPathVisibility = Visibility.Visible;
            AutoToggleRename();
            UpdateOutputPreview();
        }
    }

    [RelayCommand]
    private void PickWatermarkImage()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp;*.gif",
            Title = _localizationSet?["SelectImageFile"] ?? "Select image"
        };

        if (dialog.ShowDialog() == true)
        {
            var selectedPath = dialog.FileName;

            if (TryUpdateWatermarkImagePreview(selectedPath))
            {
                WatermarkImagePath = selectedPath;
                WatermarkModeIndex = 1;
            }
            else
            {
                WatermarkImagePreview = null;
                WatermarkImagePath = string.Empty;
                WatermarkModeIndex = 0;
            }
        }
    }

    [RelayCommand]
    private void PickWatermarkTextColor()
    {
        using var colorDialog = new FormsColorDialog
        {
            AllowFullOpen = true,
            FullOpen = true,
            Color = DrawingColor.FromArgb(WatermarkTextColor.A, WatermarkTextColor.R, WatermarkTextColor.G, WatermarkTextColor.B)
        };

        if (colorDialog.ShowDialog() == FormsDialogResult.OK)
        {
            var selectedColor = colorDialog.Color;
            WatermarkTextColor = MediaColor.FromArgb(selectedColor.A, selectedColor.R, selectedColor.G, selectedColor.B);
        }
    }

    [RelayCommand(CanExecute = nameof(CanApplyWatermark))]
    private async Task ApplyWatermarkAsync()
    {
        if (string.IsNullOrWhiteSpace(SelectedPath) || string.IsNullOrWhiteSpace(OutputPath))
        {
            return;
        }

        try
        {
            IsProcessing = true;
            byte[] userPass = [];
            byte[] ownerPass = [];
            bool shouldContinue = true;
            int permissions = new BuildPermissions
            {
                AllowAssembly = AllowAssembly,
                AllowCopy = AllowCopy,
                AllowFillIn = AllowFillIn,
                AllowModifyAnnotations = AllowModifyAnnotations,
                AllowModifyContents = AllowModifyContents,
                AllowPrint = AllowPrint,
                AllowScreenReaders = AllowScreenReaders
            }.Build();

            if (SetPassword)
            {
                (userPass, ownerPass, shouldContinue) = await PromptForPasswordAsync();
            }

            if (SetPassword && !shouldContinue)
            {
                return;
            }

            var filesToProcess = ResolveInputFiles();
            if (filesToProcess.Count == 0)
            {
                await ShowMessageAsync(_localizationSet?["OpenFileError"] ?? "Error", _localizationSet?["NoPdfFound"] ?? "No PDF file found.");
                return;
            }

            int success = 0;
            string? lastProcessed = null;
            foreach (var file in filesToProcess)
            {
                try
                {
                    var outputFilePath = BuildOutputFilePath(file);
                    using var reader = new PdfReader(file);
                    reader.SetUnethicalReading(true);
                    using var writer = SetPassword
                        ? CreatePdfWriterWithEncryption(outputFilePath, userPass, ownerPass, permissions)
                        : new PdfWriter(outputFilePath);
                    using var pdfDoc = new PdfDocument(reader, writer);
                    ApplyWatermark(pdfDoc);
                    success++;
                    lastProcessed = Path.GetFileName(file);
                }
                catch (iText.Kernel.Exceptions.BadPasswordException)
                {
                    await ShowMessageAsync(_localizationSet?["ProtectedFile"] ?? "Protected", string.Format(_localizationSet?["ProtectedFileContent"] ?? "{0}\nThis file is protected.", file));
                }
                catch (IOException ioEx)
                {
                    await ShowMessageAsync(_localizationSet?["FileInUse"] ?? "File in use", ioEx.Message);
                }
            }

            if (success > 0)
            {
                string message = success == 1
                    ? string.Format(_localizationSet?["WatermarkSuccessSingle"] ?? "Watermark added to: {0}", lastProcessed ?? string.Empty)
                    : string.Format(_localizationSet?["WatermarkSuccessMultiple"] ?? "Watermark added to {0} file(s).", success);

                var dlg = new ContentDialog
                {
                    Title = _localizationSet?["Success"] ?? "Success",
                    Content = message,
                    PrimaryButtonText = _localizationSet?["OpenOutput"] ?? "Open output",
                    CloseButtonText = _localizationSet?["Close"] ?? "Close"
                };

                var result = await _contentDialogService.ShowAsync(dlg, new CancellationTokenSource().Token);
                if (result == ContentDialogResult.Primary)
                {
                    OpenWithShell(OutputPath);
                }
            }
        }
        finally
        {
            IsProcessing = false;
        }
    }

    private bool CanApplyWatermark()
    {
        if (IsProcessing)
        {
            return false;
        }

        if (string.IsNullOrWhiteSpace(SelectedPath) || string.IsNullOrWhiteSpace(OutputPath))
        {
            return false;
        }

        if (RenameOutputFile && string.IsNullOrWhiteSpace(PrefixFileName))
        {
            return false;
        }

        if (UseTextWatermark)
        {
            return !string.IsNullOrWhiteSpace(WatermarkText);
        }

        return !string.IsNullOrWhiteSpace(WatermarkImagePath) && File.Exists(WatermarkImagePath);
    }

    #endregion

    #region Helpers

    private void AutoToggleRename()
    {
        if (string.IsNullOrWhiteSpace(OutputPath) || string.IsNullOrWhiteSpace(SelectedPath) || IsFolder)
        {
            return;
        }

        if (OutputPath == Path.GetDirectoryName(SelectedPath))
        {
            RenameOutputFile = true;
        }
    }

    private async Task LoadPreviewForFileAsync(string filePath)
    {
        try
        {
            using var pdfDocument = PdfiumViewer.PdfDocument.Load(filePath);
            PreviewPageCount = pdfDocument.PageCount;
            _currentPreviewFilePath = filePath;
            _currentPreviewPageIndex = 0;
            CurrentPreviewPage = pdfDocument.PageCount > 0 ? 1 : 0;
            _isManualZoom = false;

            if (pdfDocument.PageCount > 0)
            {
                var sizeInPoints = pdfDocument.PageSizes[0];
                int widthInPixels = (int)Math.Round(sizeInPoints.Width * 96f / 72f);
                int heightInPixels = (int)Math.Round(sizeInPoints.Height * 96f / 72f);
                var bitmap = await Task.Run(() => RenderPageToMemDC(pdfDocument, 0, widthInPixels, heightInPixels));

                PreviewImage = bitmap;
                PreviewWidth = bitmap.PixelWidth;
                PreviewHeight = bitmap.PixelHeight;
                UpdateWatermarkPreviewSize();
                UpdatePreviewPageDisplay();
                UpdatePreviewZoomFitIfNeeded(true);
            }
            else
            {
                ResetPreviewState();
            }
        }
        catch (iText.Kernel.Exceptions.BadPasswordException)
        {
            ResetPreviewState();
            await ShowMessageAsync(_localizationSet?["ProtectedFile"] ?? "Protected", string.Format(_localizationSet?["ProtectedFileContent"] ?? "{0}\nThis file is protected.", filePath));
        }
        catch (Exception ex)
        {
            ResetPreviewState();
            await ShowMessageAsync(_localizationSet?["OpenFileError"] ?? "Error", ex.Message);
        }
    }

    private static BitmapSource RenderPageToMemDC(PdfiumViewer.PdfDocument document, int page, int width, int height, float dpiX = 96, float dpiY = 96)
    {
        using var image = document.Render(page, width, height, dpiX, dpiY, true);
        return BitmapHelper.ToBitmapSource(image);
    }

    private async Task RenderPreviewPageAsync(int pageIndex)
    {
        if (string.IsNullOrWhiteSpace(_currentPreviewFilePath) || !File.Exists(_currentPreviewFilePath))
        {
            return;
        }

        try
        {
            using var pdfDocument = PdfiumViewer.PdfDocument.Load(_currentPreviewFilePath);
            PreviewPageCount = pdfDocument.PageCount;
            if (pdfDocument.PageCount == 0)
            {
                ResetPreviewState();
                return;
            }

            int clampedIndex = Math.Clamp(pageIndex, 0, pdfDocument.PageCount - 1);
            var sizeInPoints = pdfDocument.PageSizes[clampedIndex];
            int widthInPixels = (int)Math.Round(sizeInPoints.Width * 96f / 72f);
            int heightInPixels = (int)Math.Round(sizeInPoints.Height * 96f / 72f);
            var bitmap = await Task.Run(() => RenderPageToMemDC(pdfDocument, clampedIndex, widthInPixels, heightInPixels));

            PreviewImage = bitmap;
            PreviewWidth = bitmap.PixelWidth;
            PreviewHeight = bitmap.PixelHeight;
            _currentPreviewPageIndex = clampedIndex;
            CurrentPreviewPage = clampedIndex + 1;
            UpdateWatermarkPreviewSize();
            UpdatePreviewPageDisplay();
            UpdatePreviewZoomFitIfNeeded();
        }
        catch (Exception ex)
        {
            ResetPreviewState();
            await ShowMessageAsync(_localizationSet?["OpenFileError"] ?? "Error", ex.Message);
        }
    }

    private void UpdateWatermarkPreviewSize()
    {
        double contentWidth = WatermarkPreviewWidth;
        double contentHeight = WatermarkPreviewHeight;

        if (UseTextWatermark)
        {
            var textSize = MeasureWatermarkTextSize(WatermarkDisplayText, WatermarkFontSize);
            contentWidth = textSize.Width;
            contentHeight = textSize.Height;
        }
        else if (WatermarkImagePreview is BitmapSource imageSource)
        {
            double scaleFactor = Math.Max(0.05, WatermarkScale);
            contentWidth = Math.Max(40, imageSource.PixelWidth * scaleFactor);
            contentHeight = Math.Max(40, imageSource.PixelHeight * scaleFactor);
        }
        else
        {
            contentWidth = Math.Max(40, contentWidth);
            contentHeight = Math.Max(40, contentHeight);
        }

        WatermarkPreviewWidth = contentWidth;
        WatermarkPreviewHeight = contentHeight;

        UpdateWatermarkPreviewBounds();
    }

    private void UpdateWatermarkPreviewBounds()
    {
        double contentWidth = Math.Max(0, WatermarkPreviewWidth);
        double contentHeight = Math.Max(0, WatermarkPreviewHeight);

        double radians = Math.Abs(WatermarkRotation) * Math.PI / 180.0;
        double cos = Math.Cos(radians);
        double sin = Math.Sin(radians);

        double boundingWidth = Math.Abs(contentWidth * cos) + Math.Abs(contentHeight * sin);
        double boundingHeight = Math.Abs(contentWidth * sin) + Math.Abs(contentHeight * cos);

        WatermarkPreviewBoundingWidth = Math.Max(40, boundingWidth);
        WatermarkPreviewBoundingHeight = Math.Max(40, boundingHeight);

        UpdateWatermarkPreviewMargin();
    }

    private static WindowsSize MeasureWatermarkTextSize(string text, double fontSize)
    {
        if (fontSize <= 0)
        {
            return new WindowsSize(40, 40);
        }

        var formattedText = new FormattedText(
            string.IsNullOrWhiteSpace(text) ? " " : text,
            CultureInfo.CurrentUICulture,
            System.Windows.FlowDirection.LeftToRight,
            new Typeface(new System.Windows.Media.FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.SemiBold, FontStretches.Normal),
            fontSize,
            System.Windows.Media.Brushes.Black,
            1.0);

        double horizontalPadding = Math.Max(24, fontSize * 0.6);
        double verticalPadding = Math.Max(24, fontSize * 0.4);

        double width = Math.Max(80, formattedText.WidthIncludingTrailingWhitespace + horizontalPadding);
        double height = Math.Max(40, formattedText.Height + verticalPadding);

        return new WindowsSize(width, height);
    }

    private void UpdateWatermarkPreviewMargin()
    {
        if (PreviewWidth <= 0 || PreviewHeight <= 0)
        {
            return;
        }

        double x = PreviewWidth * (HorizontalPosition / 100.0);
        double y = PreviewHeight * (VerticalPosition / 100.0);

        double left = x - WatermarkPreviewBoundingWidth / 2;
        double top = y - WatermarkPreviewBoundingHeight / 2;

        WatermarkPreviewMargin = new Thickness(left, top, 0, 0);
    }

    private bool TryUpdateWatermarkImagePreview(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            WatermarkImagePreview = null;
            return false;
        }

        if (!File.Exists(path))
        {
            WatermarkImagePreview = null;
            return false;
        }

        try
        {
            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.UriSource = new Uri(path, UriKind.Absolute);
            bitmap.EndInit();
            bitmap.Freeze();
            WatermarkImagePreview = bitmap;
            return true;
        }
        catch
        {
            WatermarkImagePreview = null;
            return false;
        }
    }

    partial void OnHorizontalPositionChanged(double value) => UpdateWatermarkPreviewMargin();

    partial void OnVerticalPositionChanged(double value) => UpdateWatermarkPreviewMargin();

    partial void OnWatermarkFontSizeChanged(double value) => UpdateWatermarkPreviewSize();

    partial void OnWatermarkTextChanged(string value)
    {
        UpdateWatermarkPreviewSize();
        OnPropertyChanged(nameof(WatermarkDisplayText));
    }

    partial void OnWatermarkScaleChanged(double value) => UpdateWatermarkPreviewSize();

    partial void OnWatermarkRotationChanged(double value) => UpdateWatermarkPreviewSize();

    partial void OnUseTextWatermarkChanged(bool value)
    {
        if (WatermarkModeIndex != (value ? 0 : 1))
        {
            WatermarkModeIndex = value ? 0 : 1;
        }

        UpdateWatermarkPreviewSize();
    }

    partial void OnWatermarkImagePreviewChanged(ImageSource? value) => UpdateWatermarkPreviewSize();

    partial void OnWatermarkImagePathChanged(string value)
    {
        WatermarkImageFileName = string.IsNullOrWhiteSpace(value) ? string.Empty : Path.GetFileName(value);

        if (string.IsNullOrWhiteSpace(value))
        {
            WatermarkImagePreview = null;
            return;
        }

        if (!TryUpdateWatermarkImagePreview(value))
        {
            WatermarkImagePath = string.Empty;
            WatermarkModeIndex = 0;
        }
    }

    partial void OnWatermarkModeIndexChanged(int value)
    {
        UseTextWatermark = value == 0;
    }

    partial void OnWatermarkTextColorChanged(MediaColor value)
    {
        WatermarkTextBrush = CreateFrozenBrush(value);
    }

    partial void OnPreviewWidthChanged(double value)
    {
        UpdateWatermarkPreviewMargin();
        UpdatePreviewZoomFitIfNeeded();
    }

    partial void OnPreviewHeightChanged(double value)
    {
        UpdateWatermarkPreviewMargin();
        UpdatePreviewZoomFitIfNeeded();
    }

    partial void OnWatermarkPreviewWidthChanged(double value) => UpdateWatermarkPreviewBounds();

    partial void OnWatermarkPreviewHeightChanged(double value) => UpdateWatermarkPreviewBounds();

    partial void OnWatermarkPreviewBoundingWidthChanged(double value) => UpdateWatermarkPreviewMargin();

    partial void OnWatermarkPreviewBoundingHeightChanged(double value) => UpdateWatermarkPreviewMargin();

    partial void OnPreviewPageCountChanged(int value)
    {
        if (CurrentPreviewPage > value)
        {
            CurrentPreviewPage = value;
        }

        UpdatePreviewPageDisplay();
    }

    partial void OnCurrentPreviewPageChanged(int value)
    {
        UpdatePreviewPageDisplay();
    }

    partial void OnPreviewImageChanged(BitmapSource? value)
    {
        if (value is null)
        {
            _currentPreviewFilePath = null;
            _currentPreviewPageIndex = 0;
            PreviewWidth = 0;
            PreviewHeight = 0;
            PreviewPageCount = 0;
            CurrentPreviewPage = 0;
            PreviewZoom = 1;
            _isManualZoom = false;
            UpdatePreviewPageDisplay();
        }
    }

    partial void OnRenameOutputFileChanged(bool value) => UpdateOutputPreview();

    partial void OnPrefixFileNameChanged(string value) => UpdateOutputPreview();

    partial void OnOutputPathChanged(string value) => UpdateOutputPreview();

    partial void OnSelectedPathChanged(string value) => UpdateOutputPreview();

    partial void OnIsFolderChanged(bool value) => UpdateOutputPreview();

    private List<string> ResolveInputFiles()
    {
        if (IsFolder)
        {
            return Directory.GetFiles(SelectedPath, "*.pdf").ToList();
        }

        return string.IsNullOrWhiteSpace(SelectedPath) ? [] : [SelectedPath];
    }

    private string BuildOutputFilePath(string inputFile)
    {
        string outputName = Path.GetFileName(inputFile);
        if (!IsFolder && !string.Equals(inputFile, SelectedPath, StringComparison.OrdinalIgnoreCase))
        {
            outputName = Path.GetFileName(inputFile);
        }

        if (!IsFolder && RenameOutputFile && !string.IsNullOrWhiteSpace(PrefixFileName) && string.Equals(inputFile, SelectedPath, StringComparison.OrdinalIgnoreCase))
        {
            outputName = PrefixFileName + Path.GetFileName(inputFile);
        }
        else if (IsFolder && RenameOutputFile && !string.IsNullOrWhiteSpace(PrefixFileName))
        {
            outputName = PrefixFileName + Path.GetFileName(inputFile);
        }
        else if (!IsFolder && !RenameOutputFile && string.Equals(OutputPath, Path.GetDirectoryName(inputFile), StringComparison.OrdinalIgnoreCase))
        {
            var fileNameWithoutExtension = Path.GetFileNameWithoutExtension(inputFile);
            var extension = Path.GetExtension(inputFile);
            outputName = fileNameWithoutExtension + "_watermarked" + extension;
        }

        return Path.Combine(OutputPath, outputName);
    }

    [RelayCommand(CanExecute = nameof(CanGoToPreviousPage))]
    private async Task GoToPreviousPageAsync()
    {
        if (PreviewPageCount <= 0)
        {
            return;
        }

        await RenderPreviewPageAsync(_currentPreviewPageIndex - 1);
    }

    [RelayCommand(CanExecute = nameof(CanGoToNextPage))]
    private async Task GoToNextPageAsync()
    {
        if (PreviewPageCount <= 0)
        {
            return;
        }

        await RenderPreviewPageAsync(_currentPreviewPageIndex + 1);
    }

    [RelayCommand(CanExecute = nameof(CanManipulateZoom))]
    private void ZoomIn()
    {
        SetManualZoom(PreviewZoom + ZoomStep);
    }

    [RelayCommand(CanExecute = nameof(CanManipulateZoom))]
    private void ZoomOut()
    {
        SetManualZoom(PreviewZoom - ZoomStep);
    }

    [RelayCommand(CanExecute = nameof(CanManipulateZoom))]
    private void ResetZoom()
    {
        _isManualZoom = false;
        UpdatePreviewZoomFitIfNeeded(true);
    }

    private bool CanGoToPreviousPage() => PreviewPageCount > 0 && CurrentPreviewPage > 1;

    private bool CanGoToNextPage() => PreviewPageCount > 0 && CurrentPreviewPage < PreviewPageCount;

    private bool CanManipulateZoom() => PreviewImage is not null;

    private void ApplyWatermark(PdfDocument pdfDocument)
    {
        int totalPages = pdfDocument.GetNumberOfPages();
        for (int i = 1; i <= totalPages; i++)
        {
            var page = pdfDocument.GetPage(i);
            var pageSize = page.GetPageSize();

            float x = (float)(pageSize.GetWidth() * (HorizontalPosition / 100.0));
            float y = (float)(pageSize.GetHeight() * (1 - (VerticalPosition / 100.0)));

            var pdfCanvas = new PdfCanvas(page.NewContentStreamAfter(), page.GetResources(), pdfDocument);
            using var canvas = new Canvas(pdfCanvas, pageSize);

            if (UseTextWatermark)
            {
                var content = WatermarkDisplayText;
                var opacity = (float)Math.Clamp(WatermarkOpacity, 0f, 1f);

                pdfCanvas.SaveState();
                var graphicsState = new PdfExtGState().SetFillOpacity(opacity);
                pdfCanvas.SetExtGState(graphicsState);

                float scaledFontSize = (float)(WatermarkFontSize * 72.0 / 96.0);

                canvas
                    .SetFontSize(scaledFontSize)
                    .SetFontColor(new DeviceRgb(WatermarkTextColor.R, WatermarkTextColor.G, WatermarkTextColor.B))
                    .ShowTextAligned(
                        content,
                        x,
                        y,
                        iText.Layout.Properties.TextAlignment.CENTER,
                        iText.Layout.Properties.VerticalAlignment.MIDDLE,
                        (float)(-Math.PI * WatermarkRotation / 180.0));

                pdfCanvas.RestoreState();
            }
            else if (!string.IsNullOrWhiteSpace(WatermarkImagePath) && File.Exists(WatermarkImagePath))
            {
                var imageData = ImageDataFactory.Create(WatermarkImagePath);
                var image = new iText.Layout.Element.Image(imageData);
                var scale = (float)Math.Max(0.05, WatermarkScale);
                const float pointsPerDip = 72f / 96f;
                var width = image.GetImageWidth() * scale * pointsPerDip;
                var height = image.GetImageHeight() * scale * pointsPerDip;
                image.ScaleAbsolute(width, height);
                image.SetFixedPosition(x - width / 2, y - height / 2);
                image.SetOpacity((float)Math.Clamp(WatermarkOpacity, 0f, 1f));
                image.SetRotationAngle(-Math.PI * WatermarkRotation / 180.0);
                canvas.Add(image);
            }

        }
    }

    private PdfWriter CreatePdfWriterWithEncryption(string fileName, byte[] userPassword, byte[] ownerPassword, int permissions)
    {
        var writerProperties = new WriterProperties()
            .SetStandardEncryption(userPassword, ownerPassword, permissions, EncryptionConstants.ENCRYPTION_AES_256 | EncryptionConstants.DO_NOT_ENCRYPT_METADATA);
        return new PdfWriter(fileName, writerProperties);
    }

    private async Task<(byte[] userPassword, byte[] ownerPassword, bool shouldContinue)> PromptForPasswordAsync()
    {
        var userPwdBox = new Wpf.Ui.Controls.PasswordBox
        {
            PlaceholderText = _localizationSet?["UserPassword"] ?? "User password",
            PasswordChar = '●'
        };

        var ownerPwdBox = new Wpf.Ui.Controls.PasswordBox
        {
            PlaceholderText = _localizationSet?["OwnerPassword"] ?? "Owner password",
            PasswordChar = '●',
            Margin = new Thickness(0, 5, 0, 0)
        };

        var caption = new Wpf.Ui.Controls.TextBlock
        {
            Text = _localizationSet?["ProtectPasswordCaption"] ?? "The output PDF will be protected with these passwords.",
            Margin = new Thickness(0, 5, 0, 0),
            FontTypography = FontTypography.Caption,
            TextWrapping = TextWrapping.Wrap
        };

        var stack = new System.Windows.Controls.StackPanel
        {
            MaxWidth = 320
        };

        stack.Children.Add(userPwdBox);
        stack.Children.Add(ownerPwdBox);
        stack.Children.Add(caption);

        var dialog = new ContentDialog
        {
            Title = _localizationSet?["EnterPassword"] ?? "Enter password",
            Content = stack,
            PrimaryButtonText = _localizationSet?["Continue"] ?? "Continue",
            CloseButtonText = _localizationSet?["Cancel"] ?? "Cancel"
        };

        var result = await _contentDialogService.ShowAsync(dialog, new CancellationTokenSource().Token);
        if (result == ContentDialogResult.Primary)
        {
            return (Encoding.UTF8.GetBytes(userPwdBox.Password), Encoding.UTF8.GetBytes(ownerPwdBox.Password), true);
        }

        return ([], [], false);
    }

    public void UpdatePreviewViewportSize(double width, double height)
    {
        _previewAvailableWidth = width;
        _previewAvailableHeight = height;
        UpdatePreviewZoomFitIfNeeded();
    }

    private void UpdatePreviewZoomFitIfNeeded(bool force = false)
    {
        if (!_isManualZoom || force)
        {
            if (PreviewWidth <= 0 || PreviewHeight <= 0 || _previewAvailableWidth <= 0 || _previewAvailableHeight <= 0)
            {
                if (force)
                {
                    PreviewZoom = 1;
                }

                return;
            }

            double widthScale = _previewAvailableWidth / PreviewWidth;
            double heightScale = _previewAvailableHeight / PreviewHeight;
            double fitScale = Math.Min(widthScale, heightScale);

            if (!double.IsFinite(fitScale) || fitScale <= 0)
            {
                fitScale = 1;
            }

            PreviewZoom = Math.Clamp(fitScale, MinZoom, MaxZoom);
        }
    }

    private void SetManualZoom(double requestedZoom)
    {
        if (PreviewImage is null)
        {
            return;
        }

        _isManualZoom = true;
        PreviewZoom = Math.Clamp(requestedZoom, MinZoom, MaxZoom);
    }

    private void UpdatePreviewPageDisplay()
    {
        if (PreviewPageCount > 0 && CurrentPreviewPage > 0)
        {
            PreviewPageDisplay = $"{CurrentPreviewPage} / {PreviewPageCount}";
        }
        else
        {
            PreviewPageDisplay = "0 / 0";
        }
    }

    private void ResetPreviewState()
    {
        PreviewImage = null;
        PreviewWidth = 0;
        PreviewHeight = 0;
        PreviewPageCount = 0;
        CurrentPreviewPage = 0;
        PreviewZoom = 1;
        _currentPreviewFilePath = null;
        _currentPreviewPageIndex = 0;
        _isManualZoom = false;
        UpdatePreviewPageDisplay();
    }

    private void UpdateOutputPreview()
    {
        try
        {
            if (string.IsNullOrWhiteSpace(OutputPath))
            {
                OutputFilePreview = string.Empty;
                return;
            }

            string? sampleInput = null;

            if (IsFolder)
            {
                if (Directory.Exists(SelectedPath))
                {
                    sampleInput = Directory.GetFiles(SelectedPath, "*.pdf").FirstOrDefault();
                }
            }
            else if (File.Exists(SelectedPath))
            {
                sampleInput = SelectedPath;
            }

            if (string.IsNullOrWhiteSpace(sampleInput))
            {
                OutputFilePreview = string.Empty;
                return;
            }

            var outputFile = BuildOutputFilePath(sampleInput);
            var fileName = Path.GetFileName(outputFile);

            if (string.IsNullOrWhiteSpace(fileName))
            {
                OutputFilePreview = string.Empty;
                return;
            }

            var template = _localizationSet?["WatermarkSampleOutput"] ?? "Resulting file name: {0}";
            OutputFilePreview = string.Format(template, fileName);
        }
        catch
        {
            OutputFilePreview = string.Empty;
        }
    }

    private async Task ShowMessageAsync(string title, string content)
    {
        var dialog = new ContentDialog
        {
            Title = title,
            Content = content,
            CloseButtonText = _localizationSet?["Close"] ?? "Close"
        };

        await _contentDialogService.ShowAsync(dialog, new CancellationTokenSource().Token);
    }

    private static void OpenWithShell(string path)
    {
        try
        {
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = path,
                UseShellExecute = true
            };
            System.Diagnostics.Process.Start(psi);
        }
        catch
        {
        }
    }

    private static SolidColorBrush CreateFrozenBrush(MediaColor color)
    {
        var brush = new SolidColorBrush(color);
        if (brush.CanFreeze)
        {
            brush.Freeze();
        }

        return brush;
    }

    #endregion
}
