﻿using iText.Kernel.Pdf;
using CommunityToolkit.Mvvm.Messaging;
using Lepo.i18n;
using PDFWand.Messenger;
using Microsoft.Win32;
//using PDFWizard.Model;
//using PDFWizard.Properties;
using System;
using System.Windows;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using Wpf.Ui;
using Wpf.Ui.Controls;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Threading;
using PDFWand.Model;
using PDFWand.CoreHelper;
//using PDFWizard.CoreHelper;

namespace PDFWand.ViewModels;

public partial class MergeViewModel : ObservableObject
{
    private readonly IContentDialogService _contentDialogService;
    private readonly ILocalizationProvider _localizationProvider;
    private LocalizationSet? _localizationSet;
    private readonly IMessenger _messenger;
    private CancellationTokenSource? _metadataCancellation;

    public MergeViewModel(IContentDialogService contentDialogService,
        ILocalizationProvider localizationProvider,
        IMessenger messenger)
    {
        _contentDialogService = contentDialogService;
        _localizationProvider = localizationProvider;
        _messenger = messenger;
        _localizationSet = _localizationProvider.GetLocalizationSet(_localizationProvider.GetCulture().Name);

        _messenger.Register<LanguageChangedMessage>(this, (_, message) =>
        {
            _localizationSet = _localizationProvider.GetLocalizationSet(message.Culture.Name);
        });

        ListInputPdf.CollectionChanged += OnListInputPdfCollectionChanged;
        UpdateFileDependentState();
    }


    [ObservableProperty]
    private ObservableCollection<InputPdf> _listInputPdf = [];

    [ObservableProperty]
    private bool _hasFiles;

    [ObservableProperty]
    private int _totalPage;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(CancelMetadataProcessingCommand))]
    private bool _isProcessingFiles;

    [ObservableProperty]
    private int _processedFileCount;

    [ObservableProperty]
    private int _totalFilesToProcess;

    [ObservableProperty]
    private bool _setPassword;

    //protect option
    [ObservableProperty]
    private bool _allowPrint = true;

    [ObservableProperty]
    private bool _allowCopy = true;

    [ObservableProperty]
    private bool _allowFillIn = true;

    [ObservableProperty]
    private bool _allowModifyAnnotations = true;

    [ObservableProperty]
    private bool _allowModifyContents = true;

    [ObservableProperty]
    private bool _allowScreenReaders = true;

    [ObservableProperty]
    private bool _allowAssembly = true;
    //private bool _allowDegradedPrint = true;






    //
    //private async void MergePdf()
    //{

    //    var userPass = Encoding.UTF8.GetBytes("1111");
    //    var ownerPass = Encoding.UTF8.GetBytes("1111");
    //    int permisions = 0;
    //    if (SetPassword)
    //    {

    //        #region Permission builder

    //        if (AllowFillIn)
    //        {
    //            permisions = permisions | EncryptionConstants.ALLOW_FILL_IN;
    //        }

    //        if (AllowCopy)
    //        {
    //            permisions = permisions | EncryptionConstants.ALLOW_COPY;
    //        }

    //        if (AllowPrint)
    //        {
    //            permisions = permisions | EncryptionConstants.ALLOW_PRINTING;
    //            permisions = permisions | EncryptionConstants.ALLOW_DEGRADED_PRINTING;
    //        }

    //        if (AllowModifyAnnotations)
    //        {
    //            permisions = permisions | EncryptionConstants.ALLOW_MODIFY_ANNOTATIONS;
    //        }

    //        if (AllowModifyContents)
    //        {
    //            permisions = permisions | EncryptionConstants.ALLOW_MODIFY_CONTENTS;
    //        }

    //        if (AllowScreenReaders)
    //        {
    //            permisions = permisions | EncryptionConstants.ALLOW_SCREENREADERS;
    //        }

    //        if (AllowAssembly)
    //        {
    //            permisions = permisions | EncryptionConstants.ALLOW_ASSEMBLY;
    //        }

    //        //if (AllowDegradedPrint)
    //        //{
    //        //    permisions = permisions | EncryptionConstants.ALLOW_DEGRADED_PRINTING;
    //        //}
    //        #endregion

    //        // Show password input prompt

    //        var dlgContent = new StackPanel();
    //        var pwdBox = new Wpf.Ui.Controls.PasswordBox
    //        {
    //            PlaceholderText = Resources.Password,
    //            PasswordChar = '●'
    //        };
    //        var textBlock = new Wpf.Ui.Controls.TextBlock
    //        {
    //            Text = Resources.ProtectPasswordCaption,
    //            Margin = new Thickness(0, 5, 0, 0),
    //            FontTypography = FontTypography.Caption,
    //            TextWrapping = TextWrapping.Wrap
    //        };
    //        dlgContent.Children.Add(pwdBox);
    //        dlgContent.Children.Add(textBlock);

    //        var contentDlg = new ContentDialog
    //        {
    //            Title = Resources.EnterProtectPassword,
    //            Content = dlgContent,
    //            PrimaryButtonText = Resources.Continue

    //        };
    //        CancellationTokenSource cts = new CancellationTokenSource();

    //        ContentDialogResult result = await _contentDialogService.ShowAsync(contentDlg, cts.Token);
    //        if (result == ContentDialogResult.Primary)
    //        {
    //            userPass = Encoding.UTF8.GetBytes(pwdBox.Password);
    //            ownerPass = Encoding.UTF8.GetBytes(pwdBox.Password);
    //        }
    //    }

    //    var s = new SaveFileDialog()
    //    {
    //        Filter = "Pdf file|*.pdf"
    //    };
    //    if (s.ShowDialog() == false)
    //    {
    //        return;
    //    }
    //    PdfWriter writer;
    //    if (SetPassword)
    //    {
    //        var props = new WriterProperties()
    //        .SetStandardEncryption(userPass, ownerPass, permisions, EncryptionConstants.ENCRYPTION_AES_256 | EncryptionConstants.DO_NOT_ENCRYPT_METADATA);
    //        writer = new PdfWriter(s.FileName, props);
    //    }
    //    else
    //    {
    //        writer = new PdfWriter(s.FileName);
    //    }
    //    var outputDoc = new PdfDocument(writer);

    //    foreach (var item in ListInputPdf)
    //    {
    //        if (string.IsNullOrEmpty(item.OpenPassword))
    //        {
    //            var reader = new PdfReader(item.FullPath);
    //            var doc = new PdfDocument(reader);
    //            reader.SetUnethicalReading(true);
    //            doc.GetCatalog().Remove(PdfName.Perms);
    //            doc.CopyPagesTo(1, item.PageCount, outputDoc);
    //            doc.Close();
    //            reader.Close();
    //        }
    //        else
    //        {
    //            var reader = new PdfReader(item.FullPath,
    //            new ReaderProperties().SetPassword(Encoding.UTF8.GetBytes(item.OpenPassword)));
    //            reader.SetUnethicalReading(true);
    //            var doc = new PdfDocument(reader);
    //            doc.CopyPagesTo(1, item.PageCount, outputDoc);
    //            doc.Close();
    //            reader.Close();
    //        }
    //    }
    //    //outputDoc.GetCatalog().Remove(PdfName.Perms);
    //    outputDoc.Close();
    //    writer.Close();

    //    string msg = string.Format(Resources.MergeSuccessContent, ListInputPdf.Count, ListInputPdf.Sum(x => x.PageCount));
    //    var dlg = new ContentDialog
    //    {
    //        Title = Resources.Success,
    //        Content = msg,
    //        PrimaryButtonText = Resources.Open
    //    };
    //    var rs = await _contentDialogService.ShowAsync(dlg, new System.Threading.CancellationTokenSource().Token);
    //    if (rs == ContentDialogResult.Primary)
    //    {
    //        Process.Start(s.FileName);
    //    }

    //}

    [RelayCommand]
    private async void JoinPdf()
    {
        var per = new BuildPermissions
        {
            AllowAssembly = AllowAssembly,
            AllowCopy = AllowCopy,
            AllowFillIn = AllowFillIn,
            AllowModifyAnnotations = AllowModifyAnnotations,
            AllowModifyContents = AllowModifyContents,
            AllowPrint = AllowPrint,
            AllowScreenReaders = AllowScreenReaders,
        };
        var userPass = Encoding.UTF8.GetBytes("");
        var ownerPass = Encoding.UTF8.GetBytes("");
        var isContinue = false;
        int permissions = per.Build();

        if (SetPassword)
        {
            (userPass, ownerPass, isContinue) = await PromptForPasswordAsync();
        }

        if (SetPassword && !isContinue)
        {
            return;
        }

        var saveFileDialog = new Microsoft.Win32.SaveFileDialog()
        {
            Filter = "PDF file|*.pdf",
            FileName = string.Format(_localizationSet!["MergeDefaultFileName"], ListInputPdf.Count)
        };
        if (saveFileDialog.ShowDialog() == false) return;

        using var writer = SetPassword
            ? CreatePdfWriterWithEncryption(saveFileDialog.FileName, userPass, ownerPass, permissions)
            : new PdfWriter(saveFileDialog.FileName);
        using var outputDoc = new PdfDocument(writer);

        foreach (var item in ListInputPdf)
        {
            using var reader = string.IsNullOrEmpty(item.OpenPassword)
                ? new PdfReader(item.FullPath)
                : new PdfReader(item.FullPath, new ReaderProperties().SetPassword(Encoding.UTF8.GetBytes(item.OpenPassword)));
            reader.SetUnethicalReading(true);
            using var doc = new PdfDocument(reader);
            doc.CopyPagesTo(1, item.PageCount, outputDoc);
        }

        await ShowSuccessMessageAsync(ListInputPdf.Count, TotalPage, saveFileDialog.FileName);

    }

    private async Task<(byte[], byte[], bool)> PromptForPasswordAsync()
    {
        var userPwdBox = new Wpf.Ui.Controls.PasswordBox
        {
            PlaceholderText = _localizationSet!["UserPassword"],
            PasswordChar = '●'
        };

        var ownerPwdBox = new Wpf.Ui.Controls.PasswordBox
        {
            PlaceholderText = _localizationSet!["OwnerPassword"],
            PasswordChar = '●',
            Margin = new Thickness(0, 5, 0, 0)
        };

        var textBlock = new Wpf.Ui.Controls.TextBlock
        {
            Text = _localizationSet!["ProtectPasswordCaption"],
            Margin = new Thickness(0, 5, 0, 0),
            FontTypography = FontTypography.Caption,
            TextWrapping = TextWrapping.Wrap
        };

        var dialogContent = new StackPanel
        {
            MaxWidth = 320
        };
        dialogContent.Children.Add(userPwdBox);
        dialogContent.Children.Add(ownerPwdBox);
        dialogContent.Children.Add(textBlock);

        var contentDialog = new ContentDialog
        {
            Title = _localizationSet!["EnterPassword"],
            Content = dialogContent,
            PrimaryButtonText = _localizationSet!["Continue"],
            CloseButtonText = _localizationSet!["Cancel"],
            DialogWidth = 100

        };
        var confirm = await _contentDialogService.ShowAsync(contentDialog, new CancellationTokenSource().Token);
        if (confirm == ContentDialogResult.Primary)
        {
            var userPassword = Encoding.UTF8.GetBytes(userPwdBox.Password);
            var ownerPassword = Encoding.UTF8.GetBytes(ownerPwdBox.Password);
            return (userPassword, ownerPassword, true);
        }
        else
        {
            return (Encoding.UTF8.GetBytes(""), Encoding.UTF8.GetBytes(""), false);
        }

    }


    private PdfWriter CreatePdfWriterWithEncryption(string fileName, byte[] userPass, byte[] ownerPass, int permissions)
    {
        var writerProperties = new WriterProperties()
            .SetStandardEncryption(userPass, ownerPass, permissions, EncryptionConstants.ENCRYPTION_AES_256 | EncryptionConstants.DO_NOT_ENCRYPT_METADATA);
        return new PdfWriter(fileName, writerProperties);
    }

    private async Task ShowSuccessMessageAsync(int fileCount, int pageCount, string fileName)
    {
        string message = string.Format(_localizationSet!["MergeSuccessContent"], fileCount, pageCount);
        var contentDialog = new ContentDialog
        {
            Title = _localizationSet!["Success"],
            Content = message,
            PrimaryButtonText = _localizationSet!["Open"],
            CloseButtonText = _localizationSet!["Close"]
        };

        if (await _contentDialogService.ShowAsync(contentDialog, CancellationToken.None) == ContentDialogResult.Primary)
        {
            Process.Start(fileName);
        }
    }






    //public bool AllowDegradedPrint { get => _allowDegradedPrint; set => SetProperty(ref _allowDegradedPrint, value); }


    [RelayCommand]
    private void RemoveFile(object param)
    {
        if (param is not InputPdf file)
        {
            return;
        }

        var index = ListInputPdf.IndexOf(file);
        if (index < 0)
        {
            return;
        }

        ListInputPdf.RemoveAt(index);
        for (int i = index; i < ListInputPdf.Count; i++)
        {
            ListInputPdf[i].No = i + 1;
        }

        TotalPage = Math.Max(0, TotalPage - file.PageCount);
        UpdateFileDependentState();
    }

    [RelayCommand]
    private async Task AddFileToList()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "Pdf file|*.pdf",
            Multiselect = true
        };
        if (dialog.ShowDialog() == false)
        {
            return;
        }

        DisposeMetadataCancellation(true);
        ResetMetadataProgress(true);

        var selectedFiles = dialog.FileNames;
        if (selectedFiles.Length == 0)
        {
            return;
        }

        _metadataCancellation = new CancellationTokenSource();
        var cancellationToken = _metadataCancellation.Token;

        var fileInfos = selectedFiles
            .Select((path, index) => (Index: index, Info: new FileInfo(path)))
            .ToList();

        IsProcessingFiles = true;
        TotalFilesToProcess = fileInfos.Count;
        ProcessedFileCount = 0;

        try
        {
            var maxConcurrency = Math.Max(1, Environment.ProcessorCount / 2);
            using var throttler = new SemaphoreSlim(maxConcurrency);
            var processingTasks = fileInfos
                .Select(item => ProcessFileAsync(item.Info, item.Index, cancellationToken, throttler))
                .ToList();

            var results = await Task.WhenAll(processingTasks);

            foreach (var result in results.OrderBy(r => r.Index))
            {
                cancellationToken.ThrowIfCancellationRequested();
                var info = result.Info;
                if (info is null)
                {
                    continue;
                }

                var fileInfo = result.FileInfo;
                var pdf = new InputPdf
                {
                    FileName = fileInfo.Name,
                    Size = fileInfo.Length,
                    FullPath = fileInfo.FullName,
                    PageCount = info.PageCount,
                    ModifiedDate = fileInfo.LastWriteTime,
                    No = ListInputPdf.Count + 1
                };

                if (info.HasPassword)
                {
                    pdf.OpenPassword = info.Password;
                }

                ListInputPdf.Add(pdf);
                TotalPage += pdf.PageCount;
            }

            UpdateFileDependentState();
        }
        catch (OperationCanceledException)
        {
        }
        finally
        {
            ResetMetadataProgress(true);
            DisposeMetadataCancellation(false);
        }
    }

    [RelayCommand(CanExecute = nameof(CanCancelMetadataProcessing))]
    private void CancelMetadataProcessing()
    {
        DisposeMetadataCancellation(true);
        ResetMetadataProgress(true);
    }

    private bool CanCancelMetadataProcessing()
    {
        return IsProcessingFiles;
    }

    private async Task<FileProcessingResult> ProcessFileAsync(FileInfo fileInfo, int index, CancellationToken cancellationToken, SemaphoreSlim throttler)
    {
        await throttler.WaitAsync(cancellationToken);
        try
        {
            var info = await GetPdfInfoAsync(fileInfo.FullName, cancellationToken);
            return new FileProcessingResult(index, fileInfo, info);
        }
        finally
        {
            throttler.Release();
            ReportMetadataProgress(cancellationToken);
        }
    }

    private async Task<PdfInfoResult?> GetPdfInfoAsync(string pdfFile, CancellationToken cancellationToken)
    {
        try
        {
            return await LoadPdfMetadataAsync(pdfFile, null, cancellationToken);
        }
        catch (iText.Kernel.Exceptions.BadPasswordException)
        {
            var password = await PromptForFilePasswordAsync(pdfFile, cancellationToken);
            if (string.IsNullOrEmpty(password))
            {
                return null;
            }

            try
            {
                return await LoadPdfMetadataAsync(pdfFile, password, cancellationToken);
            }
            catch (iText.Kernel.Exceptions.BadPasswordException)
            {
                await ShowWrongPasswordDialogAsync(pdfFile, cancellationToken);
                return null;
            }
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex)
        {
            await ShowOpenFileErrorAsync(ex.Message, cancellationToken);
            return null;
        }
    }

    private static Task<PdfInfoResult> LoadPdfMetadataAsync(string pdfFile, string? password, CancellationToken cancellationToken)
    {
        return Task.Run(() =>
        {
            cancellationToken.ThrowIfCancellationRequested();

            using var reader = string.IsNullOrEmpty(password)
                ? new PdfReader(pdfFile)
                : new PdfReader(pdfFile, new ReaderProperties().SetPassword(Encoding.UTF8.GetBytes(password)));
            reader.SetUnethicalReading(true);
            using var document = new PdfDocument(reader);
            var pageCount = document.GetNumberOfPages();
            return new PdfInfoResult(pageCount, !string.IsNullOrEmpty(password), password);
        }, cancellationToken);
    }

    private async Task<string?> PromptForFilePasswordAsync(string pdfFile, CancellationToken cancellationToken)
    {
        var textBlock = new Wpf.Ui.Controls.TextBlock
        {
            Text = string.Format(_localizationSet!["PasswordForFile"], Path.GetFileName(pdfFile)),
            Margin = new Thickness(0, 0, 0, 5)
        };
        var passwordBox = new Wpf.Ui.Controls.PasswordBox
        {
            PlaceholderText = _localizationSet!["Password"],
            PasswordChar = '●'
        };
        var container = new StackPanel();
        container.Children.Add(textBlock);
        container.Children.Add(passwordBox);

        var dialog = new ContentDialog
        {
            Title = _localizationSet!["EnterPassword"],
            Content = container,
            PrimaryButtonText = _localizationSet!["Continue"],
            CloseButtonText = _localizationSet!["Cancel"]
        };

        var result = await ShowDialogAsync(dialog, cancellationToken);
        return result == ContentDialogResult.Primary ? passwordBox.Password : null;
    }

    private Task ShowWrongPasswordDialogAsync(string pdfFile, CancellationToken cancellationToken)
    {
        var dialog = new ContentDialog
        {
            Title = _localizationSet!["WrongPassword"],
            Content = string.Format(_localizationSet!["WrongPasswordContent"], Path.GetFileName(pdfFile)),
            CloseButtonText = _localizationSet!["Close"]
        };

        return ShowDialogAsync(dialog, cancellationToken);
    }

    private Task ShowOpenFileErrorAsync(string message, CancellationToken cancellationToken)
    {
        var dialog = new ContentDialog
        {
            Title = _localizationSet!["OpenFileError"],
            Content = message,
            CloseButtonText = _localizationSet!["Close"]
        };

        return ShowDialogAsync(dialog, cancellationToken);
    }

    private Task<ContentDialogResult> ShowDialogAsync(ContentDialog dialog, CancellationToken cancellationToken)
    {
        if (System.Windows.Application.Current?.Dispatcher?.CheckAccess() == true)
        {
            return _contentDialogService.ShowAsync(dialog, cancellationToken);
        }

        var tcs = new TaskCompletionSource<ContentDialogResult>();
        System.Windows.Application.Current!.Dispatcher.InvokeAsync(async () =>
        {
            try
            {
                var result = await _contentDialogService.ShowAsync(dialog, cancellationToken);
                tcs.TrySetResult(result);
            }
            catch (Exception ex)
            {
                tcs.TrySetException(ex);
            }
        });

        return tcs.Task;
    }

    private void ReportMetadataProgress(CancellationToken cancellationToken)
    {
        if (cancellationToken.IsCancellationRequested)
        {
            return;
        }

        void Increment()
        {
            ProcessedFileCount++;
        }

        if (System.Windows.Application.Current?.Dispatcher?.CheckAccess() == true)
        {
            Increment();
        }
        else
        {
            System.Windows.Application.Current!.Dispatcher.Invoke(Increment);
        }
    }

    private void DisposeMetadataCancellation(bool cancel)
    {
        if (_metadataCancellation is null)
        {
            return;
        }

        if (cancel && !_metadataCancellation.IsCancellationRequested)
        {
            _metadataCancellation.Cancel();
        }

        _metadataCancellation.Dispose();
        _metadataCancellation = null;
    }

    private void ResetMetadataProgress(bool clearCounts)
    {
        IsProcessingFiles = false;
        if (clearCounts)
        {
            ProcessedFileCount = 0;
            TotalFilesToProcess = 0;
        }
    }

    private sealed record PdfInfoResult(int PageCount, bool HasPassword, string? Password);

    private sealed record FileProcessingResult(int Index, FileInfo FileInfo, PdfInfoResult? Info);

    partial void OnListInputPdfChanging(ObservableCollection<InputPdf> value)
    {
        if (value is not null)
        {
            value.CollectionChanged -= OnListInputPdfCollectionChanged;
        }
    }

    partial void OnListInputPdfChanged(ObservableCollection<InputPdf> value)
    {
        if (value is not null)
        {
            value.CollectionChanged += OnListInputPdfCollectionChanged;
        }

        UpdateFileDependentState();
    }

    private void OnListInputPdfCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        UpdateFileDependentState();
    }

    private void UpdateFileDependentState()
    {
        HasFiles = ListInputPdf.Count > 0;

        if (!HasFiles)
        {
            SetPassword = false;
            TotalPage = 0;
        }
    }
}
