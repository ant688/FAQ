﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using iText.Kernel.Pdf;
using CommunityToolkit.Mvvm.Messaging;
using Lepo.i18n;
using PDFWand.Messenger;
using System.IO;
using System.Threading;
using Wpf.Ui.Controls;
using Wpf.Ui;
using System.Windows.Controls;
using System.Diagnostics;
using PDFWand.CoreHelper;
using Microsoft.Win32;


namespace PDFWand.ViewModels;

public partial class ProtectViewModel : ObservableObject
{
    private readonly IContentDialogService _contentDialogService;
    private readonly ILocalizationProvider _localizationProvider;
    private LocalizationSet? _localizationSet;
    private readonly IMessenger _messenger;

    public ProtectViewModel(IContentDialogService contentDialogService,
        ILocalizationProvider localizationProvider,
        IMessenger messenger)
    {
        _contentDialogService = contentDialogService;
        _localizationProvider = localizationProvider;
        _messenger = messenger;
        _localizationSet = _localizationProvider.GetLocalizationSet(_localizationProvider.GetCulture().Name);

        _messenger.Register<LanguageChangedMessage>(this, (_, message) =>
        {
            _localizationSet = _localizationProvider.GetLocalizationSet(message.Culture.Name);
        });
    }

    #region Fields

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ProtectPdfCommand))]
    [NotifyCanExecuteChangedFor(nameof(UnProtectPdfCommand))]
    private string _selectedPath;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ProtectPdfCommand))]
    [NotifyCanExecuteChangedFor(nameof(UnProtectPdfCommand))]
    private string _outputPath;

    [ObservableProperty]
    private bool _isFolder;

    [ObservableProperty]
    private Visibility _openedFilePathVisibility = Visibility.Collapsed;

    [ObservableProperty]
    private Visibility _outputPathVisibility = Visibility.Collapsed;

    [ObservableProperty]
    private string _pickedFileOrFolder;


    [ObservableProperty]
    private string _pdfPassword;
    //protect option

    [ObservableProperty]
    private bool _allowPrint = true;

    [ObservableProperty]
    private bool _allowCopy = true;

    [ObservableProperty]
    private bool _allowFillIn = true;

    [ObservableProperty]
    private bool _allowModifyAnnotations = true;

    [ObservableProperty]
    private bool _allowModifyContents = true;

    [ObservableProperty]
    private bool _allowScreenReaders = true;

    [ObservableProperty]
    private bool _allowAssembly = true;

    [ObservableProperty]
    private bool _allowDegradedPrint = true;


    [ObservableProperty]
    private ControlAppearance _openFileButtonApperance = ControlAppearance.Transparent;

    [ObservableProperty]
    private ControlAppearance _openFolderButtonApperance = ControlAppearance.Transparent;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ProtectPdfCommand))]
    [NotifyCanExecuteChangedFor(nameof(UnProtectPdfCommand))]
    private bool _renameOutputFile;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ProtectPdfCommand))]
    [NotifyCanExecuteChangedFor(nameof(UnProtectPdfCommand))]
    private string _prefixFileName;
    #endregion




    #region METHODS

    [RelayCommand]
    private void OpenFile()
    {
        Microsoft.Win32.OpenFileDialog o = new()
        {
            Filter = "PDF file|*.pdf",
            Title = _localizationSet!["OpenFile"],
            InitialDirectory = Environment.SpecialFolder.MyDocuments.ToString()
        };
        if (o.ShowDialog() == true)
        {
            IsFolder = false;
            SelectedPath = o.FileName;
            PickedFileOrFolder = _localizationSet!["SelectedFileLabel"];
            OpenedFilePathVisibility = Visibility.Visible;
            OpenFileButtonApperance = ControlAppearance.Info;
            OpenFolderButtonApperance = ControlAppearance.Transparent;

            if (!string.IsNullOrEmpty(OutputPath) && !string.IsNullOrEmpty(SelectedPath))
            {
                if ((IsFolder && OutputPath == SelectedPath)
                     || (!IsFolder && OutputPath == Path.GetDirectoryName(SelectedPath)))
                {
                    RenameOutputFile = true;
                }
            }
        }
    }


    [RelayCommand]
    private void OpenFolder()
    {
        var folder = new OpenFolderDialog
        {
            Title = _localizationSet!["SelectPdfFolderTitle"],
            Multiselect = false
        };

        if (folder.ShowDialog() == true)
        {
            IsFolder = true;
            PickedFileOrFolder = _localizationSet!["SelectedFolderLabel"];
            SelectedPath = folder.FolderName;
            OpenedFilePathVisibility = Visibility.Visible;
            OpenFileButtonApperance = ControlAppearance.Transparent;
            OpenFolderButtonApperance = ControlAppearance.Info;

            if (!string.IsNullOrEmpty(OutputPath) && !string.IsNullOrEmpty(SelectedPath))
            {
                if ((IsFolder && OutputPath == SelectedPath)
                     || (!IsFolder && OutputPath == Path.GetDirectoryName(SelectedPath)))
                {
                    RenameOutputFile = true;
                }
            }
        }
    }

    [RelayCommand]
    private void OpenOutputFolder()
    {
        var folder = new OpenFolderDialog
        {
            Title = _localizationSet!["SelectOutputFolderTitle"],
            Multiselect = false
        };

        if (folder.ShowDialog() == true)
        {
            OutputPath = folder.FolderName;
            OutputPathVisibility = Visibility.Visible;

            if (!string.IsNullOrEmpty(OutputPath) && !string.IsNullOrEmpty(SelectedPath))
            {
                if ((IsFolder && OutputPath == SelectedPath)
                     || (!IsFolder && OutputPath == Path.GetDirectoryName(SelectedPath)))
                {
                    RenameOutputFile = true;
                }
            }
        }
    }


    [RelayCommand(CanExecute = nameof(CanStartProtectPdf))]
    private async Task ProtectPdfAsync()
    {
        var per = new BuildPermissions
        {
            AllowAssembly = AllowAssembly,
            AllowCopy = AllowCopy,
            AllowFillIn = AllowFillIn,
            AllowModifyAnnotations = AllowModifyAnnotations,
            AllowModifyContents = AllowModifyContents,
            AllowPrint = AllowPrint,
            AllowScreenReaders = AllowScreenReaders,
        };
        var userPass = Encoding.UTF8.GetBytes("");
        var ownerPass = Encoding.UTF8.GetBytes("");
        int permissions = per.Build();


        var dlgContent = new StackPanel
        {
            MaxWidth = 300
        };
        //var b = new Wpf.Ui.Controls.Button();
        //b.Appearance = ControlAppearance.Secondary;
        var pwdBox = new Wpf.Ui.Controls.PasswordBox
        {
            PlaceholderText = _localizationSet!["UserPassword"],
            PasswordChar = '●'
        };
        var ownerPwdBox = new Wpf.Ui.Controls.PasswordBox
        {
            PlaceholderText = _localizationSet!["OwnerPassword"],
            PasswordChar = '●',
            Margin = new Thickness(0, 5, 0, 0)
        };
        var textBlock = new Wpf.Ui.Controls.TextBlock
        {
            Text = _localizationSet!["ProtectPasswordCaption"],
            Margin = new Thickness(0, 5, 0, 0),
            FontTypography = FontTypography.Caption,
            TextWrapping = TextWrapping.Wrap
        };
        dlgContent.Children.Add(pwdBox);
        dlgContent.Children.Add(ownerPwdBox);
        dlgContent.Children.Add(textBlock);


        var contentDlg = new ContentDialog
        {
            Title = _localizationSet!["EnterProtectPassword"],
            Content = dlgContent,
            PrimaryButtonText = _localizationSet!["Continue"],
            CloseButtonText = _localizationSet!["Cancel"]

        };
        CancellationTokenSource cts = new CancellationTokenSource();

        ContentDialogResult result = await _contentDialogService.ShowAsync(contentDlg, cts.Token);
        if (result == ContentDialogResult.Primary)
        {
            userPass = Encoding.UTF8.GetBytes(pwdBox.Password);
            ownerPass = Encoding.UTF8.GetBytes(ownerPwdBox.Password);
            _pdfPassword = pwdBox.Password;
        }
        else if (result == ContentDialogResult.None)
        {
            return;
        }

        // single file
        if (!IsFolder)
        {
            try
            {

                var outputFileName = Path.GetFileName(SelectedPath);
                if (RenameOutputFile)
                {
                    outputFileName = PrefixFileName + Path.GetFileName(SelectedPath);
                }

                var outputFilePath = Path.Combine(OutputPath, outputFileName);
                using var reader = new PdfReader(SelectedPath);
                reader.SetUnethicalReading(true);
                var props = new WriterProperties()
                    .SetStandardEncryption(userPass, ownerPass, permissions, EncryptionConstants.ENCRYPTION_AES_256 | EncryptionConstants.DO_NOT_ENCRYPT_METADATA);
                using var writer = new PdfWriter(outputFilePath, props);
                using var doc = new PdfDocument(reader, writer);
                var dlg = new ContentDialog
                {
                    Title = _localizationSet!["Success"],
                    Content = _localizationSet!["PasswordWasSet"],
                    PrimaryButtonText = _localizationSet!["OpenOutput"],
                    CloseButtonText = _localizationSet!["Close"]
                };
                var res = await _contentDialogService.ShowAsync(dlg, cts.Token);
                if (res == ContentDialogResult.Primary)
                {
                    OpenWithShell(OutputPath);
                }
            }
            catch (System.IO.IOException ex)
            {
                var dlg = new ContentDialog
                {
                    Title = _localizationSet!["FileInUse"],
                    Content = ex.Message,
                    CloseButtonText = _localizationSet!["Close"]
                };
                _ = await _contentDialogService.ShowAsync(dlg, cts.Token);
            }
            catch (iText.Kernel.Exceptions.BadPasswordException)
            {
                var dlg = new ContentDialog
                {
                    Title = _localizationSet!["ProtectedFile"],
                    Content = string.Format(_localizationSet!["ProtectedFileContent"], SelectedPath),
                    CloseButtonText = _localizationSet!["Close"]
                };
                _ = await _contentDialogService.ShowAsync(dlg, cts.Token);
            }
        }

        if (IsFolder)
        {
            int susscess = 0;
            var listPDf = Directory.GetFiles(SelectedPath, "*.pdf");
            int total = listPDf.Length;
            foreach (var filePdf in listPDf)
            {
                try
                {
                    var outputFileName = Path.GetFileName(filePdf);
                    if (RenameOutputFile)
                    {
                        outputFileName = PrefixFileName + Path.GetFileName(filePdf);
                    }
                    var outputFilePath = Path.Combine(OutputPath, outputFileName);
                    using var reader = new PdfReader(filePdf);
                    reader.SetUnethicalReading(true);
                    var props = new WriterProperties()
                        .SetStandardEncryption(userPass, ownerPass, permissions, EncryptionConstants.ENCRYPTION_AES_256 | EncryptionConstants.DO_NOT_ENCRYPT_METADATA);
                    using var writer = new PdfWriter(outputFilePath, props);
                    using var doc = new PdfDocument(reader, writer);
                    susscess++;
                }
                catch (System.IO.IOException ex)
                {
                    var dlg1 = new ContentDialog
                    {
                        Title = _localizationSet!["FileInUse"],
                        Content = ex.Message,
                        CloseButtonText = _localizationSet!["Close"]
                    };
                    _ = await _contentDialogService.ShowAsync(dlg1, cts.Token);
                }
                catch (iText.Kernel.Exceptions.BadPasswordException)
                {
                    var dlg2 = new ContentDialog
                    {
                        Title = _localizationSet!["ProtectedFile"],
                        Content = string.Format(_localizationSet!["ProtectedFileContent"], filePdf),
                        CloseButtonText = _localizationSet!["Close"]
                    };
                    _ = await _contentDialogService.ShowAsync(dlg2, cts.Token);
                }
            }
            if (susscess > 0)
            {
                var dlg = new ContentDialog
                {
                    Title = _localizationSet!["Success"],
                    Content = string.Format(_localizationSet!["FilesProtectedSummary"], susscess, total),
                    PrimaryButtonText = _localizationSet!["OpenOutput"],
                    CloseButtonText = _localizationSet!["Close"]
                };
                var res = await _contentDialogService.ShowAsync(dlg, cts.Token);
                if (res == ContentDialogResult.Primary)
                {
                    OpenWithShell(OutputPath);
                }
            }
        }
    }


    [RelayCommand(CanExecute = nameof(CanStartProtectPdf))]
    private async Task UnProtectPdfAsync()
    {
        var txtbl = new Wpf.Ui.Controls.TextBlock
        {
            FontTypography = FontTypography.Caption,
            Text = _localizationSet!["FilePassword"],
            Margin = new Thickness(0, 0, 0, 5)
        };
        var dlgContent = new StackPanel
        {
            Width = 200
        };
        var pwdBox = new Wpf.Ui.Controls.PasswordBox
        {
            PlaceholderText = _localizationSet!["Password"],
            PasswordChar = '●',
            Password = _pdfPassword
        };
        dlgContent.Children.Add(txtbl);
        dlgContent.Children.Add(pwdBox);

        var contentDlg = new ContentDialog
        {
            Title = _localizationSet!["EnterFilePassword"],
            Content = dlgContent,
            PrimaryButtonText = _localizationSet!["Continue"],
            CloseButtonText = _localizationSet!["Close"]

        };
        CancellationTokenSource cts = new CancellationTokenSource();

        ContentDialogResult result = await _contentDialogService.ShowAsync(contentDlg, cts.Token);

        string pwd;

        if (result == ContentDialogResult.Primary)
        {
            pwd = pwdBox.Password;
            _pdfPassword = pwdBox.Password;
        }
        else
        {
            return;
        }

        var outputFileName = Path.GetFileName(SelectedPath);
        if (RenameOutputFile)
        {
            outputFileName = PrefixFileName + Path.GetFileName(SelectedPath);
        }
        var outputFilePath = Path.Combine(OutputPath, outputFileName);

        try
        {
            using var pdfReader = new PdfReader(SelectedPath,
                new ReaderProperties().SetPassword(Encoding.UTF8.GetBytes(pwd)));
            pdfReader.SetUnethicalReading(true);
            using var pdfWriter = new PdfWriter(outputFilePath);
            using var pdfDoc = new PdfDocument(pdfReader, pdfWriter);

            var dlg = new ContentDialog
            {
                Title = _localizationSet!["Success"],
                Content = string.Format(_localizationSet!["RemovedPasswordNotice"], SelectedPath),
                PrimaryButtonText = _localizationSet!["OpenOutput"],
                CloseButtonText = _localizationSet!["Close"]
            };
            var res = await _contentDialogService.ShowAsync(dlg, cts.Token);
            if (res == ContentDialogResult.Primary)
            {
                OpenWithShell(OutputPath);
            }
        }
        catch (EntryPointNotFoundException e)
        {
            Debug.Print("{0}:\n   {1}", e.GetType().Name,
                              e.Message);
        }
        catch (iText.Kernel.Exceptions.BadPasswordException)
        {
            var dlg2 = new ContentDialog
            {
                Title = _localizationSet!["WrongPassword"],
                Content = string.Format(_localizationSet!["WrongPasswordContent"], SelectedPath),
                CloseButtonText = _localizationSet!["Close"]
            };
            _ = await _contentDialogService.ShowAsync(dlg2, cts.Token);
            //File.Delete(outputFilePath);
        }
        catch (System.IO.IOException ex)
        {
            var dlg = new ContentDialog
            {
                Title = _localizationSet!["FileInUse"],
                Content = ex.Message,
                CloseButtonText = _localizationSet!["Close"]
            };
            _ = await _contentDialogService.ShowAsync(dlg, cts.Token);
        }

    }

    private bool CanStartProtectPdf()
    {
        if (RenameOutputFile && string.IsNullOrEmpty(PrefixFileName))
        {
            return false;
        }
        else if (!RenameOutputFile) 
        {
            if (!string.IsNullOrEmpty(OutputPath) && !string.IsNullOrEmpty(SelectedPath))
            {
                if ((IsFolder && OutputPath == SelectedPath)
                     || (!IsFolder && OutputPath == Path.GetDirectoryName(SelectedPath)))
                {
                    RenameOutputFile = true;
                }
            }
        }
        return !string.IsNullOrEmpty(SelectedPath) && !string.IsNullOrEmpty(OutputPath);
    }


    private static void OpenWithShell(string target)
    {
        if (string.IsNullOrWhiteSpace(target))
        {
            return;
        }

        var startInfo = new ProcessStartInfo
        {
            FileName = target,
            UseShellExecute = true
        };

        Process.Start(startInfo);
    }


    #endregion
}
