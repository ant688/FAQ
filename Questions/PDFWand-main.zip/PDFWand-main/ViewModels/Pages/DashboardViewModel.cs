﻿using PDFWand.Helpers;
using Wpf.Ui;

namespace PDFWand.ViewModels.Pages;

public partial class DashboardViewModel(INavigationService navigationService) : ObservableObject
{

    [RelayCommand]     
    private void OnCardClick(string parameter)
    {
        if (string.IsNullOrWhiteSpace(parameter))
        {
            return;
        }

        Type? pageType = NameToPageTypeConverter.Convert(parameter);

        if (pageType == null)
        {
            return;
        }

        _ = navigationService.Navigate(pageType);
    }
}
