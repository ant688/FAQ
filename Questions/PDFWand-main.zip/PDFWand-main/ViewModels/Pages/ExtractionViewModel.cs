﻿using CommunityToolkit.Mvvm.Messaging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using iText.Kernel.Pdf;
using Lepo.i18n;
using PDFWand.Helpers;
using PDFWand.Messenger;
using PDFWand.Models;
using PDFWand.Services;
using Wpf.Ui;
using Wpf.Ui.Abstractions.Controls;
using Wpf.Ui.Controls;

namespace PDFWand.ViewModels.Pages;

public partial class ExtractionViewModel : ObservableObject, INavigationAware
{
    private readonly ILocalSettingsService _localSettingsService;
    private readonly IContentDialogService _contentDialogService;
    private readonly ILocalizationProvider _localizationProvider;
    private readonly IMessenger _messenger;
    private LocalizationSet? _localizationSet;

    public ExtractionViewModel(ILocalSettingsService localSettingsService,
        IContentDialogService contentDialogService,
        ILocalizationProvider localizationProvider,
        IMessenger messenger)
    {
        _localSettingsService = localSettingsService;
        _contentDialogService = contentDialogService;
        _localizationProvider = localizationProvider;
        _messenger = messenger;

        _messenger.Register<LanguageChangedMessage>(this, (_, message) =>
        {
            _localizationSet = _localizationProvider.GetLocalizationSet(message.Culture.Name);
        });
    }

    public Task OnNavigatedFromAsync()
    {
        PreviewPages.Clear();
        _pdfDocument?.Dispose();
        _pdfDocument = null;
        _pageRotations = null;
        CurrentViewPage = null;
        CurrentPageRotation = 0;
        ZoomLevel = 1.0;
        SelectPath = null;
        OpenedFilePathVisibility = Visibility.Collapsed;
        IsPreviewAvailable = false;
        UpdateRotationCommandStates();
        UpdateZoomCommandStates();
        return Task.CompletedTask;
    }

    public async Task OnNavigatedToAsync()
    {
        _localizationSet = _localizationProvider.GetLocalizationSet(_localizationProvider.GetCulture().Name);
        var isPreviewAllPage = await _localSettingsService.ReadSettingAsync<bool>("PreviewAllPage");
        if (isPreviewAllPage)
        {
            PreviewAllPage = true;
            PreviewOnePage = false;
        }
        else
        {
            PreviewAllPage = false;
            PreviewOnePage = true;
        }
    }

    #region Preview Handling

    [ObservableProperty]
    private ImageSource? _currentViewPage;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SaveRotatedPdfCommand))]
    [NotifyCanExecuteChangedFor(nameof(RotateLeftCommand))]
    [NotifyCanExecuteChangedFor(nameof(RotateRightCommand))]
    private string? _selectPath;

    [ObservableProperty]
    private Visibility _openedFilePathVisibility = Visibility.Collapsed;

    private PdfiumViewer.PdfDocument? _pdfDocument;

    private int[]? _pageRotations;

    private const double MinZoomLevel = 0.5;
    private const double MaxZoomLevel = 3.0;
    private const double ZoomStep = 0.1;

    [ObservableProperty]
    private ObservableCollection<PdfPreviewPage> _previewPages = [];

    [ObservableProperty]
    private bool _isPreviewAvailable;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(NextPageCommand))]
    private int _totalPage;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(PrevPageCommand))]
    [NotifyCanExecuteChangedFor(nameof(NextPageCommand))]
    private int _currentPageIndex = 0;

    [ObservableProperty]
    private int _currentPageRotation;

    [ObservableProperty]
    private bool _previewAllPage = true;

    [ObservableProperty]
    private bool _previewOnePage = false;

    [ObservableProperty]
    private string? _masterPassword;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ZoomInCommand))]
    [NotifyCanExecuteChangedFor(nameof(ZoomOutCommand))]
    private double _zoomLevel = 1.0;

    partial void OnCurrentPageIndexChanged(int value)
    {
        if (_pdfDocument != null && value > -1)
        {
            _ = PreViewPageAsync(_pdfDocument, value);
            CurrentPageRotation = _pageRotations?[value] ?? 0;
        }
    }


    [RelayCommand]
    private async Task OpenFile()
    {
        Microsoft.Win32.OpenFileDialog o = new()
        {
            Filter = "PDF file|*.pdf",
            Title = _localizationSet!["OpenFile"],
            InitialDirectory = Environment.SpecialFolder.MyDocuments.ToString()
        };
        if (o.ShowDialog() == true)
        {
            SelectPath = o.FileName;
            OpenedFilePathVisibility = Visibility.Visible;
            PreviewPages.Clear();
            CurrentViewPage = null;
            IsPreviewAvailable = false;
            ZoomLevel = 1.0;
            UpdateZoomCommandStates();
        OpenPDF:
            try
            {
                _pdfDocument?.Dispose();
                _pdfDocument = PdfiumViewer.PdfDocument.Load(SelectPath, MasterPassword);
                TotalPage = _pdfDocument.PageCount;
                _pageRotations = new int[TotalPage];
                IsPreviewAvailable = true;
                UpdateZoomCommandStates();
            }
            catch (PdfiumViewer.PdfException ex)
            {
                if (ex.Message == "Password required or incorrect password")
                {
                    var dlgContent = new PasswordBox
                    {
                        PlaceholderText = _localizationSet["Password"]
                    };
                    var dlg = new ContentDialog
                    {
                        Title = _localizationSet!["PasswordToOpen"],
                        Content = dlgContent,
                        PrimaryButtonText = _localizationSet!["Open"],
                        CloseButtonText = _localizationSet!["Cancel"]
                    };
                    var rs = await _contentDialogService.ShowAsync(dlg, CancellationToken.None);
                    if (rs == ContentDialogResult.Primary)
                    {
                        MasterPassword = dlgContent.Password;
                        goto OpenPDF;
                    }
                    else
                    {
                        SelectPath = null;
                        _pageRotations = null;
                        _pdfDocument = null;
                        IsPreviewAvailable = false;
                        UpdateRotationCommandStates();
                        UpdateZoomCommandStates();
                        return;
                    }
                }
                else
                {
                    SelectPath = null;
                    _pageRotations = null;
                    _pdfDocument = null;
                    IsPreviewAvailable = false;
                    UpdateRotationCommandStates();
                    UpdateZoomCommandStates();
                    return;
                }
            }
            catch (Exception ex)
            {
                var dlg = new ContentDialog
                {
                    Title = "Open error",
                    Content = ex.Message,
                };
                await _contentDialogService.ShowAsync(dlg, CancellationToken.None);
                SelectPath = null;
                _pageRotations = null;
                _pdfDocument = null;
                IsPreviewAvailable = false;
                UpdateRotationCommandStates();
                UpdateZoomCommandStates();
                return;
            }




            CurrentPageIndex = 0;
            UpdateRotationCommandStates();
            UpdateZoomCommandStates();

            if (PreviewOnePage)
            {
                await PreViewPageAsync(_pdfDocument, CurrentPageIndex);
            }


            if (PreviewAllPage && _pdfDocument is not null)
            {
                var document = _pdfDocument;
                var previewPages = await Task.Run(() =>
                {
                    var pages = new List<PdfPreviewPage>(TotalPage);
                    for (int i = 0; i < TotalPage; i++)
                    {
                        var sizeInPoints = document.PageSizes[i];
                        int widthInPixels = (int)Math.Round(sizeInPoints.Width * 96f / 72f);
                        int heightInPixels = (int)Math.Round(sizeInPoints.Height * 96f / 72f);
                        pages.Add(new PdfPreviewPage
                        {
                            PageNo = i + 1,
                            TotalPage = TotalPage,
                            ViewPage = RenderPageToMemDC(document, i, widthInPixels, heightInPixels),
                            RotationAngle = _pageRotations?[i] ?? 0
                        });
                    }

                    return pages;
                });

                PreviewPages = new ObservableCollection<PdfPreviewPage>(previewPages);
                if (_pageRotations is not null && CurrentPageIndex >= 0 && CurrentPageIndex < _pageRotations.Length)
                {
                    UpdatePreviewRotation(CurrentPageIndex, _pageRotations[CurrentPageIndex]);
                }
            }
        }
    }


    private async Task PreViewPageAsync(PdfiumViewer.PdfDocument pdfDoc, int page, float dpiX = 96, float dpiY = 96)
    {

        var sizeInPoints = pdfDoc!.PageSizes[page];
        int widthInPixels = (int)Math.Round(sizeInPoints.Width * dpiX / 72F);
        int heightInPixels = (int)Math.Round(sizeInPoints.Height * dpiY / 72F);

        var bitmap = await Task.Run(() =>
        {
            return RenderPageToMemDC(pdfDoc, page, widthInPixels, heightInPixels, dpiX, dpiY);
        });

        if (_pdfDocument == pdfDoc && CurrentPageIndex == page)
        {
            CurrentViewPage = bitmap;
        }
    }

    [RelayCommand(CanExecute = nameof(CanRotate))]
    private void RotateLeft()
    {
        ApplyRotation(-90);
    }

    [RelayCommand(CanExecute = nameof(CanRotate))]
    private void RotateRight()
    {
        ApplyRotation(90);
    }

    private void ApplyRotation(int delta)
    {
        if (_pageRotations == null || _pdfDocument == null || CurrentPageIndex < 0 || CurrentPageIndex >= _pageRotations.Length)
        {
            return;
        }

        var index = CurrentPageIndex;
        var newRotation = (_pageRotations[index] + delta) % 360;
        if (newRotation < 0)
        {
            newRotation += 360;
        }

        _pageRotations[index] = newRotation;
        CurrentPageRotation = newRotation;
        UpdatePreviewRotation(index, newRotation);
    }

    private void UpdatePreviewRotation(int index, int rotation)
    {
        if (PreviewPages is { Count: > 0 } && index < PreviewPages.Count)
        {
            PreviewPages[index].RotationAngle = rotation;
        }
    }

    private bool CanRotate()
    {
        return _pdfDocument != null;
    }

    private void UpdateRotationCommandStates()
    {
        RotateLeftCommand.NotifyCanExecuteChanged();
        RotateRightCommand.NotifyCanExecuteChanged();
        SaveRotatedPdfCommand.NotifyCanExecuteChanged();
    }

    [RelayCommand(CanExecute = nameof(CanZoomIn))]
    private void ZoomIn()
    {
        if (ZoomLevel >= MaxZoomLevel)
        {
            return;
        }

        var newZoom = Math.Min(MaxZoomLevel, ZoomLevel + ZoomStep);
        ZoomLevel = Math.Round(newZoom, 2);
    }

    [RelayCommand(CanExecute = nameof(CanZoomOut))]
    private void ZoomOut()
    {
        if (ZoomLevel <= MinZoomLevel)
        {
            return;
        }

        var newZoom = Math.Max(MinZoomLevel, ZoomLevel - ZoomStep);
        ZoomLevel = Math.Round(newZoom, 2);
    }

    private bool CanZoomIn()
    {
        return _pdfDocument != null && ZoomLevel < MaxZoomLevel;
    }

    private bool CanZoomOut()
    {
        return _pdfDocument != null && ZoomLevel > MinZoomLevel;
    }

    private void UpdateZoomCommandStates()
    {
        ZoomInCommand.NotifyCanExecuteChanged();
        ZoomOutCommand.NotifyCanExecuteChanged();
    }

    [RelayCommand(CanExecute = nameof(CanNext))]
    private void NextPage()
    {

        CurrentPageIndex++;
    }

    [RelayCommand(CanExecute = nameof(CanPrev))]
    private void PrevPage()
    {

        CurrentPageIndex--;

    }

    private bool CanNext()
    {
        return CurrentPageIndex < TotalPage - 1;
    }

    private bool CanPrev()
    {
        return CurrentPageIndex > 0;
    }

    private static BitmapSource RenderPageToMemDC(PdfiumViewer.PdfDocument document, int page, int width, int height, float dpiX = 96, float dpiY = 96)
    {
        using var image = document.Render(page, width, height, dpiX, dpiY, true);
        return BitmapHelper.ToBitmapSource(image);
    }

    [RelayCommand(CanExecute = nameof(CanSaveRotatedPdf))]
    private async Task SaveRotatedPdf()
    {
        if (string.IsNullOrEmpty(SelectPath))
        {
            return;
        }

        var saveDialog = new Microsoft.Win32.SaveFileDialog
        {
            Filter = "Pdf file|*.pdf",
            FileName = $"{Path.GetFileNameWithoutExtension(SelectPath)}_rotated"
        };

        if (saveDialog.ShowDialog() != true)
        {
            return;
        }

        try
        {
            using var pdfReader = string.IsNullOrEmpty(MasterPassword)
                ? new PdfReader(SelectPath)
                : new PdfReader(SelectPath,
                    new ReaderProperties().SetPassword(Encoding.UTF8.GetBytes(MasterPassword)));
            pdfReader.SetUnethicalReading(true);
            using var pdfWriter = new PdfWriter(saveDialog.FileName);
            using var pdfDoc = new PdfDocument(pdfReader, pdfWriter);
            var pageCount = pdfDoc.GetNumberOfPages();
            for (int i = 1; i <= pageCount; i++)
            {
                var page = pdfDoc.GetPage(i);
                var existingRotation = page.GetRotation();
                var additionalRotation = _pageRotations?[i - 1] ?? 0;
                var finalRotation = (existingRotation + additionalRotation) % 360;
                page.SetRotation(finalRotation);
            }

            var dlgFinish = new ContentDialog
            {
                Title = _localizationSet!["MsgRotationSavedTitle"],
                Content = string.Format(_localizationSet!["MsgRotationSavedContent"]!, Environment.NewLine, saveDialog.FileName),
                CloseButtonText = "OK"
            };
            await _contentDialogService.ShowAsync(dlgFinish, CancellationToken.None);
        }
        catch (Exception ex)
        {
            var dlg = new ContentDialog
            {
                Title = _localizationSet!["SaveError"],
                Content = ex.Message,
                CloseButtonText = "OK"
            };
            await _contentDialogService.ShowAsync(dlg, CancellationToken.None);
        }
    }

    private bool CanSaveRotatedPdf()
    {
        return _pdfDocument != null && !string.IsNullOrEmpty(SelectPath);
    }

    #endregion

    #region Extraction

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ExtractPageCommand))]
    private string? _extractPages;

    /// <summary>
    /// Parses a string of page numbers, which can contain individual numbers or ranges.
    /// Example valid inputs: "1-10", "1,2,3,4", "1,3-5,8".
    /// </summary>
    /// <param name="input">The input string to parse.</param>
    /// <returns>A List<int> of page numbers on success, otherwise null.</returns>
    private static List<int> ParsePageNumbers(string input)
    {
        // Handle null or empty input
        if (string.IsNullOrWhiteSpace(input))
        {
            return null;
        }

        var resultList = new List<int>();

        // Split the string by commas to get individual numbers or ranges
        var parts = input.Split(',');

        foreach (var part in parts)
        {
            // Remove any leading/trailing whitespace
            var trimmedPart = part.Trim();

            // Check for a hyphen, indicating a range
            if (trimmedPart.Contains('-'))
            {
                var rangeParts = trimmedPart.Split('-');
                if (rangeParts.Length != 2)
                {
                    // Invalid range format (e.g., "1-2-3")
                    return null;
                }

                if (!int.TryParse(rangeParts[0].Trim(), out int start) ||
                    !int.TryParse(rangeParts[1].Trim(), out int end))
                {
                    // Invalid number in the range
                    return null;
                }

                // A valid range must have the start number less than or equal to the end number.
                if (start > end)
                {
                    return null;
                }

                // Add all numbers within the range
                for (int i = start; i <= end; i++)
                {
                    resultList.Add(i);
                }
            }
            else
            {
                // No hyphen, so it's a single number
                if (!int.TryParse(trimmedPart, out int singleNumber))
                {
                    // Invalid number format (e.g., "1,a,3")
                    return null;
                }
                resultList.Add(singleNumber);
            }
        }

        // Return a new list to prevent external modification of the original.
        return resultList;
    }

    /// <summary>
    /// Checks if any page number in a list is greater than the total number of pages.
    /// </summary>
    /// <param name="pages">The List<int> of page numbers to validate.</param>
    /// <param name="totalPageCount">The total number of pages available.</param>
    /// <returns>True if all pages are valid, otherwise false.</returns>
    public static bool ValidatePageNumbers(List<int> pages, int totalPageCount)
    {
        // First, check if the list of pages is not null.
        if (pages == null)
        {
            return false;
        }

        // Use LINQ's Any() method to check if any page number is greater than the total page count.
        // The condition `p > totalPageCount` handles the "greater than" requirement.
        // It also implicitly checks for `p <= 0` since page numbers should be positive.
        if (pages.Any(p => p > totalPageCount || p <= 0))
        {
            // If any page number is out of bounds, return false.
            return false;
        }

        // If the loop completes without finding any invalid page numbers, return true.
        return true;
    }


    [RelayCommand(CanExecute = nameof(CanExtractPage))]
    private async Task ExtractPage()
    {
        var pages = ParsePageNumbers(ExtractPages!);
        var isValid = ValidatePageNumbers(pages, TotalPage);
        if (!isValid)
        {
            var dlg = new ContentDialog
            {
                Title = _localizationSet!["MsgInvalidPageNumberTitle"],
                Content = _localizationSet!["MsgInvalidPageNumberContent"]
            };
            await _contentDialogService.ShowAsync(dlg, CancellationToken.None);
            return;
        }
        string saveFileName = $"{System.IO.Path.GetFileNameWithoutExtension(SelectPath)}_pages_{ExtractPages}";
        var s = new Microsoft.Win32.SaveFileDialog
        {
            Filter = "Pdf file|*.pdf",
            FileName = saveFileName
        };
        if (s.ShowDialog() == false)
        {
            return;
        }

        using var pdfReader = string.IsNullOrEmpty(MasterPassword)
            ? new PdfReader(SelectPath)
            : new PdfReader(SelectPath,
                new ReaderProperties().SetPassword(Encoding.UTF8.GetBytes(MasterPassword)));
        pdfReader.SetUnethicalReading(true);
        using var pdfDoc = new PdfDocument(pdfReader);
        using var pdfWriter = new PdfWriter(s.FileName);
        using var pdfDocOutput = new PdfDocument(pdfWriter);
        foreach (var p in pages)
        {
            _ = pdfDoc.GetPage(p);
            pdfDoc.CopyPagesTo(p, p, pdfDocOutput);
        }

        var dlgFinish = new ContentDialog
        {
            Title = _localizationSet!["MsgExtractedTitle"],
            Content = string.Format(_localizationSet!["MsgExtractedContent"]!, ExtractPages, Environment.NewLine, s.FileName),
            CloseButtonText = "OK"
        };
        _= await _contentDialogService.ShowAsync(dlgFinish, CancellationToken.None);
    }

    private bool CanExtractPage()
    {
        return !string.IsNullOrEmpty(ExtractPages);
    }

    #endregion
}
