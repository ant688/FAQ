using CommunityToolkit.Mvvm.Messaging;
using Lepo.i18n;
using PDFWand.Helpers;
using PDFWand.Messenger;
using PDFWand.Services;
using System.Collections.ObjectModel;
using Wpf.Ui.Controls;

namespace PDFWand.ViewModels.Windows
{
    public partial class MainWindowViewModel : ObservableObject
    {
        private LocalizationSet? _localizationSet;
        private readonly ILocalSettingsService _localSettingsService;
        private readonly ILocalizationProvider _localizationProvider;
        private readonly IMessenger _messenger;

        [ObservableProperty]
        private string _applicationTitle = "HARRY TRINH - PDF Wand";

        [ObservableProperty]
        private ObservableCollection<object> _menuItems = [];

        [ObservableProperty]
        private ObservableCollection<object> _footerMenuItems = [];

        [ObservableProperty]
        private ObservableCollection<MenuItem> _trayMenuItems = new()
        {
            new MenuItem { Header = "Home", Tag = "tray_home" }
        };

        [ObservableProperty]
        private bool _isPaneOpen;

        public MainWindowViewModel(ILocalizationProvider localizationProvider, ILocalSettingsService localSettingsService, IMessenger messenger)
        {
            _localizationProvider = localizationProvider;
            _localSettingsService = localSettingsService;
            _messenger = messenger;

            _localizationSet = _localizationProvider.GetLocalizationSet(_localizationProvider.GetCulture().Name);

            BuildNavigationItems();

            _messenger.Register<LanguageChangedMessage>(this, (_, message) =>
            {
                _localizationSet = _localizationProvider.GetLocalizationSet(message.Culture.Name);
                BuildNavigationItems();
            });

            Task.Run(async () =>
            {
                _isPaneOpen = await localSettingsService.ReadSettingAsync<bool>("IsPaneOpen");
            });
        }

        private void BuildNavigationItems()
        {
            if (_localizationSet is null)
            {
                return;
            }

            FooterMenuItems = new ObservableCollection<object>
            {
                new NavigationViewItem()
                {
                    Content = _localizationSet["Settings"],
                    Icon = StencilIconHelper.GetIcon("settings-32"),
                    TargetPageType = typeof(Views.Pages.SettingsPage)
                }
            };

            MenuItems = new ObservableCollection<object>
            {
                new NavigationViewItem()
                {
                    Content = _localizationSet["Home"],
                    Icon = StencilIconHelper.GetIcon("home-32", 20, 20),
                    TargetPageType = typeof(Views.Pages.DashboardPage)
                },
                new NavigationViewItem()
                {
                    Content = _localizationSet["Extract"],
                    Icon = StencilIconHelper.GetIcon("export-pdf-32",20,20),
                    TargetPageType = typeof(Views.Pages.ExtractionPage)
                },
                new NavigationViewItem()
                {
                    Content = _localizationSet["Paging"],
                    Icon = StencilIconHelper.GetIcon("numbers-32",20,20),
                    TargetPageType = typeof(Views.Pages.PagingPage)
                },
                new NavigationViewItem()
                {
                     Content = _localizationSet["Merge"],
                    Icon = StencilIconHelper.GetIcon("merge-files-32",20,20),
                    TargetPageType = typeof(Views.Pages.MergePage)
                },
                new NavigationViewItem()
                {
                    Content = _localizationSet["Watermark"],
                    Icon = StencilIconHelper.GetIcon("stamp-32",20,20),
                    TargetPageType = typeof(Views.Pages.WatermarkPage)
                },
                new NavigationViewItem()
                {
                     Content = _localizationSet["Security"],
                    Icon = StencilIconHelper.GetIcon("security-lock-100",20,20),
                    TargetPageType = typeof(Views.Pages.ProtectPage)
                }
            };
        }
    }
}
