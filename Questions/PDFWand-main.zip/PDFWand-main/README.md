# PDFWand

[English](#english) | [Tiếng Việt](#tiếng-việt)

## English

PDFWand is a powerful desktop application designed to make working with PDF documents faster and more reliable. Created by **harrytrinh9**, the project focuses on practical tools that help you prepare, edit, and share PDFs with ease.

### Key Features

- **Merge PDFs**: Combine multiple PDF files into one coherent document without quality loss.
- **Split Documents**: Extract selected pages or split large PDFs into smaller, manageable files.
- **Page Reordering**: Rearrange pages quickly through an intuitive interface.
- **Compression Tools**: Reduce file sizes while keeping readable quality for easy sharing.
- **Security Enhancements**: Protect sensitive PDFs with password encryption and permissions.
- **Format Conversion**: Turn PDFs into images and other supported formats for flexible use.

### Getting Started

1. Clone the repository and open `PDFWand.sln` in Visual Studio.
2. Restore NuGet packages and build the solution.
3. Run the application to begin managing your PDF files.

### Contributing

Contributions are welcome! Please open an issue to discuss significant changes before submitting a pull request.

---

## Tiếng Việt

PDFWand là ứng dụng desktop mạnh mẽ giúp bạn xử lý tài liệu PDF nhanh chóng và ổn định. Dự án được phát triển bởi **harrytrinh9**, tập trung vào các công cụ thực tiễn để bạn chuẩn bị, chỉnh sửa và chia sẻ PDF dễ dàng.

### Tính Năng Nổi Bật

- **Gộp PDF**: Kết hợp nhiều tệp PDF thành một tài liệu hoàn chỉnh mà không giảm chất lượng.
- **Tách Tài Liệu**: Trích xuất các trang mong muốn hoặc chia nhỏ PDF lớn thành các tệp dễ quản lý.
- **Sắp Xếp Lại Trang**: Sắp xếp lại các trang nhanh chóng thông qua giao diện trực quan.
- **Nén Tệp**: Giảm dung lượng PDF nhưng vẫn giữ chất lượng đọc tốt để chia sẻ thuận tiện.
- **Bảo Mật**: Bảo vệ tài liệu quan trọng bằng mật khẩu và thiết lập quyền truy cập.
- **Chuyển Đổi Định Dạng**: Chuyển PDF sang hình ảnh và các định dạng được hỗ trợ khác để sử dụng linh hoạt.

### Bắt Đầu

1. Clone repository và mở `PDFWand.sln` trong Visual Studio.
2. Khôi phục các gói NuGet và build solution.
3. Chạy ứng dụng để bắt đầu quản lý tệp PDF của bạn.

### Đóng Góp

Rất hoan nghênh các đóng góp! Vui lòng mở issue để trao đổi về các thay đổi lớn trước khi gửi pull request.
