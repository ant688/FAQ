using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace PDFWand.Helpers;

public class NullToVisibilityConverter : IValueConverter
{
    public bool Invert { get; set; }

    public bool CollapseWhenNull { get; set; } = true;

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        bool invert = Invert;

        if (parameter is string rawParameter)
        {
            if (bool.TryParse(rawParameter, out bool parsed))
            {
                invert = parsed;
            }
            else if (string.Equals(rawParameter, "Invert", StringComparison.OrdinalIgnoreCase))
            {
                invert = !invert;
            }
        }

        bool isNull = value is null;

        if (invert)
        {
            isNull = !isNull;
        }

        if (isNull)
        {
            return CollapseWhenNull ? Visibility.Collapsed : Visibility.Hidden;
        }

        return Visibility.Visible;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return System.Windows.Data.Binding.DoNothing;
    }
}
