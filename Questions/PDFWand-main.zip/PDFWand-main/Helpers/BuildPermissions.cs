﻿using iText.Kernel.Pdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDFWand.CoreHelper;

public class BuildPermissions
{

    /// <summary>
    /// Cho phép in
    /// </summary>
    public bool AllowPrint { get; set; }

    /// <summary>
    /// Cho phép copy nội dung
    /// </summary>
    public bool AllowCopy { get; set; }

    /// <summary>
    /// Cho phép điền vào form
    /// </summary>
    public bool AllowFillIn { get; set; }

    /// <summary>
    /// Cho phép thêm/chỉnh sửa chú thích 
    /// </summary>
    public bool AllowModifyAnnotations { get; set; }

    /// <summary>
    /// Cho phép sửa nội dung PDF 
    /// </summary>
    public bool AllowModifyContents { get; set; }

    /// <summary>
    /// Hỗ trợ trình đọc màn hình 
    /// </summary>
    public bool AllowScreenReaders { get; set; }

    /// <summary>
    /// Cho phép ghép/tách trang 
    /// </summary>
    public bool AllowAssembly { get; set; }

    //public bool AllowDegradedPrint { get; set; }

    public int Build()
    {
        int permissions = 0;
        if (AllowPrint) permissions |= EncryptionConstants.ALLOW_PRINTING;
        if (AllowCopy) permissions |= EncryptionConstants.ALLOW_COPY;
        if (AllowModifyContents) permissions |= EncryptionConstants.ALLOW_MODIFY_CONTENTS;
        if (AllowModifyAnnotations) permissions |= EncryptionConstants.ALLOW_MODIFY_ANNOTATIONS;
        if (AllowScreenReaders) permissions |= EncryptionConstants.ALLOW_SCREENREADERS;
        if (AllowFillIn) permissions |= EncryptionConstants.ALLOW_FILL_IN;
        if (AllowAssembly) permissions |= EncryptionConstants.ALLOW_ASSEMBLY;
        return permissions;
    }
}
