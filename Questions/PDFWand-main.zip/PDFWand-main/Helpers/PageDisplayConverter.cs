﻿using System.Globalization;
using System.Windows.Data;

namespace PDFWand.Helpers;

public class PageDisplayConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is int val)
        {
            return ++val;
        }
        return value;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is int val)
        {
            return --val;
        }
        return value;
    }
}
