﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Wpf.Ui.Controls;

namespace PDFWand.Helpers;

public class StencilIconHelper
{
    public static ImageIcon GetIcon(string iconName, double height = 25, double width = 25)
    {
        var bitmapImage = new BitmapImage(new Uri($"pack://application:,,,/Assets/Stencil/{iconName}.png"));
        return new ImageIcon {Source = bitmapImage, Height = height, Width = width, Margin = new Thickness(3)};
    }
}
