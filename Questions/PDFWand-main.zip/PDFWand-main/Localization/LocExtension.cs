using System.Windows.Data;
using System.Windows.Markup;

using DataBinding = System.Windows.Data.Binding;

namespace PDFWand.Localization;

[MarkupExtensionReturnType(typeof(string))]
public class LocExtension : DataBinding
{
    private string? _key;

    public LocExtension()
    {
        InitializeBinding();
    }

    public LocExtension(string key)
        : this()
    {
        Key = key;
    }

    [ConstructorArgument("key")]
    public string? Key
    {
        get => _key;
        set
        {
            _key = value;
            UpdatePath();
        }
    }

    private void InitializeBinding()
    {
        Mode = BindingMode.OneWay;
        Source = LocalizationManager.Instance;
    }

    private void UpdatePath()
    {
        if (!string.IsNullOrWhiteSpace(_key))
        {
            Path = new PropertyPath($"[{_key}]");
        }
    }
}
