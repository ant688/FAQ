using CommunityToolkit.Mvvm.Messaging;
using Lepo.i18n;
using PDFWand.Messenger;

namespace PDFWand.Localization;

public sealed class LocalizationManager : ObservableObject
{
    private const string IndexerPropertyName = "Item[]";

    private static readonly Lazy<LocalizationManager> _instance = new(() => new LocalizationManager());

    private LocalizationSet? _localizationSet;
    private ILocalizationProvider? _localizationProvider;
    private bool _isInitialized;

    private LocalizationManager()
    {
    }

    public static LocalizationManager Instance => _instance.Value;

    public string this[string key]
    {
        get
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                return string.Empty;
            }

            var value = _localizationSet?[key];
            return string.IsNullOrEmpty(value) ? key : value!;
        }
    }

    public void Initialize(ILocalizationProvider localizationProvider, IMessenger messenger)
    {
        if (_isInitialized)
        {
            return;
        }

        _localizationProvider = localizationProvider;
        _localizationSet = _localizationProvider.GetLocalizationSet(_localizationProvider.GetCulture().Name)
            ?? _localizationProvider.GetLocalizationSet("en-US");
        _isInitialized = true;
        OnPropertyChanged(IndexerPropertyName);

        messenger.Register<LanguageChangedMessage>(this, (_, message) =>
        {
            if (_localizationProvider is null)
            {
                return;
            }

            _localizationSet = _localizationProvider.GetLocalizationSet(message.Culture.Name)
                ?? _localizationProvider.GetLocalizationSet("en-US");
            OnPropertyChanged(IndexerPropertyName);
        });
    }

    public void Refresh()
    {
        if (_localizationProvider is null)
        {
            return;
        }

        _localizationSet = _localizationProvider.GetLocalizationSet(_localizationProvider.GetCulture().Name)
            ?? _localizationProvider.GetLocalizationSet("en-US");
        OnPropertyChanged(IndexerPropertyName);
    }
}
