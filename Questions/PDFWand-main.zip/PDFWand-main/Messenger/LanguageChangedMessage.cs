using System.Globalization;

namespace PDFWand.Messenger;

public class LanguageChangedMessage
{
    public LanguageChangedMessage(CultureInfo culture)
    {
        Culture = culture;
    }

    public CultureInfo Culture { get; }
}
