﻿using PDFWand.Models;
using CommunityToolkit.Mvvm.Messaging.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDFWand.Messenger;

public class WindowSizeMessage : ValueChangedMessage<WindowSize>
{
    public WindowSizeMessage(WindowSize value) : base(value)
    {
    }
}
