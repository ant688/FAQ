﻿using PDFWand.Models;
using CommunityToolkit.Mvvm.Messaging.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDFWand.Messenger;

public class ThemeChangeMessage
{
    public LocalTheme Theme { get; }
    public ThemeChangeMessage(LocalTheme theme)
    {
        Theme = theme;
    }
}
