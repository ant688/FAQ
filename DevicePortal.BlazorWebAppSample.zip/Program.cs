using DevicePortal.WebApp.Data;
using DevicePortal.WebApp.Models;
using DevicePortal.WebApp.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Localization;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddLocalization();

builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("Default")));
builder.Services.AddIdentity<AppUser, IdentityRole>(o => {
    o.Password.RequireNonAlphanumeric = false;
    o.Password.RequireUppercase = false;
}).AddEntityFrameworkStores<AppDbContext>()
  .AddDefaultTokenProviders()
  .AddDefaultUI();

builder.Services.AddAuthorization();
builder.Services.AddRazorPages();

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.Configure<RequestLocalizationOptions>(opt => {
    var cultures = new[] { "vi-VN", "en-US" };
    opt.SetDefaultCulture("vi-VN")
       .AddSupportedCultures(cultures)
       .AddSupportedUICultures(cultures);
    opt.ApplyCurrentCultureToResponseHeaders = true;
});

var app = builder.Build();

var loc = app.Services.GetRequiredService<Microsoft.Extensions.Options.IOptions<RequestLocalizationOptions>>();
app.UseRequestLocalization(loc.Value);

if (!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Error"); app.UseHsts(); }

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/set-culture", (string culture, string returnUrl, HttpContext ctx) => {
    var cookie = CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture));
    ctx.Response.Cookies.Append(CookieRequestCultureProvider.DefaultCookieName, cookie,
        new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1) });
    return Results.LocalRedirect(returnUrl);
});

app.MapRazorPages();

app.MapRazorComponents<DevicePortal.WebApp.Components.App>()
    .AddInteractiveServerRenderMode();

await IdentitySeeder.SeedAsync(app);
app.Run();
