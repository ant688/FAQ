# DevicePortal.BlazorWebAppSample (.NET 8)
- Blazor Web App (SSR + Interactive Server)
- Identity + Roles + SQL Server (EF Core)
- Devices CRUD + Localization EN/VI
- Deployable to IIS (enable WebSockets)

## Setup
1) Edit `appsettings.json` connection string.
2) Migrations:
```
dotnet tool install --global dotnet-ef
dotnet ef migrations add Init
dotnet ef database update
```
3) Run:
```
dotnet run
```
Login: `admin@example.com / ChangeMe_123!`
