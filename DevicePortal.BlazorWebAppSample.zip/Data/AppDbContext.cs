using DevicePortal.WebApp.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DevicePortal.WebApp.Data;
public class AppDbContext : IdentityDbContext<AppUser>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    public DbSet<Device> Devices => Set<Device>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);
        b.Entity<Device>().Property(d => d.RowVersion).IsRowVersion();
        b.Entity<Device>().HasIndex(d => d.Code).IsUnique();
    }
}
