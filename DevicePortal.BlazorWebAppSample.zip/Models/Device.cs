using System.ComponentModel.DataAnnotations;
namespace DevicePortal.WebApp.Models;
public class Device {
    public Guid Id { get; set; } = Guid.NewGuid();
    [Required, MaxLength(50)] public string Code { get; set; } = string.Empty;
    [Required, MaxLength(200)] public string Name { get; set; } = string.Empty;
    [MaxLength(100)] public string Category { get; set; } = string.Empty;
    [MaxLength(100)] public string? Serial { get; set; }
    [DataType(DataType.Date)] public DateTime? PurchaseDate { get; set; }
    public bool Active { get; set; } = true;
    public byte[]? RowVersion { get; set; }
}
