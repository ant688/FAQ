using Microsoft.AspNetCore.Identity; namespace DevicePortal.WebApp.Models; public class AppUser : IdentityUser { public string? PreferredCulture { get; set; } }
