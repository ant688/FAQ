namespace DevicePortal.WebApp.Localization; public class Shared { }
