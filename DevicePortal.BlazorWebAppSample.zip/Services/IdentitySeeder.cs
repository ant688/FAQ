using DevicePortal.WebApp.Models;
using Microsoft.AspNetCore.Identity;

namespace DevicePortal.WebApp.Services;
public static class IdentitySeeder {
    public static async Task SeedAsync(IApplicationBuilder app){
        using var s = app.ApplicationServices.CreateScope();
        var cfg = s.ServiceProvider.GetRequiredService<IConfiguration>();
        var rm = s.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var um = s.ServiceProvider.GetRequiredService<UserManager<AppUser>>();
        foreach (var r in new[]{ "Admin","Requester","Approver"}) if (!await rm.RoleExistsAsync(r)) await rm.CreateAsync(new IdentityRole(r));
        var email = cfg["Seed:AdminEmail"]; var pass = cfg["Seed:AdminPassword"] ?? "ChangeMe_123!";
        if (!string.IsNullOrWhiteSpace(email)){
            var u = await um.FindByEmailAsync(email);
            if (u is null){ u = new AppUser{ UserName=email, Email=email, EmailConfirmed=true };
                await um.CreateAsync(u, pass); await um.AddToRoleAsync(u,"Admin"); }
        }
    }
}
