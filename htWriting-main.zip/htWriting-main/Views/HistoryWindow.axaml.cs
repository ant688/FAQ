using Avalonia.Controls;
using Avalonia.Input;
using htWriting.Helpers;
using htWriting.ViewModels;
using Ursa.Controls;

namespace htWriting.Views;

public partial class HistoryWindow : Window
{
    public HistoryWindow()
    {
        InitializeComponent();
        Opened += OnOpened;
    }

    public HistoryWindow(HistoryViewModel viewModel)
        : this()
    {
        DataContext = viewModel;
    }

    private async void OnOpened(object? sender, EventArgs e)
    {
        if (DataContext is HistoryViewModel viewModel)
        {
            await viewModel.LoadHistoryAsync();
        }
    }

    private async void SearchKeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && DataContext is HistoryViewModel viewModel)
        {
            await viewModel.LoadHistoryAsync();
        }
    }

    private void DeleteItemClick(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (sender is Button { DataContext: HistoryItemViewModel item }
            && DataContext is HistoryViewModel viewModel)
        {
            viewModel.DeleteHistoryCommand.Execute(item);
        }
    }

    private async void DeleteAllClick(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (DataContext is HistoryViewModel viewModel)
        {
            var result = await MessageBox.ShowAsync(
                this,
                UiText.Get(viewModel.UiLanguage, "history.confirm_delete_all_message"),
                UiText.Get(viewModel.UiLanguage, "history.confirm_delete_all_title"),
                MessageBoxIcon.Warning,
                MessageBoxButton.YesNo);

            if (result == MessageBoxResult.Yes)
            {
                await viewModel.DeleteAllHistoryAsync();
            }
        }
    }
}
