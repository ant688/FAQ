using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using htWriting.Contracts;
using htWriting.Helpers;
using htWriting.Models;

namespace htWriting.ViewModels;

public partial class HistoryViewModel : ViewModelBase
{
    private readonly IRewriteHistoryService _historyService;
    private IReadOnlyList<RewriteHistoryEntry> _entries = [];

    [ObservableProperty]
    public partial UiLanguage UiLanguage { get; set; } = UiLanguage.Vietnamese;

    [ObservableProperty]
    public partial string SearchText { get; set; } = string.Empty;

    [ObservableProperty]
    public partial string StatusMessage { get; set; } = string.Empty;

    public ObservableCollection<HistoryItemViewModel> Items { get; } = [];

    public bool IsEmpty => Items.Count == 0;

    public HistoryViewModel(IRewriteHistoryService historyService)
    {
        _historyService = historyService;
    }

    partial void OnUiLanguageChanged(UiLanguage value) => RefreshItems();

    [RelayCommand]
    public async Task LoadHistoryAsync()
    {
        try
        {
            _entries = await _historyService.SearchAsync(SearchText.Trim());
            RefreshItems();
            StatusMessage = string.Empty;
        }
        catch (Exception exception)
        {
            StatusMessage = UiText.Get(UiLanguage, "history.load_error", exception.Message);
        }
    }

    [RelayCommand]
    public async Task DeleteHistoryAsync(HistoryItemViewModel item)
    {
        try
        {
            await _historyService.DeleteAsync(item.Id);
            await LoadHistoryAsync();
        }
        catch (Exception exception)
        {
            StatusMessage = UiText.Get(UiLanguage, "history.delete_error", exception.Message);
        }
    }

    [RelayCommand]
    public async Task DeleteAllHistoryAsync()
    {
        try
        {
            await _historyService.DeleteAllAsync();
            await LoadHistoryAsync();
        }
        catch (Exception exception)
        {
            StatusMessage = UiText.Get(UiLanguage, "history.delete_error", exception.Message);
        }
    }

    private void RefreshItems()
    {
        Items.Clear();
        foreach (var entry in _entries)
        {
            Items.Add(new HistoryItemViewModel(entry, UiLanguage));
        }

        OnPropertyChanged(nameof(IsEmpty));
    }
}
