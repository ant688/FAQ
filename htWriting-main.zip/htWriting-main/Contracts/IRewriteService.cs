using htWriting.Models;

namespace htWriting.Contracts;

public interface IRewriteService
{
    IAsyncEnumerable<string> RewriteTextAsync(
        string originalText,
        string modelPath,
        int gpuLayerCount,
        int maxTokens,
        RewriteStyle style,
        Language inputLanguage,
        Language translateTo,
        bool useModelConfig,
        ModelSamplingPipeline configs,
        bool enableThinking,
        IReadOnlyList<string> additionalGuidelines,
        CancellationToken cancellationToken = default);
}
